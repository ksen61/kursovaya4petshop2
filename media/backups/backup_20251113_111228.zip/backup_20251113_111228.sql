--
-- PostgreSQL database dump
--

\restrict JjGylJgvWfEBFOhU7dRkyfO7mePgYm2EvBhTPtkmNtZFy5Z9J4WQhAF6jnpt5Jt

-- Dumped from database version 17rc1
-- Dumped by pg_dump version 17.6 (Homebrew)

-- Started on 2025-11-13 11:12:28 MSK

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 291 (class 1255 OID 20178)
-- Name: get_orders_by_day(date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_orders_by_day(day_date date) RETURNS TABLE(order_id bigint, user_name character varying, total numeric, order_date date)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT o.id,
           (u.first_name || ' ' || u.last_name)::VARCHAR AS user_name,
           SUM(oi.quantity * oi.price)::NUMERIC AS total,
           o.date_created::DATE
    FROM petshop_order o
    JOIN petshop_orderitem oi ON o.id = oi.order_id
    JOIN petshop_user u ON o.user_id = u.id
    WHERE o.date_created::DATE = day_date
    GROUP BY o.id, u.first_name, u.last_name, o.date_created
    ORDER BY o.id ASC;
END;
$$;


ALTER FUNCTION public.get_orders_by_day(day_date date) OWNER TO postgres;

--
-- TOC entry 290 (class 1255 OID 20180)
-- Name: get_orders_by_month(date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_orders_by_month(month_date date) RETURNS TABLE(order_id bigint, user_name character varying, total numeric, order_date date)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT o.id,
           (u.first_name || ' ' || u.last_name)::VARCHAR AS user_name,
           SUM(oi.quantity * oi.price)::NUMERIC AS total,
           o.date_created::DATE
    FROM petshop_order o
    JOIN petshop_orderitem oi ON o.id = oi.order_id
    JOIN petshop_user u ON o.user_id = u.id
    WHERE date_trunc('month', o.date_created) = date_trunc('month', month_date)
    GROUP BY o.id, u.first_name, u.last_name, o.date_created
    ORDER BY o.id ASC;
END;
$$;


ALTER FUNCTION public.get_orders_by_month(month_date date) OWNER TO postgres;

--
-- TOC entry 292 (class 1255 OID 20179)
-- Name: get_orders_by_week(date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_orders_by_week(week_date date) RETURNS TABLE(order_id bigint, user_name character varying, total numeric, order_date date)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT o.id,
           (u.first_name || ' ' || u.last_name)::VARCHAR AS user_name,
           SUM(oi.quantity * oi.price)::NUMERIC AS total,
           o.date_created::DATE
    FROM petshop_order o
    JOIN petshop_orderitem oi ON o.id = oi.order_id
    JOIN petshop_user u ON o.user_id = u.id
    WHERE date_trunc('week', o.date_created) = date_trunc('week', week_date)
    GROUP BY o.id, u.first_name, u.last_name, o.date_created
    ORDER BY o.id ASC;
END;
$$;


ALTER FUNCTION public.get_orders_by_week(week_date date) OWNER TO postgres;

--
-- TOC entry 293 (class 1255 OID 20182)
-- Name: get_orders_report(bigint, bigint, bigint, bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_orders_report(var_product_id bigint, var_category_id bigint, var_brand_id bigint, var_user_id bigint) RETURNS TABLE(order_id bigint, product_name character varying, brand_name character varying, category_name character varying, user_name character varying, quantity integer, total numeric, order_date date)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT o.id,
           p.name AS product_name,
           b.name AS brand_name,
           c.name AS category_name,
           (u.first_name || ' ' || u.last_name)::VARCHAR AS user_name,
           oi.quantity,
           (oi.quantity * oi.price)::NUMERIC AS total,
           o.date_created::DATE AS order_date
    FROM petshop_order o
    JOIN petshop_orderitem oi ON o.id = oi.order_id
    JOIN petshop_product p ON oi.product_id = p.id
    JOIN petshop_category c ON p.category_id = c.id
    JOIN petshop_brand b ON p.brand_id = b.id
    JOIN petshop_user u ON o.user_id = u.id
    WHERE (var_product_id IS NULL OR p.id = var_product_id)
      AND (var_category_id IS NULL OR c.id = var_category_id)
      AND (var_brand_id IS NULL OR b.id = var_brand_id)
      AND (var_user_id IS NULL OR u.id = var_user_id)
    ORDER BY o.id ASC;
END;
$$;


ALTER FUNCTION public.get_orders_report(var_product_id bigint, var_category_id bigint, var_brand_id bigint, var_user_id bigint) OWNER TO postgres;

--
-- TOC entry 277 (class 1255 OID 20151)
-- Name: get_sales_by_category(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_sales_by_category() RETURNS TABLE(category_name character varying, total_sales numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT c.name, SUM(oi.price * oi.quantity) AS total_sales
    FROM petshop_orderitem oi
    JOIN petshop_product p ON oi.product_id = p.id
    JOIN petshop_category c ON p.category_id = c.id
    GROUP BY c.name
    ORDER BY total_sales DESC;
END;
$$;


ALTER FUNCTION public.get_sales_by_category() OWNER TO postgres;

--
-- TOC entry 278 (class 1255 OID 20153)
-- Name: get_sales_by_month(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_sales_by_month() RETURNS TABLE(month date, total_sales numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT DATE_TRUNC('month', o.date_created)::DATE AS month,
           SUM(oi.price * oi.quantity) AS total_sales
    FROM petshop_orderitem oi
    JOIN petshop_order o ON oi.order_id = o.id
    GROUP BY DATE_TRUNC('month', o.date_created)::DATE
    ORDER BY month;
END;
$$;


ALTER FUNCTION public.get_sales_by_month() OWNER TO postgres;

--
-- TOC entry 308 (class 1255 OID 20338)
-- Name: log_delete(text, bigint, json); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.log_delete(IN p_table_name text, IN p_row_id bigint, IN p_old_data json)
    LANGUAGE plpgsql
    AS $$
DECLARE
    p_user_id bigint;
BEGIN
    p_user_id := current_setting('myapp.current_user_id', true)::bigint;

    INSERT INTO petshop_auditlog(table_name, row_id, user_id, action, old_data, action_time)
    VALUES (p_table_name, p_row_id, p_user_id, 'DELETE', p_old_data, NOW());
END;
$$;


ALTER PROCEDURE public.log_delete(IN p_table_name text, IN p_row_id bigint, IN p_old_data json) OWNER TO postgres;

--
-- TOC entry 295 (class 1255 OID 20336)
-- Name: log_insert(text, bigint, json); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.log_insert(IN p_table_name text, IN p_row_id bigint, IN p_new_data json)
    LANGUAGE plpgsql
    AS $$
DECLARE
    p_user_id bigint;
BEGIN
    -- Берём user_id из текущей сессии, если не задано — NULL
    p_user_id := current_setting('myapp.current_user_id', true)::bigint;

    INSERT INTO petshop_auditlog(table_name, row_id, user_id, action, new_data, action_time)
    VALUES (p_table_name, p_row_id, p_user_id, 'CREATE', p_new_data, NOW());
END;
$$;


ALTER PROCEDURE public.log_insert(IN p_table_name text, IN p_row_id bigint, IN p_new_data json) OWNER TO postgres;

--
-- TOC entry 296 (class 1255 OID 20337)
-- Name: log_update(text, bigint, json, json); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.log_update(IN p_table_name text, IN p_row_id bigint, IN p_old_data json, IN p_new_data json)
    LANGUAGE plpgsql
    AS $$
DECLARE
    p_user_id bigint;
BEGIN
    p_user_id := current_setting('myapp.current_user_id', true)::bigint;

    INSERT INTO petshop_auditlog(table_name, row_id, user_id, action, old_data, new_data, action_time)
    VALUES (p_table_name, p_row_id, p_user_id, 'UPDATE', p_old_data, p_new_data, NOW());
END;
$$;


ALTER PROCEDURE public.log_update(IN p_table_name text, IN p_row_id bigint, IN p_old_data json, IN p_new_data json) OWNER TO postgres;

--
-- TOC entry 298 (class 1255 OID 20403)
-- Name: trg_agecategory_delete_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_agecategory_delete_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    CALL log_delete('petshop_agecategory', OLD.id, row_to_json(OLD));
    RETURN OLD;
END; $$;


ALTER FUNCTION public.trg_agecategory_delete_func() OWNER TO postgres;

--
-- TOC entry 294 (class 1255 OID 20399)
-- Name: trg_agecategory_insert_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_agecategory_insert_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
	CALL log_insert('petshop_agecategory', NEW.id, row_to_json(NEW));
    RETURN NEW;
END; $$;


ALTER FUNCTION public.trg_agecategory_insert_func() OWNER TO postgres;

--
-- TOC entry 297 (class 1255 OID 20401)
-- Name: trg_agecategory_update_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_agecategory_update_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    CALL log_update('petshop_agecategory', NEW.id, row_to_json(OLD), row_to_json(NEW));
    RETURN NEW;
END; $$;


ALTER FUNCTION public.trg_agecategory_update_func() OWNER TO postgres;

--
-- TOC entry 331 (class 1255 OID 20397)
-- Name: trg_brand_delete_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_brand_delete_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    CALL log_delete('petshop_brand', OLD.id, row_to_json(OLD));
    RETURN OLD;
END; $$;


ALTER FUNCTION public.trg_brand_delete_func() OWNER TO postgres;

--
-- TOC entry 329 (class 1255 OID 20393)
-- Name: trg_brand_insert_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_brand_insert_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    CALL log_insert('petshop_brand', NEW.id, row_to_json(NEW));
    RETURN NEW;
END; $$;


ALTER FUNCTION public.trg_brand_insert_func() OWNER TO postgres;

--
-- TOC entry 330 (class 1255 OID 20395)
-- Name: trg_brand_update_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_brand_update_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    CALL log_update('petshop_brand', NEW.id, row_to_json(OLD), row_to_json(NEW));
    RETURN NEW;
END; $$;


ALTER FUNCTION public.trg_brand_update_func() OWNER TO postgres;

--
-- TOC entry 328 (class 1255 OID 20391)
-- Name: trg_category_delete_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_category_delete_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    CALL log_delete('petshop_category', OLD.id, row_to_json(OLD));
    RETURN OLD;
END; $$;


ALTER FUNCTION public.trg_category_delete_func() OWNER TO postgres;

--
-- TOC entry 326 (class 1255 OID 20387)
-- Name: trg_category_insert_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_category_insert_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    CALL log_insert('petshop_category', NEW.id, row_to_json(NEW));
    RETURN NEW;
END; $$;


ALTER FUNCTION public.trg_category_insert_func() OWNER TO postgres;

--
-- TOC entry 327 (class 1255 OID 20389)
-- Name: trg_category_update_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_category_update_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    CALL log_update('petshop_category', NEW.id, row_to_json(OLD), row_to_json(NEW));
    RETURN NEW;
END; $$;


ALTER FUNCTION public.trg_category_update_func() OWNER TO postgres;

--
-- TOC entry 314 (class 1255 OID 20355)
-- Name: trg_order_delete_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_order_delete_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    CALL log_delete('petshop_order', NEW.id, row_to_json(Old));
    RETURN OLD;
END; $$;


ALTER FUNCTION public.trg_order_delete_func() OWNER TO postgres;

--
-- TOC entry 312 (class 1255 OID 20351)
-- Name: trg_order_insert_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_order_insert_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    CALL log_insert('petshop_order', NEW.id, row_to_json(NEW));
    RETURN NEW;
END; $$;


ALTER FUNCTION public.trg_order_insert_func() OWNER TO postgres;

--
-- TOC entry 313 (class 1255 OID 20353)
-- Name: trg_order_update_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_order_update_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    CALL log_update('petshop_order', NEW.id, row_to_json(OLD), row_to_json(NEW));
    RETURN NEW;
END; $$;


ALTER FUNCTION public.trg_order_update_func() OWNER TO postgres;

--
-- TOC entry 317 (class 1255 OID 20361)
-- Name: trg_pickuppoint_delete_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_pickuppoint_delete_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    CALL log_delete('petshop_pickuppoint', NEW.id, row_to_json(OLD));
    RETURN OLD;
END; $$;


ALTER FUNCTION public.trg_pickuppoint_delete_func() OWNER TO postgres;

--
-- TOC entry 315 (class 1255 OID 20357)
-- Name: trg_pickuppoint_insert_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_pickuppoint_insert_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    CALL log_insert('petshop_pickuppoint', NEW.id, row_to_json(NEW));
    RETURN NEW;
END; $$;


ALTER FUNCTION public.trg_pickuppoint_insert_func() OWNER TO postgres;

--
-- TOC entry 316 (class 1255 OID 20359)
-- Name: trg_pickuppoint_update_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_pickuppoint_update_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    CALL log_update('petshop_pickuppoint', NEW.id, row_to_json(OLD), row_to_json(NEW));
    RETURN NEW;
END; $$;


ALTER FUNCTION public.trg_pickuppoint_update_func() OWNER TO postgres;

--
-- TOC entry 309 (class 1255 OID 20385)
-- Name: trg_product_delete_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_product_delete_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    CALL log_delete('petshop_product', OLD.id, row_to_json(OLD));
    RETURN OLD;
END; $$;


ALTER FUNCTION public.trg_product_delete_func() OWNER TO postgres;

--
-- TOC entry 324 (class 1255 OID 20381)
-- Name: trg_product_insert_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_product_insert_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    CALL log_insert('petshop_product', NEW.id, row_to_json(NEW));
    RETURN NEW;
END; $$;


ALTER FUNCTION public.trg_product_insert_func() OWNER TO postgres;

--
-- TOC entry 325 (class 1255 OID 20383)
-- Name: trg_product_update_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_product_update_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    CALL log_update('petshop_product', NEW.id, row_to_json(OLD), row_to_json(NEW));
    RETURN NEW;
END; $$;


ALTER FUNCTION public.trg_product_update_func() OWNER TO postgres;

--
-- TOC entry 332 (class 1255 OID 20349)
-- Name: trg_productpurpose_delete_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_productpurpose_delete_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    CALL log_delete('petshop_productpurpose', OLD.id, row_to_json(OLD));
    RETURN OLD;
END;
$$;


ALTER FUNCTION public.trg_productpurpose_delete_func() OWNER TO postgres;

--
-- TOC entry 310 (class 1255 OID 20345)
-- Name: trg_productpurpose_insert_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_productpurpose_insert_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    	CALL log_insert('petshop_productpurpose', NEW.id, row_to_json(NEW));
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.trg_productpurpose_insert_func() OWNER TO postgres;

--
-- TOC entry 311 (class 1255 OID 20347)
-- Name: trg_productpurpose_update_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_productpurpose_update_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    CALL log_update('petshop_productpurpose', NEW.id, row_to_json(OLD), row_to_json(NEW));
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.trg_productpurpose_update_func() OWNER TO postgres;

--
-- TOC entry 320 (class 1255 OID 20367)
-- Name: trg_productstock_delete_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_productstock_delete_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    CALL log_delete('petshop_productstock', OLD.id, row_to_json(OLD));
    RETURN OLD;
END; $$;


ALTER FUNCTION public.trg_productstock_delete_func() OWNER TO postgres;

--
-- TOC entry 318 (class 1255 OID 20363)
-- Name: trg_productstock_insert_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_productstock_insert_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    CALL log_insert('petshop_productstock', NEW.id, row_to_json(NEW));
    RETURN NEW;
END; $$;


ALTER FUNCTION public.trg_productstock_insert_func() OWNER TO postgres;

--
-- TOC entry 319 (class 1255 OID 20365)
-- Name: trg_productstock_update_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_productstock_update_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    CALL log_update('petshop_productstock', NEW.id, row_to_json(OLD), row_to_json(NEW));
    RETURN NEW;
END; $$;


ALTER FUNCTION public.trg_productstock_update_func() OWNER TO postgres;

--
-- TOC entry 301 (class 1255 OID 20409)
-- Name: trg_producttype_delete_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_producttype_delete_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    CALL log_delete('petshop_producttype', OLD.id, row_to_json(OLD));
    RETURN OLD;
END; $$;


ALTER FUNCTION public.trg_producttype_delete_func() OWNER TO postgres;

--
-- TOC entry 299 (class 1255 OID 20405)
-- Name: trg_producttype_insert_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_producttype_insert_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    CALL log_insert('petshop_producttype', NEW.id, row_to_json(NEW));
    RETURN NEW;
END; $$;


ALTER FUNCTION public.trg_producttype_insert_func() OWNER TO postgres;

--
-- TOC entry 300 (class 1255 OID 20407)
-- Name: trg_producttype_update_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_producttype_update_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    CALL log_update('petshop_producttype', NEW.id, row_to_json(OLD), row_to_json(NEW));
    RETURN NEW;
END; $$;


ALTER FUNCTION public.trg_producttype_update_func() OWNER TO postgres;

--
-- TOC entry 307 (class 1255 OID 20421)
-- Name: trg_purpose_delete_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_purpose_delete_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    CALL log_delete('petshop_purpose', OLD.id, row_to_json(OLD));
    RETURN OLD;
END; $$;


ALTER FUNCTION public.trg_purpose_delete_func() OWNER TO postgres;

--
-- TOC entry 305 (class 1255 OID 20417)
-- Name: trg_purpose_insert_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_purpose_insert_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    CALL log_insert('petshop_purpose', NEW.id, row_to_json(NEW));
    RETURN NEW;
END; $$;


ALTER FUNCTION public.trg_purpose_insert_func() OWNER TO postgres;

--
-- TOC entry 306 (class 1255 OID 20419)
-- Name: trg_purpose_update_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_purpose_update_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    CALL log_update('petshop_purpose', NEW.id, row_to_json(OLD), row_to_json(NEW));
    RETURN NEW;
END; $$;


ALTER FUNCTION public.trg_purpose_update_func() OWNER TO postgres;

--
-- TOC entry 323 (class 1255 OID 20379)
-- Name: trg_role_delete_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_role_delete_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    CALL log_delete('petshop_role', OLD.id, row_to_json(OLD));
    RETURN OLD;
END; $$;


ALTER FUNCTION public.trg_role_delete_func() OWNER TO postgres;

--
-- TOC entry 321 (class 1255 OID 20375)
-- Name: trg_role_insert_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_role_insert_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    CALL log_insert('petshop_role', NEW.id, row_to_json(NEW));
    RETURN NEW;
END; $$;


ALTER FUNCTION public.trg_role_insert_func() OWNER TO postgres;

--
-- TOC entry 322 (class 1255 OID 20377)
-- Name: trg_role_update_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_role_update_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    CALL log_update('petshop_role', NEW.id, row_to_json(OLD), row_to_json(NEW));
    RETURN NEW;
END; $$;


ALTER FUNCTION public.trg_role_update_func() OWNER TO postgres;

--
-- TOC entry 304 (class 1255 OID 20415)
-- Name: trg_species_delete_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_species_delete_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    CALL log_delete('petshop_species', OLD.id, row_to_json(OLD));
    RETURN OLD;
END; $$;


ALTER FUNCTION public.trg_species_delete_func() OWNER TO postgres;

--
-- TOC entry 302 (class 1255 OID 20411)
-- Name: trg_species_insert_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_species_insert_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    CALL log_insert('petshop_species', NEW.id, row_to_json(NEW));
    RETURN NEW;
END; $$;


ALTER FUNCTION public.trg_species_insert_func() OWNER TO postgres;

--
-- TOC entry 303 (class 1255 OID 20413)
-- Name: trg_species_update_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_species_update_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    CALL log_update('petshop_species', NEW.id, row_to_json(OLD), row_to_json(NEW));
    RETURN NEW;
END; $$;


ALTER FUNCTION public.trg_species_update_func() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 260 (class 1259 OID 19993)
-- Name: auth_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO postgres;

--
-- TOC entry 259 (class 1259 OID 19992)
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.auth_group ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 262 (class 1259 OID 20001)
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group_permissions (
    id bigint NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO postgres;

--
-- TOC entry 261 (class 1259 OID 20000)
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.auth_group_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 258 (class 1259 OID 19987)
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO postgres;

--
-- TOC entry 257 (class 1259 OID 19986)
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.auth_permission ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 256 (class 1259 OID 19966)
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id bigint NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO postgres;

--
-- TOC entry 255 (class 1259 OID 19965)
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.django_admin_log ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 254 (class 1259 OID 19958)
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO postgres;

--
-- TOC entry 253 (class 1259 OID 19957)
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.django_content_type ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 218 (class 1259 OID 19704)
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_migrations (
    id bigint NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO postgres;

--
-- TOC entry 217 (class 1259 OID 19703)
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.django_migrations ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 267 (class 1259 OID 20085)
-- Name: django_session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO postgres;

--
-- TOC entry 220 (class 1259 OID 19712)
-- Name: petshop_agecategory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.petshop_agecategory (
    id bigint NOT NULL,
    age_name character varying(100) NOT NULL,
    is_active boolean NOT NULL
);


ALTER TABLE public.petshop_agecategory OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 19711)
-- Name: petshop_agecategory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.petshop_agecategory ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.petshop_agecategory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 272 (class 1259 OID 20187)
-- Name: petshop_auditlog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.petshop_auditlog (
    id bigint NOT NULL,
    table_name character varying(100) NOT NULL,
    row_id bigint NOT NULL,
    action character varying(10) NOT NULL,
    old_data jsonb,
    new_data jsonb,
    action_time timestamp with time zone NOT NULL,
    user_id bigint
);


ALTER TABLE public.petshop_auditlog OWNER TO postgres;

--
-- TOC entry 271 (class 1259 OID 20186)
-- Name: petshop_auditlog_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.petshop_auditlog ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.petshop_auditlog_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 222 (class 1259 OID 19718)
-- Name: petshop_brand; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.petshop_brand (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    is_active boolean NOT NULL
);


ALTER TABLE public.petshop_brand OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 19717)
-- Name: petshop_brand_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.petshop_brand ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.petshop_brand_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 250 (class 1259 OID 19832)
-- Name: petshop_cart; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.petshop_cart (
    id bigint NOT NULL,
    quantity integer NOT NULL,
    product_id bigint NOT NULL,
    user_id bigint NOT NULL
);


ALTER TABLE public.petshop_cart OWNER TO postgres;

--
-- TOC entry 249 (class 1259 OID 19831)
-- Name: petshop_cart_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.petshop_cart ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.petshop_cart_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 224 (class 1259 OID 19724)
-- Name: petshop_category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.petshop_category (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    is_active boolean NOT NULL
);


ALTER TABLE public.petshop_category OWNER TO postgres;

--
-- TOC entry 223 (class 1259 OID 19723)
-- Name: petshop_category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.petshop_category ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.petshop_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 236 (class 1259 OID 19762)
-- Name: petshop_order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.petshop_order (
    id bigint NOT NULL,
    order_number character varying(20) NOT NULL,
    status character varying(20) NOT NULL,
    total_price numeric(10,2) NOT NULL,
    date_created timestamp with time zone NOT NULL,
    date_updated timestamp with time zone NOT NULL,
    pickup_point_id bigint NOT NULL,
    user_id bigint NOT NULL,
    email character varying(254) NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    phone character varying(20)
);


ALTER TABLE public.petshop_order OWNER TO postgres;

--
-- TOC entry 235 (class 1259 OID 19761)
-- Name: petshop_order_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.petshop_order ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.petshop_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 240 (class 1259 OID 19778)
-- Name: petshop_orderitem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.petshop_orderitem (
    id bigint NOT NULL,
    quantity integer NOT NULL,
    price numeric(10,2) NOT NULL,
    order_id bigint NOT NULL,
    product_id bigint NOT NULL
);


ALTER TABLE public.petshop_orderitem OWNER TO postgres;

--
-- TOC entry 239 (class 1259 OID 19777)
-- Name: petshop_orderitem_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.petshop_orderitem ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.petshop_orderitem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 238 (class 1259 OID 19770)
-- Name: petshop_product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.petshop_product (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    price numeric(10,2) NOT NULL,
    stock integer NOT NULL,
    image character varying(255),
    is_active boolean NOT NULL,
    age_category_id bigint,
    brand_id bigint,
    category_id bigint NOT NULL,
    product_type_id bigint,
    species_id bigint
);


ALTER TABLE public.petshop_product OWNER TO postgres;

--
-- TOC entry 269 (class 1259 OID 20139)
-- Name: petshop_orders_by_brand; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.petshop_orders_by_brand AS
 SELECT b.name AS brand_name,
    count(oi.id) AS total_orders,
    sum((oi.price * (oi.quantity)::numeric)) AS total_sales,
    avg((oi.price * (oi.quantity)::numeric)) AS avg_order_value
   FROM (((public.petshop_orderitem oi
     JOIN public.petshop_order o ON ((oi.order_id = o.id)))
     JOIN public.petshop_product p ON ((oi.product_id = p.id)))
     LEFT JOIN public.petshop_brand b ON ((p.brand_id = b.id)))
  GROUP BY b.name
  ORDER BY (sum((oi.price * (oi.quantity)::numeric))) DESC;


ALTER VIEW public.petshop_orders_by_brand OWNER TO postgres;

--
-- TOC entry 268 (class 1259 OID 20134)
-- Name: petshop_orders_by_category; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.petshop_orders_by_category AS
 SELECT row_number() OVER () AS id,
    c.name AS category_name,
    count(o.id) AS total_orders,
    sum((oi.price * (oi.quantity)::numeric)) AS total_sales,
    avg((oi.price * (oi.quantity)::numeric)) AS avg_order_value
   FROM (((public.petshop_product p
     JOIN public.petshop_category c ON ((p.category_id = c.id)))
     JOIN public.petshop_orderitem oi ON ((oi.product_id = p.id)))
     JOIN public.petshop_order o ON ((oi.order_id = o.id)))
  GROUP BY c.name;


ALTER VIEW public.petshop_orders_by_category OWNER TO postgres;

--
-- TOC entry 270 (class 1259 OID 20144)
-- Name: petshop_orders_by_month; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.petshop_orders_by_month AS
 SELECT date_trunc('month'::text, o.date_created) AS month,
    count(o.id) AS total_orders,
    sum((oi.price * (oi.quantity)::numeric)) AS total_sales,
    avg((oi.price * (oi.quantity)::numeric)) AS avg_order_value
   FROM (public.petshop_order o
     JOIN public.petshop_orderitem oi ON ((oi.order_id = o.id)))
  GROUP BY (date_trunc('month'::text, o.date_created))
  ORDER BY (date_trunc('month'::text, o.date_created));


ALTER VIEW public.petshop_orders_by_month OWNER TO postgres;

--
-- TOC entry 226 (class 1259 OID 19730)
-- Name: petshop_pickuppoint; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.petshop_pickuppoint (
    id bigint NOT NULL,
    address character varying(255) NOT NULL,
    working_hours character varying(100),
    is_active boolean NOT NULL
);


ALTER TABLE public.petshop_pickuppoint OWNER TO postgres;

--
-- TOC entry 225 (class 1259 OID 19729)
-- Name: petshop_pickuppoint_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.petshop_pickuppoint ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.petshop_pickuppoint_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 237 (class 1259 OID 19769)
-- Name: petshop_product_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.petshop_product ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.petshop_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 244 (class 1259 OID 19790)
-- Name: petshop_productpurpose; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.petshop_productpurpose (
    id bigint NOT NULL,
    product_id bigint NOT NULL,
    purpose_id bigint NOT NULL
);


ALTER TABLE public.petshop_productpurpose OWNER TO postgres;

--
-- TOC entry 243 (class 1259 OID 19789)
-- Name: petshop_productpurpose_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.petshop_productpurpose ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.petshop_productpurpose_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 242 (class 1259 OID 19784)
-- Name: petshop_productstock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.petshop_productstock (
    id bigint NOT NULL,
    quantity integer NOT NULL,
    pickup_point_id bigint NOT NULL,
    product_id bigint NOT NULL
);


ALTER TABLE public.petshop_productstock OWNER TO postgres;

--
-- TOC entry 241 (class 1259 OID 19783)
-- Name: petshop_productstock_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.petshop_productstock ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.petshop_productstock_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 228 (class 1259 OID 19736)
-- Name: petshop_producttype; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.petshop_producttype (
    id bigint NOT NULL,
    type_name character varying(100) NOT NULL,
    is_active boolean NOT NULL
);


ALTER TABLE public.petshop_producttype OWNER TO postgres;

--
-- TOC entry 227 (class 1259 OID 19735)
-- Name: petshop_producttype_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.petshop_producttype ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.petshop_producttype_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 230 (class 1259 OID 19742)
-- Name: petshop_purpose; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.petshop_purpose (
    id bigint NOT NULL,
    purpose_name character varying(100) NOT NULL,
    is_active boolean NOT NULL
);


ALTER TABLE public.petshop_purpose OWNER TO postgres;

--
-- TOC entry 229 (class 1259 OID 19741)
-- Name: petshop_purpose_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.petshop_purpose ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.petshop_purpose_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 248 (class 1259 OID 19819)
-- Name: petshop_review; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.petshop_review (
    id bigint NOT NULL,
    rating integer NOT NULL,
    text text,
    date_created timestamp with time zone NOT NULL,
    product_id bigint NOT NULL,
    user_id bigint NOT NULL
);


ALTER TABLE public.petshop_review OWNER TO postgres;

--
-- TOC entry 247 (class 1259 OID 19818)
-- Name: petshop_review_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.petshop_review ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.petshop_review_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 232 (class 1259 OID 19748)
-- Name: petshop_role; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.petshop_role (
    id bigint NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.petshop_role OWNER TO postgres;

--
-- TOC entry 231 (class 1259 OID 19747)
-- Name: petshop_role_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.petshop_role ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.petshop_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 234 (class 1259 OID 19756)
-- Name: petshop_species; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.petshop_species (
    id bigint NOT NULL,
    species_name character varying(100) NOT NULL,
    is_active boolean NOT NULL
);


ALTER TABLE public.petshop_species OWNER TO postgres;

--
-- TOC entry 233 (class 1259 OID 19755)
-- Name: petshop_species_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.petshop_species ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.petshop_species_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 246 (class 1259 OID 19801)
-- Name: petshop_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.petshop_user (
    id bigint NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    middle_name character varying(50),
    email character varying(254) NOT NULL,
    password character varying(128) NOT NULL,
    phone character varying(20),
    role_id bigint NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    is_active boolean NOT NULL,
    is_staff boolean NOT NULL,
    is_superuser boolean NOT NULL,
    last_login timestamp with time zone
);


ALTER TABLE public.petshop_user OWNER TO postgres;

--
-- TOC entry 264 (class 1259 OID 20034)
-- Name: petshop_user_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.petshop_user_groups (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.petshop_user_groups OWNER TO postgres;

--
-- TOC entry 263 (class 1259 OID 20033)
-- Name: petshop_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.petshop_user_groups ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.petshop_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 245 (class 1259 OID 19800)
-- Name: petshop_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.petshop_user ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.petshop_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 266 (class 1259 OID 20043)
-- Name: petshop_user_user_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.petshop_user_user_permissions (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.petshop_user_user_permissions OWNER TO postgres;

--
-- TOC entry 265 (class 1259 OID 20042)
-- Name: petshop_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.petshop_user_user_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.petshop_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 252 (class 1259 OID 19838)
-- Name: petshop_userprofile; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.petshop_userprofile (
    id bigint NOT NULL,
    date_of_birth date,
    theme boolean NOT NULL,
    user_id bigint NOT NULL,
    date_format character varying(20) NOT NULL
);


ALTER TABLE public.petshop_userprofile OWNER TO postgres;

--
-- TOC entry 251 (class 1259 OID 19837)
-- Name: petshop_userprofile_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.petshop_userprofile ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.petshop_userprofile_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 274 (class 1259 OID 105408)
-- Name: reversion_revision; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reversion_revision (
    id integer NOT NULL,
    date_created timestamp with time zone NOT NULL,
    comment text NOT NULL,
    user_id bigint
);


ALTER TABLE public.reversion_revision OWNER TO postgres;

--
-- TOC entry 273 (class 1259 OID 105407)
-- Name: reversion_revision_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.reversion_revision ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.reversion_revision_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 276 (class 1259 OID 105416)
-- Name: reversion_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reversion_version (
    id integer NOT NULL,
    object_id character varying(191) NOT NULL,
    format character varying(255) NOT NULL,
    serialized_data text NOT NULL,
    object_repr text NOT NULL,
    content_type_id integer NOT NULL,
    revision_id integer NOT NULL,
    db character varying(191) NOT NULL
);


ALTER TABLE public.reversion_version OWNER TO postgres;

--
-- TOC entry 275 (class 1259 OID 105415)
-- Name: reversion_version_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.reversion_version ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.reversion_version_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 4025 (class 0 OID 19993)
-- Dependencies: 260
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- TOC entry 4027 (class 0 OID 20001)
-- Dependencies: 262
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- TOC entry 4023 (class 0 OID 19987)
-- Dependencies: 258
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can view log entry	1	view_logentry
5	Can add permission	2	add_permission
6	Can change permission	2	change_permission
7	Can delete permission	2	delete_permission
8	Can view permission	2	view_permission
9	Can add group	3	add_group
10	Can change group	3	change_group
11	Can delete group	3	delete_group
12	Can view group	3	view_group
13	Can add content type	4	add_contenttype
14	Can change content type	4	change_contenttype
15	Can delete content type	4	delete_contenttype
16	Can view content type	4	view_contenttype
17	Can add session	5	add_session
18	Can change session	5	change_session
19	Can delete session	5	delete_session
20	Can view session	5	view_session
21	Can add age category	6	add_agecategory
22	Can change age category	6	change_agecategory
23	Can delete age category	6	delete_agecategory
24	Can view age category	6	view_agecategory
25	Can add brand	7	add_brand
26	Can change brand	7	change_brand
27	Can delete brand	7	delete_brand
28	Can view brand	7	view_brand
29	Can add category	8	add_category
30	Can change category	8	change_category
31	Can delete category	8	delete_category
32	Can view category	8	view_category
33	Can add pickup point	9	add_pickuppoint
34	Can change pickup point	9	change_pickuppoint
35	Can delete pickup point	9	delete_pickuppoint
36	Can view pickup point	9	view_pickuppoint
37	Can add product type	10	add_producttype
38	Can change product type	10	change_producttype
39	Can delete product type	10	delete_producttype
40	Can view product type	10	view_producttype
41	Can add purpose	11	add_purpose
42	Can change purpose	11	change_purpose
43	Can delete purpose	11	delete_purpose
44	Can view purpose	11	view_purpose
45	Can add role	12	add_role
46	Can change role	12	change_role
47	Can delete role	12	delete_role
48	Can view role	12	view_role
49	Can add species	13	add_species
50	Can change species	13	change_species
51	Can delete species	13	delete_species
52	Can view species	13	view_species
53	Can add order	14	add_order
54	Can change order	14	change_order
55	Can delete order	14	delete_order
56	Can view order	14	view_order
57	Can add product	15	add_product
58	Can change product	15	change_product
59	Can delete product	15	delete_product
60	Can view product	15	view_product
61	Can add order item	16	add_orderitem
62	Can change order item	16	change_orderitem
63	Can delete order item	16	delete_orderitem
64	Can view order item	16	view_orderitem
65	Can add product stock	17	add_productstock
66	Can change product stock	17	change_productstock
67	Can delete product stock	17	delete_productstock
68	Can view product stock	17	view_productstock
69	Can add product purpose	18	add_productpurpose
70	Can change product purpose	18	change_productpurpose
71	Can delete product purpose	18	delete_productpurpose
72	Can view product purpose	18	view_productpurpose
73	Can add user	19	add_user
74	Can change user	19	change_user
75	Can delete user	19	delete_user
76	Can view user	19	view_user
77	Can add test result	20	add_testresult
78	Can change test result	20	change_testresult
79	Can delete test result	20	delete_testresult
80	Can view test result	20	view_testresult
81	Can add review	21	add_review
82	Can change review	21	change_review
83	Can delete review	21	delete_review
84	Can view review	21	view_review
85	Can add cart	22	add_cart
86	Can change cart	22	change_cart
87	Can delete cart	22	delete_cart
88	Can view cart	22	view_cart
89	Can add user profile	23	add_userprofile
90	Can change user profile	23	change_userprofile
91	Can delete user profile	23	delete_userprofile
92	Can view user profile	23	view_userprofile
93	Can add orders by brand	24	add_ordersbybrand
94	Can change orders by brand	24	change_ordersbybrand
95	Can delete orders by brand	24	delete_ordersbybrand
96	Can view orders by brand	24	view_ordersbybrand
97	Can add orders by category	25	add_ordersbycategory
98	Can change orders by category	25	change_ordersbycategory
99	Can delete orders by category	25	delete_ordersbycategory
100	Can view orders by category	25	view_ordersbycategory
101	Can add orders by month	26	add_ordersbymonth
102	Can change orders by month	26	change_ordersbymonth
103	Can delete orders by month	26	delete_ordersbymonth
104	Can view orders by month	26	view_ordersbymonth
105	Can add audit log	27	add_auditlog
106	Can change audit log	27	change_auditlog
107	Can delete audit log	27	delete_auditlog
108	Can view audit log	27	view_auditlog
109	Can add revision	28	add_revision
110	Can change revision	28	change_revision
111	Can delete revision	28	delete_revision
112	Can view revision	28	view_revision
113	Can add version	29	add_version
114	Can change version	29	change_version
115	Can delete version	29	delete_version
116	Can view version	29	view_version
\.


--
-- TOC entry 4021 (class 0 OID 19966)
-- Dependencies: 256
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2025-09-20 17:33:00.948159+03	1	Взрослые	1	[{"added": {}}]	6	2
2	2025-09-20 17:40:43.991968+03	2	Пожилые	1	[{"added": {}}]	6	2
3	2025-09-20 17:40:54.974484+03	1	Carnica	1	[{"added": {}}]	7	2
4	2025-09-20 17:40:59.623563+03	2	Grandorf	1	[{"added": {}}]	7	2
5	2025-09-20 17:41:32.705691+03	1	Корм	1	[{"added": {}}]	8	2
6	2025-09-20 17:41:37.647239+03	2	Игрушки	1	[{"added": {}}]	8	2
7	2025-09-20 17:41:53.093283+03	1	Лакомства	1	[{"added": {}}]	10	2
8	2025-09-20 17:41:56.494164+03	2	Сухой корм	1	[{"added": {}}]	10	2
9	2025-09-20 17:42:14.173265+03	1	Для роста и развития	1	[{"added": {}}]	11	2
10	2025-09-20 17:42:16.874238+03	2	Для поддержания здоровья	1	[{"added": {}}]	11	2
11	2025-09-20 17:42:23.345498+03	1	Собаки	1	[{"added": {}}]	13	2
12	2025-09-20 17:42:26.356977+03	2	Кошки	1	[{"added": {}}]	13	2
13	2025-09-20 17:43:52.459458+03	1	Product object (1)	1	[{"added": {}}, {"added": {"name": "product purpose", "object": "ProductPurpose object (1)"}}]	15	2
14	2025-09-20 17:56:52.091442+03	1	PickupPoint object (1)	1	[{"added": {}}]	9	2
15	2025-09-20 17:57:17.882849+03	1	ProductStock object (1)	1	[{"added": {}}]	17	2
16	2025-09-20 17:57:49.359644+03	1	ProductStock object (1)	2	[{"changed": {"fields": ["Quantity"]}}]	17	2
17	2025-09-20 18:57:45.616622+03	3	Мария Белова	1	[{"added": {}}]	19	2
18	2025-09-20 18:57:56.81011+03	3	Мария Белова	2	[{"changed": {"fields": ["Is staff"]}}]	19	2
19	2025-09-20 20:25:51.292084+03	3	Мария Белова	2	[{"changed": {"fields": ["Superuser status"]}}]	19	2
20	2025-09-20 20:31:32.1491+03	1	Корм для кошек Grandorf 2кг ягненок с индейкой	2	[{"changed": {"fields": ["Stock"]}}]	15	2
21	2025-09-20 20:51:54.672529+03	1	Корм для кошек Grandorf 2кг ягненок с индейкой	2	[{"changed": {"fields": ["Stock"]}}]	15	2
22	2025-09-20 20:52:14.983901+03	1	ProductStock object (1)	2	[{"changed": {"fields": ["Quantity"]}}]	17	2
23	2025-09-20 21:00:05.750568+03	2	Покупатель	2	[{"changed": {"fields": ["Name"]}}]	12	2
24	2025-09-22 17:24:30.857488+03	27	Order object (27)	2	[{"changed": {"fields": ["Status"]}}]	14	3
25	2025-09-22 17:24:55.088025+03	22	Order object (22)	2	[{"changed": {"fields": ["Status"]}}]	14	3
26	2025-09-22 18:18:24.417275+03	27	Order object (27)	2	[{"changed": {"fields": ["Status"]}}]	14	3
27	2025-09-22 18:28:25.383908+03	28	Order object (28)	2	[{"changed": {"fields": ["Status"]}}]	14	3
28	2025-09-22 18:28:48.42397+03	1	Отзыв #1 - Корм для кошек Grandorf 2кг ягненок с индейкой от Мария	3		21	3
29	2025-09-22 18:33:03.64426+03	29	Order object (29)	2	[{"changed": {"fields": ["Status"]}}]	14	3
30	2025-09-22 18:41:07.293933+03	29	Order object (29)	2	[{"changed": {"fields": ["Status"]}}]	14	3
31	2025-09-22 18:41:20.951757+03	29	Order object (29)	2	[{"changed": {"fields": ["Status"]}}]	14	3
32	2025-09-22 18:42:52.718019+03	29	Order object (29)	2	[{"changed": {"fields": ["Status"]}}]	14	3
33	2025-09-22 18:42:58.963945+03	28	Order object (28)	2	[{"changed": {"fields": ["Status"]}}]	14	3
34	2025-09-22 18:43:07.721261+03	2	Отзыв #2 - Корм для кошек Grandorf 2кг ягненок с индейкой от Мария	3		21	3
35	2025-09-22 18:43:23.957996+03	28	Order object (28)	2	[{"changed": {"fields": ["Status"]}}]	14	3
36	2025-09-22 18:43:47.621292+03	30	Order object (30)	2	[{"changed": {"fields": ["Status"]}}]	14	3
37	2025-09-22 18:47:55.469132+03	1	ProductStock object (1)	2	[{"changed": {"fields": ["Quantity"]}}]	17	3
38	2025-09-22 18:48:12.939058+03	31	Order object (31)	2	[{"changed": {"fields": ["Status"]}}]	14	3
39	2025-09-22 18:49:40.304012+03	31	Order object (31)	2	[]	14	3
40	2025-09-23 18:25:08.235171+03	2	г. Москва, пр-т Дружбы, д. 45, магазин «Yes of кусь»	1	[{"added": {}}]	9	3
41	2025-09-23 18:25:19.257886+03	2	г. Москва, пр-т Дружбы, д. 45, зоомагазин «Yes of кусь»	2	[{"changed": {"fields": ["Address"]}}]	9	3
42	2025-09-23 18:25:48.287797+03	2	ProductStock object (2)	1	[{"added": {}}]	17	3
43	2025-09-23 18:30:05.602115+03	1	ProductStock object (1)	2	[{"changed": {"fields": ["Quantity"]}}]	17	3
44	2025-09-23 19:47:29.729943+03	2	ProductStock object (2)	2	[{"changed": {"fields": ["Quantity"]}}]	17	3
45	2025-09-23 21:24:32.249505+03	2	ProductStock object (2)	2	[{"changed": {"fields": ["Quantity"]}}]	17	3
46	2025-09-24 17:20:57.355129+03	3	ыауаук	1	[{"added": {}}]	6	3
47	2025-09-24 17:47:31.26535+03	3	dfgdfgdf	2	[{"changed": {"fields": ["Age name"]}}]	6	2
48	2025-09-24 17:51:56.720103+03	2	Игрушка для собак мягкая Triol Бобер	1	[{"added": {}}]	15	2
49	2025-09-24 17:55:33.452805+03	40	Order object (40)	2	[{"changed": {"fields": ["Status"]}}]	14	2
50	2025-09-24 18:40:51.751543+03	3	ыыввыыв	2	[{"changed": {"fields": ["Age name"]}}]	6	2
51	2025-09-24 18:50:11.4+03	40	Order object (40)	2	[{"changed": {"fields": ["Status"]}}]	14	2
52	2025-09-24 19:02:26.447891+03	40	Order object (40)	2	[{"changed": {"fields": ["Status"]}}]	14	2
53	2025-09-24 19:03:06.73451+03	41	Order object (41)	1	[{"added": {}}]	14	2
54	2025-09-24 19:19:22.981787+03	46	Order object (46)	1	[{"added": {}}]	14	2
55	2025-09-24 19:19:55.322113+03	46	Order object (46)	2	[{"changed": {"fields": ["Status"]}}]	14	2
56	2025-09-24 19:26:35.378584+03	3	ыывйввввыыв	2	[{"changed": {"fields": ["Age name"]}}]	6	2
57	2025-09-24 19:32:31.174061+03	3	121цвцвц	2	[{"changed": {"fields": ["Age name"]}}]	6	2
58	2025-09-24 19:43:37.647443+03	4	ыпып	1	[{"added": {}}]	6	2
59	2025-09-24 19:43:54.536563+03	4	ыпып	3		6	2
60	2025-09-24 19:45:22.171736+03	3	121цвцвц	3		6	2
61	2025-09-24 19:45:41.594972+03	5	ыввыы	1	[{"added": {}}]	6	2
62	2025-09-24 19:46:04.993124+03	6	ыв	1	[{"added": {}}]	6	2
63	2025-09-24 19:54:01.718554+03	2	ProductPurpose object (2)	1	[{"added": {}}]	18	2
66	2025-09-24 20:09:15.043779+03	6	23аауа	2	[{"changed": {"fields": ["Age name"]}}]	6	2
68	2025-09-24 20:42:06.234377+03	6	ывыв	2	[{"changed": {"fields": ["Age name"]}}]	6	2
69	2025-09-24 20:42:25.325837+03	6	ывыв	3		6	2
70	2025-09-24 20:42:37.432706+03	7	ывсыв	1	[{"added": {}}]	6	2
71	2025-09-24 21:11:23.966306+03	3	dfsdfsd	1	[{"added": {}}]	8	2
72	2025-09-24 21:11:33.19293+03	3	xdvsdf	2	[{"changed": {"fields": ["Name"]}}]	8	2
73	2025-09-24 21:37:01.154694+03	5	Мария Панкова	1	[{"added": {}}]	19	3
74	2025-09-24 21:38:08.554832+03	5	Мария Панкова	2	[{"changed": {"fields": ["Email"]}}]	19	3
75	2025-09-24 21:39:00.211486+03	6	Виктория Дроздова	1	[{"added": {}}]	19	3
76	2025-09-24 21:44:19.803957+03	6	Виктория Дроздова	2	[{"changed": {"fields": ["Email"]}}]	19	3
77	2025-09-24 23:25:30.350502+03	7	ывсыв	3		6	2
78	2025-09-24 23:25:30.350544+03	5	ыввыы	3		6	2
79	2025-09-24 23:26:49.028295+03	3	ыаыва	1	[{"added": {}}]	7	2
80	2025-09-24 23:26:53.953483+03	3	ыаыва	3		7	2
81	2025-09-24 23:26:59.426555+03	7	ывсыв	3		6	2
82	2025-09-24 23:27:02.585564+03	5	ыввыы	3		6	2
83	2025-09-24 23:27:47.932177+03	5	ыввыы	3		6	2
84	2025-09-24 23:27:51.983408+03	7	ывсыв	3		6	2
85	2025-09-24 23:30:32.689892+03	7	ывсыв	3		6	2
86	2025-09-25 01:10:28.848716+03	7	ывсыв	3		6	2
87	2025-09-26 20:42:21.114432+03	46	Order object (46)	2	[{"changed": {"fields": ["Status"]}}]	14	2
88	2025-09-26 20:43:13.329073+03	41	Order object (41)	2	[{"changed": {"fields": ["Status"]}}]	14	2
89	2025-09-26 20:49:18.326151+03	26	Order object (26)	2	[{"changed": {"fields": ["Status"]}}]	14	2
90	2025-09-28 17:33:23.366546+03	2	ProductStock object (2)	2	[{"changed": {"fields": ["Quantity"]}}]	17	2
91	2025-09-28 18:12:14.813213+03	3	ProductStock object (3)	1	[{"added": {}}]	17	2
92	2025-09-28 20:53:15.159177+03	3	ProductStock object (3)	3		17	3
93	2025-09-28 20:53:37.925971+03	2	ProductStock object (2)	2	[{"changed": {"fields": ["Quantity"]}}]	17	3
96	2025-09-28 21:01:52.449988+03	4	ыава	1	[{"added": {}}]	7	3
97	2025-09-28 21:01:56.718154+03	4	ыава	3		7	3
102	2025-09-28 21:19:42.793893+03	103	Order object (103)	2	[{"changed": {"fields": ["Status"]}}]	14	3
103	2025-09-28 21:24:56.510069+03	106	Order object (106)	2	[{"changed": {"fields": ["Status"]}}]	14	3
104	2025-09-28 22:53:59.666008+03	8	Review object (8)	3		21	3
105	2025-09-28 23:31:59.100104+03	7	Review object (7)	3		21	3
106	2025-09-29 18:05:00.213722+03	4	ProductStock object (4)	1	[{"added": {}}]	17	2
107	2025-09-29 21:51:54.772409+03	4	ProductStock object (4)	3		17	2
108	2025-09-29 21:52:04.515701+03	5	ProductStock object (5)	1	[{"added": {}}]	17	2
109	2025-10-08 22:06:52.319234+03	121	Order object (121)	2	[{"changed": {"fields": ["\\u0421\\u0442\\u0430\\u0442\\u0443\\u0441"]}}]	14	2
110	2025-10-08 22:54:48.481484+03	3	ProductPurpose object (3)	1	[{"added": {}}]	18	2
111	2025-10-13 11:06:31.349003+03	2	ProductStock object (2)	2	[{"changed": {"fields": ["\\u041a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u043e"]}}]	17	2
112	2025-10-14 15:12:11.830546+03	120	Order object (120)	2	[{"changed": {"fields": ["\\u0421\\u0442\\u0430\\u0442\\u0443\\u0441"]}}]	14	2
113	2025-10-14 15:12:48.375186+03	121	Order object (121)	2	[{"changed": {"fields": ["\\u0421\\u0442\\u0430\\u0442\\u0443\\u0441"]}}]	14	2
114	2025-10-14 15:13:50.842178+03	118	Order object (118)	2	[{"changed": {"fields": ["\\u0421\\u0442\\u0430\\u0442\\u0443\\u0441"]}}]	14	2
115	2025-10-14 15:16:36.931807+03	92	Order object (92)	2	[{"changed": {"fields": ["\\u0421\\u0442\\u0430\\u0442\\u0443\\u0441"]}}]	14	2
116	2025-10-14 15:16:59.414724+03	93	Order object (93)	2	[{"changed": {"fields": ["\\u0421\\u0442\\u0430\\u0442\\u0443\\u0441"]}}]	14	2
119	2025-10-14 15:38:13.011765+03	121	Order object (121)	2	[{"changed": {"fields": ["\\u0421\\u0442\\u0430\\u0442\\u0443\\u0441"]}}]	14	2
120	2025-10-14 21:30:34.537897+03	1	ProductStock object (1)	2	[{"changed": {"fields": ["\\u041a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u043e"]}}]	17	2
121	2025-10-18 12:24:12.570161+03	3	корм	1	[{"added": {}}, {"added": {"name": "\\u041d\\u0430\\u0437\\u043d\\u0430\\u0447\\u0435\\u043d\\u0438\\u0435 \\u0442\\u043e\\u0432\\u0430\\u0440\\u0430", "object": "ProductPurpose object (4)"}}]	15	2
122	2025-10-18 12:25:14.023459+03	1	Корм для кошек Grandorf 2кг ягненок с индейкой	2	[]	15	2
123	2025-10-18 12:28:26.896772+03	1	Корм для кошек Grandorf 2кг ягненок с индейкой	2	[{"deleted": {"name": "\\u041d\\u0430\\u0437\\u043d\\u0430\\u0447\\u0435\\u043d\\u0438\\u0435 \\u0442\\u043e\\u0432\\u0430\\u0440\\u0430", "object": "ProductPurpose object (None)"}}]	15	2
124	2025-10-18 12:28:37.475687+03	3	корм	2	[{"changed": {"name": "\\u041d\\u0430\\u0437\\u043d\\u0430\\u0447\\u0435\\u043d\\u0438\\u0435 \\u0442\\u043e\\u0432\\u0430\\u0440\\u0430", "object": "ProductPurpose object (4)", "fields": ["\\u041d\\u0430\\u0437\\u043d\\u0430\\u0447\\u0435\\u043d\\u0438\\u0435"]}}]	15	2
125	2025-10-18 12:29:08.133547+03	4	пкуп	1	[{"added": {}}, {"added": {"name": "\\u041d\\u0430\\u0437\\u043d\\u0430\\u0447\\u0435\\u043d\\u0438\\u0435 \\u0442\\u043e\\u0432\\u0430\\u0440\\u0430", "object": "ProductPurpose object (5)"}}]	15	2
126	2025-10-18 12:29:17.989523+03	4	пкуп	2	[{"changed": {"name": "\\u041d\\u0430\\u0437\\u043d\\u0430\\u0447\\u0435\\u043d\\u0438\\u0435 \\u0442\\u043e\\u0432\\u0430\\u0440\\u0430", "object": "ProductPurpose object (5)", "fields": ["\\u041d\\u0430\\u0437\\u043d\\u0430\\u0447\\u0435\\u043d\\u0438\\u0435"]}}]	15	2
127	2025-10-18 12:30:03.375273+03	6	ProductStock object (6)	1	[{"added": {}}]	17	2
128	2025-10-18 12:30:11.40633+03	7	ProductStock object (7)	1	[{"added": {}}]	17	2
129	2025-10-18 12:31:05.146964+03	4	пкуп	2	[{"changed": {"fields": ["\\u0418\\u0437\\u043e\\u0431\\u0440\\u0430\\u0436\\u0435\\u043d\\u0438\\u0435"]}}]	15	2
130	2025-10-18 12:31:11.294743+03	3	корм	2	[{"changed": {"fields": ["\\u0418\\u0437\\u043e\\u0431\\u0440\\u0430\\u0436\\u0435\\u043d\\u0438\\u0435"]}}]	15	2
182	2025-11-05 11:57:20.036822+03	11	ProductStock object (11)	1	[{"added": {}}]	17	2
131	2025-10-18 12:31:48.170556+03	5	авпрорл	1	[{"added": {}}, {"added": {"name": "\\u041d\\u0430\\u0437\\u043d\\u0430\\u0447\\u0435\\u043d\\u0438\\u0435 \\u0442\\u043e\\u0432\\u0430\\u0440\\u0430", "object": "ProductPurpose object (6)"}}]	15	2
132	2025-10-18 12:31:56.871984+03	8	ProductStock object (8)	1	[{"added": {}}]	17	2
133	2025-10-18 13:32:34.927046+03	1	Корм для кошек Grandorf 2кг ягненок с индейкой	2	[{"changed": {"fields": ["\\u0426\\u0435\\u043d\\u0430"]}}]	15	2
134	2025-10-18 13:32:51.841534+03	1	Корм для кошек Grandorf 2кг ягненок с индейкой	2	[{"changed": {"fields": ["\\u0426\\u0435\\u043d\\u0430"]}}]	15	2
135	2025-10-18 13:40:06.382483+03	5	авпрорл	3		15	2
136	2025-10-18 13:42:23.208175+03	6	цуакуп	1	[{"added": {}}, {"added": {"name": "\\u041d\\u0430\\u0437\\u043d\\u0430\\u0447\\u0435\\u043d\\u0438\\u0435 \\u0442\\u043e\\u0432\\u0430\\u0440\\u0430", "object": "ProductPurpose object (7)"}}]	15	2
137	2025-10-18 13:42:33.153081+03	9	ProductStock object (9)	1	[{"added": {}}]	17	2
138	2025-10-18 13:56:41.86286+03	7	цуекн	1	[{"added": {}}, {"added": {"name": "\\u041d\\u0430\\u0437\\u043d\\u0430\\u0447\\u0435\\u043d\\u0438\\u0435 \\u0442\\u043e\\u0432\\u0430\\u0440\\u0430", "object": "ProductPurpose object (8)"}}]	15	2
139	2025-10-18 13:56:52.795302+03	10	ProductStock object (10)	1	[{"added": {}}]	17	2
140	2025-10-18 13:57:19.784684+03	7	цуекн	3		15	2
141	2025-10-18 14:19:53.72007+03	4	пкуп	2	[{"changed": {"fields": ["\\u041e\\u0441\\u0442\\u0430\\u0442\\u043e\\u043a"]}}]	15	2
142	2025-10-18 14:20:08.821788+03	7	ProductStock object (7)	2	[{"changed": {"fields": ["\\u041a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u043e"]}}]	17	2
143	2025-10-18 14:20:58.292319+03	7	ProductStock object (7)	2	[{"changed": {"fields": ["\\u041a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u043e"]}}]	17	2
144	2025-10-18 14:21:54.052622+03	7	ProductStock object (7)	2	[{"changed": {"fields": ["\\u041a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u043e"]}}]	17	2
145	2025-10-18 14:22:42.124954+03	7	ProductStock object (7)	2	[{"changed": {"fields": ["\\u041a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u043e"]}}]	17	2
146	2025-10-18 14:25:45.109709+03	7	ProductStock object (7)	2	[{"changed": {"fields": ["\\u041a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u043e"]}}]	17	2
147	2025-10-18 14:36:49.86923+03	7	ProductStock object (7)	2	[{"changed": {"fields": ["\\u041a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u043e"]}}]	17	2
148	2025-10-18 14:47:58.78665+03	7	ProductStock object (7)	2	[{"changed": {"fields": ["\\u041a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u043e"]}}]	17	2
149	2025-10-18 14:48:31.055661+03	7	ProductStock object (7)	2	[{"changed": {"fields": ["\\u041a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u043e"]}}]	17	2
150	2025-10-18 14:51:52.213546+03	7	ProductStock object (7)	2	[{"changed": {"fields": ["\\u041a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u043e"]}}]	17	2
151	2025-10-18 15:10:30.575408+03	7	ProductStock object (7)	2	[{"changed": {"fields": ["\\u041a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u043e"]}}]	17	2
152	2025-10-18 15:32:53.040153+03	7	ProductStock object (7)	2	[{"changed": {"fields": ["\\u041a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u043e"]}}]	17	2
153	2025-10-18 15:37:37.124813+03	7	ProductStock object (7)	2	[{"changed": {"fields": ["\\u041a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u043e"]}}]	17	2
154	2025-10-21 09:02:32.337656+03	5	ProductStock object (5)	2	[{"changed": {"fields": ["\\u041a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u043e"]}}]	17	2
155	2025-10-21 09:10:43.510915+03	5	ProductStock object (5)	2	[{"changed": {"fields": ["\\u041a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u043e"]}}]	17	2
156	2025-10-21 09:12:36.797391+03	5	ProductStock object (5)	2	[{"changed": {"fields": ["\\u041a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u043e"]}}]	17	2
157	2025-10-21 09:19:37.287421+03	5	ProductStock object (5)	2	[{"changed": {"fields": ["\\u041a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u043e"]}}]	17	2
158	2025-10-21 09:25:07.475634+03	5	ProductStock object (5)	2	[{"changed": {"fields": ["\\u041a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u043e"]}}]	17	2
159	2025-10-22 22:05:11.930119+03	8	seller999@example.com	3		19	2
160	2025-10-22 23:11:57.023605+03	2	kspankova13@gmail.com	2	[{"changed": {"fields": ["Superuser status"]}}]	19	2
161	2025-10-22 23:16:16.697769+03	12	valeriya@example.com	2	[{"changed": {"fields": ["\\u041f\\u0435\\u0440\\u0441\\u043e\\u043d\\u0430\\u043b"]}}]	19	2
162	2025-10-22 23:16:21.719326+03	6	seller1010@example.com	2	[{"changed": {"fields": ["\\u041f\\u0435\\u0440\\u0441\\u043e\\u043d\\u0430\\u043b"]}}]	19	2
163	2025-10-22 23:16:29.738938+03	5	seller001@example.com	2	[{"changed": {"fields": ["\\u041f\\u0435\\u0440\\u0441\\u043e\\u043d\\u0430\\u043b"]}}]	19	2
164	2025-10-22 23:16:36.965864+03	3	isip_k.a.pankova@mpt.ru	2	[{"changed": {"fields": ["\\u041f\\u0435\\u0440\\u0441\\u043e\\u043d\\u0430\\u043b"]}}]	19	2
165	2025-10-22 23:16:50.600955+03	3	isip_k.a.pankova@mpt.ru	2	[{"changed": {"fields": ["\\u041f\\u0435\\u0440\\u0441\\u043e\\u043d\\u0430\\u043b"]}}]	19	2
166	2025-10-26 00:26:09.221933+03	4	пкуп	2	[{"changed": {"fields": ["\\u041a\\u0430\\u0442\\u0435\\u0433\\u043e\\u0440\\u0438\\u044f"]}}]	15	2
167	2025-10-26 00:26:41.040354+03	4	пкуп	2	[{"changed": {"fields": ["\\u041a\\u0430\\u0442\\u0435\\u0433\\u043e\\u0440\\u0438\\u044f"]}}]	15	2
168	2025-10-26 00:26:51.228794+03	3	xdvsdf	3		8	2
169	2025-10-26 00:30:57.681629+03	4	уакпк	1	[{"added": {}}]	8	2
170	2025-10-26 00:31:04.432045+03	4	пкуп	2	[{"changed": {"fields": ["\\u041a\\u0430\\u0442\\u0435\\u0433\\u043e\\u0440\\u0438\\u044f"]}}]	15	2
173	2025-11-01 17:07:48.976017+03	19	kuznetsova@example.com	3		19	2
174	2025-11-01 18:06:15.690213+03	4	Order object (4)	2	[{"changed": {"fields": ["\\u0421\\u0442\\u0430\\u0442\\u0443\\u0441"]}}]	14	2
175	2025-11-01 18:06:20.289394+03	3	Order object (3)	2	[{"changed": {"fields": ["\\u0421\\u0442\\u0430\\u0442\\u0443\\u0441"]}}]	14	2
176	2025-11-01 18:06:23.479655+03	2	Order object (2)	2	[{"changed": {"fields": ["\\u0421\\u0442\\u0430\\u0442\\u0443\\u0441"]}}]	14	2
177	2025-11-02 13:55:42.42123+03	8	ыфвуаквпенг	1	[{"added": {}}, {"added": {"name": "\\u041d\\u0430\\u0437\\u043d\\u0430\\u0447\\u0435\\u043d\\u0438\\u0435 \\u0442\\u043e\\u0432\\u0430\\u0440\\u0430", "object": "ProductPurpose object (9)"}}]	15	2
178	2025-11-02 13:56:06.046377+03	8	ыфвуаквпенг	3		15	2
179	2025-11-05 10:13:37.091241+03	1	ProductStock object (1)	2	[{"changed": {"fields": ["\\u041a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u043e"]}}]	17	2
180	2025-11-05 10:14:36.355822+03	134	Order object (134)	2	[{"changed": {"fields": ["\\u0421\\u0442\\u0430\\u0442\\u0443\\u0441"]}}]	14	2
181	2025-11-05 11:57:00.552276+03	9	adsdgtfyh	1	[{"added": {}}, {"added": {"name": "\\u041d\\u0430\\u0437\\u043d\\u0430\\u0447\\u0435\\u043d\\u0438\\u0435 \\u0442\\u043e\\u0432\\u0430\\u0440\\u0430", "object": "ProductPurpose object (10)"}}]	15	2
183	2025-11-06 11:35:47.580221+03	130	Order object (130)	2	[{"changed": {"fields": ["\\u0421\\u0442\\u0430\\u0442\\u0443\\u0441"]}}]	14	2
184	2025-11-06 11:36:58.339664+03	130	Order object (130)	2	[]	14	2
185	2025-11-06 11:53:53.081678+03	136	Order object (136)	2	[{"changed": {"fields": ["\\u0421\\u0442\\u0430\\u0442\\u0443\\u0441"]}}]	14	2
186	2025-11-06 12:37:11.064067+03	9	adsdgtfyh	3		15	2
187	2025-11-06 12:37:40.348544+03	9	adsdgtfyh	3		15	2
188	2025-11-06 22:01:29.67578+03	5	Triol	1	[{"added": {}}]	7	2
189	2025-11-06 22:01:51.420913+03	3	Мягкие игрушки	1	[{"added": {}}]	10	2
190	2025-11-06 22:03:15.193381+03	2	Игрушка для собак мягкая Triol Бобер	2	[{"changed": {"fields": ["\\u0411\\u0440\\u0435\\u043d\\u0434", "\\u0412\\u043e\\u0437\\u0440\\u0430\\u0441\\u0442\\u043d\\u0430\\u044f \\u043a\\u0430\\u0442\\u0435\\u0433\\u043e\\u0440\\u0438\\u044f", "\\u0422\\u0438\\u043f \\u0442\\u043e\\u0432\\u0430\\u0440\\u0430", "\\u041e\\u043f\\u0438\\u0441\\u0430\\u043d\\u0438\\u0435", "\\u0426\\u0435\\u043d\\u0430", "\\u0418\\u0437\\u043e\\u0431\\u0440\\u0430\\u0436\\u0435\\u043d\\u0438\\u0435"]}}, {"deleted": {"name": "\\u041d\\u0430\\u0437\\u043d\\u0430\\u0447\\u0435\\u043d\\u0438\\u0435 \\u0442\\u043e\\u0432\\u0430\\u0440\\u0430", "object": "ProductPurpose object (None)"}}]	15	2
191	2025-11-06 22:04:14.275853+03	5	Маленькие	2	[{"changed": {"fields": ["\\u0412\\u043e\\u0437\\u0440\\u0430\\u0441\\u0442\\u043d\\u0430\\u044f \\u043a\\u0430\\u0442\\u0435\\u0433\\u043e\\u0440\\u0438\\u044f"]}}]	6	2
192	2025-11-06 22:05:01.187819+03	3	Корм для щенков Grandorf 1кг ягненок с индейкой	2	[{"changed": {"fields": ["\\u0412\\u043e\\u0437\\u0440\\u0430\\u0441\\u0442\\u043d\\u0430\\u044f \\u043a\\u0430\\u0442\\u0435\\u0433\\u043e\\u0440\\u0438\\u044f", "\\u0412\\u0438\\u0434", "\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0442\\u043e\\u0432\\u0430\\u0440\\u0430", "\\u041e\\u043f\\u0438\\u0441\\u0430\\u043d\\u0438\\u0435", "\\u0426\\u0435\\u043d\\u0430", "\\u0418\\u0437\\u043e\\u0431\\u0440\\u0430\\u0436\\u0435\\u043d\\u0438\\u0435"]}}]	15	2
193	2025-11-06 22:05:50.185002+03	6	Barbaks	1	[{"added": {}}]	7	2
194	2025-11-06 22:06:16.728149+03	4	Интерактивные ишрушки	1	[{"added": {}}]	10	2
195	2025-11-06 22:06:24.208116+03	4	Интерактивные игрушки	2	[{"changed": {"fields": ["\\u0422\\u0438\\u043f"]}}]	10	2
196	2025-11-06 22:07:14.998702+03	4	Пирамидка для кошек Barbaks Ёлочка-трек	2	[{"changed": {"fields": ["\\u041a\\u0430\\u0442\\u0435\\u0433\\u043e\\u0440\\u0438\\u044f", "\\u0411\\u0440\\u0435\\u043d\\u0434", "\\u0412\\u043e\\u0437\\u0440\\u0430\\u0441\\u0442\\u043d\\u0430\\u044f \\u043a\\u0430\\u0442\\u0435\\u0433\\u043e\\u0440\\u0438\\u044f", "\\u0422\\u0438\\u043f \\u0442\\u043e\\u0432\\u0430\\u0440\\u0430", "\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0442\\u043e\\u0432\\u0430\\u0440\\u0430", "\\u041e\\u043f\\u0438\\u0441\\u0430\\u043d\\u0438\\u0435", "\\u0426\\u0435\\u043d\\u0430", "\\u0418\\u0437\\u043e\\u0431\\u0440\\u0430\\u0436\\u0435\\u043d\\u0438\\u0435"]}}, {"deleted": {"name": "\\u041d\\u0430\\u0437\\u043d\\u0430\\u0447\\u0435\\u043d\\u0438\\u0435 \\u0442\\u043e\\u0432\\u0430\\u0440\\u0430", "object": "ProductPurpose object (None)"}}]	15	2
197	2025-11-06 22:08:32.952544+03	9	Игрушка для кошек Barbaks Окунь Кузьма с кошачьей мятой	2	[{"changed": {"fields": ["\\u0411\\u0440\\u0435\\u043d\\u0434", "\\u0412\\u043e\\u0437\\u0440\\u0430\\u0441\\u0442\\u043d\\u0430\\u044f \\u043a\\u0430\\u0442\\u0435\\u0433\\u043e\\u0440\\u0438\\u044f", "\\u0422\\u0438\\u043f \\u0442\\u043e\\u0432\\u0430\\u0440\\u0430", "\\u0412\\u0438\\u0434", "\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0442\\u043e\\u0432\\u0430\\u0440\\u0430", "\\u041e\\u043f\\u0438\\u0441\\u0430\\u043d\\u0438\\u0435", "\\u0426\\u0435\\u043d\\u0430", "\\u0418\\u0437\\u043e\\u0431\\u0440\\u0430\\u0436\\u0435\\u043d\\u0438\\u0435"]}}, {"deleted": {"name": "\\u041d\\u0430\\u0437\\u043d\\u0430\\u0447\\u0435\\u043d\\u0438\\u0435 \\u0442\\u043e\\u0432\\u0430\\u0440\\u0430", "object": "ProductPurpose object (None)"}}]	15	2
198	2025-11-12 16:47:47.350082+03	142	Order object (142)	2	[{"changed": {"fields": ["\\u0421\\u0442\\u0430\\u0442\\u0443\\u0441"]}}]	14	2
199	2025-11-12 16:59:02.572339+03	143	Order object (143)	2	[{"changed": {"fields": ["\\u0421\\u0442\\u0430\\u0442\\u0443\\u0441"]}}]	14	2
200	2025-11-12 17:35:13.915972+03	29	asdfg@gmail.com	1	[{"added": {}}]	19	2
201	2025-11-12 17:49:41.882034+03	12	ывап	1	[{"added": {}}]	6	2
202	2025-11-12 17:49:45.874233+03	12	ывап	3		6	2
\.


--
-- TOC entry 4019 (class 0 OID 19958)
-- Dependencies: 254
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	admin	logentry
2	auth	permission
3	auth	group
4	contenttypes	contenttype
5	sessions	session
6	petshop	agecategory
7	petshop	brand
8	petshop	category
9	petshop	pickuppoint
10	petshop	producttype
11	petshop	purpose
12	petshop	role
13	petshop	species
14	petshop	order
15	petshop	product
16	petshop	orderitem
17	petshop	productstock
18	petshop	productpurpose
19	petshop	user
20	petshop	testresult
21	petshop	review
22	petshop	cart
23	petshop	userprofile
24	petshop	ordersbybrand
25	petshop	ordersbycategory
26	petshop	ordersbymonth
27	petshop	auditlog
28	reversion	revision
29	reversion	version
\.


--
-- TOC entry 3983 (class 0 OID 19704)
-- Dependencies: 218
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	petshop	0001_initial	2025-09-20 17:29:53.459542+03
2	contenttypes	0001_initial	2025-09-20 17:29:53.463081+03
3	admin	0001_initial	2025-09-20 17:29:53.474901+03
4	admin	0002_logentry_remove_auto_add	2025-09-20 17:29:53.478322+03
5	admin	0003_logentry_add_action_flag_choices	2025-09-20 17:29:53.481238+03
6	contenttypes	0002_remove_content_type_name	2025-09-20 17:29:53.49022+03
7	auth	0001_initial	2025-09-20 17:29:53.526704+03
8	auth	0002_alter_permission_name_max_length	2025-09-20 17:29:53.533724+03
9	auth	0003_alter_user_email_max_length	2025-09-20 17:29:53.536873+03
10	auth	0004_alter_user_username_opts	2025-09-20 17:29:53.539187+03
11	auth	0005_alter_user_last_login_null	2025-09-20 17:29:53.541735+03
12	auth	0006_require_contenttypes_0002	2025-09-20 17:29:53.542346+03
13	auth	0007_alter_validators_add_error_messages	2025-09-20 17:29:53.544841+03
14	auth	0008_alter_user_username_max_length	2025-09-20 17:29:53.546974+03
15	auth	0009_alter_user_last_name_max_length	2025-09-20 17:29:53.548984+03
16	auth	0010_alter_group_name_max_length	2025-09-20 17:29:53.556329+03
17	auth	0011_update_proxy_permissions	2025-09-20 17:29:53.562452+03
18	auth	0012_alter_user_first_name_max_length	2025-09-20 17:29:53.56532+03
19	petshop	0002_user_date_joined_user_groups_user_is_active_and_more	2025-09-20 17:29:53.623935+03
20	sessions	0001_initial	2025-09-20 17:29:53.629918+03
21	petshop	0003_order_email_order_first_name_order_last_name_and_more	2025-09-20 19:15:46.04366+03
22	petshop	0004_rename_date_created_review_created_at_and_more	2025-09-22 18:40:14.275173+03
23	petshop	0005_rename_created_at_review_date_created_and_more	2025-09-22 18:47:20.386416+03
24	petshop	0006_remove_review_order_item_alter_review_rating_and_more	2025-09-22 18:49:26.938277+03
25	petshop	0007_ordersbybrand_ordersbycategory_ordersbymonth_and_more	2025-09-24 17:33:17.994126+03
26	petshop	0008_alter_auditlog_action	2025-09-24 20:05:32.413577+03
27	petshop	0009_alter_auditlog_action	2025-09-24 20:07:37.54636+03
28	reversion	0001_squashed_0004_auto_20160611_1202	2025-10-18 15:30:09.802011+03
29	reversion	0002_add_index_on_version_for_content_type_and_db	2025-10-18 15:30:09.808593+03
30	petshop	0010_alter_agecategory_options_alter_brand_options_and_more	2025-10-21 14:41:42.758378+03
31	petshop	0011_alter_userprofile_date_format	2025-10-21 15:07:50.487318+03
32	petshop	0012_alter_userprofile_date_format	2025-10-21 15:14:15.234443+03
\.


--
-- TOC entry 4032 (class 0 OID 20085)
-- Dependencies: 267
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
0uod1p3pwdcixn84u58ho6yqnyg830yg	.eJxVjEEOwiAQRe_C2hBAoIxL9z0DGYapVA0kpV0Z765NutDtf-_9l4i4rSVunZc4Z3ERRpx-t4T04LqDfMd6a5JaXZc5yV2RB-1ybJmf18P9OyjYy7cmQD_pyemkU4BzZqccgEE7EDvvgh6YVWDARNaQVt5aw0iQPRhSqMT7A-TVN9M:1v3JYJ:hXGMJ4dBHk7mg6AnBQ_0zhA29gHDaflydE0Dba5nH3g	2025-10-13 22:28:51.811895+03
4dowkqslbje4qwl1lm8vxnbqbbg01hux	.eJxVjMsOwiAQRf-FtSEUmAFduvcbyAwPqRqalHZl_HfbpAvd3nPOfYtA61LD2vMcxiQuwojT78YUn7ntID2o3ScZp7bMI8tdkQft8jal_Loe7t9BpV63mtE6F82gFRmOsZCzNgF6r31h4zw4zQYQQWkAVqxQbyqWIUXmM7L4fAHIMzc0:1v14rw:0hToGZjJ1_GzeZbEI2El7DGdCsN8iX2f_c-tHVRc9Yg	2025-10-07 18:23:52.450428+03
w11i5w14raw7m5ru85rgp1rldx6k3oip	e30:1v1TyZ:6YiVuq_VaQy6Pb1gGvD1muvnJrsH5o--CHydt1etN_E	2025-10-08 21:12:23.637598+03
df963wdvbr9fwy2329womuhn20wrnuii	e30:1v1Tyg:JSh28YPU4TR0BRZKirtdds9DfkKmwE9k0gglWcWYPRU	2025-10-08 21:12:30.599625+03
na6r2zzefkmdgrnde4saxh0fcek2xu8m	e30:1v1U0b:nfl4duRNv5IXleUlL5mHXFe17LKDr5d-Ml0kAr5JeqE	2025-10-08 21:14:29.735871+03
1hr9rmu71by4i50nd6boc055p5fvec5u	e30:1v1U5i:4YuFqKbsB80VXrBT4BPRNzJKZbhN03QPHgmbZz8FVLw	2025-10-08 21:19:46.125821+03
3p7scdia3aqe72girwgg2dai7juojokt	e30:1v1U6B:DLhctCw8bFu3POhHW5jPiDyNTLsUdcSE_2EIGBFgf_U	2025-10-08 21:20:15.076982+03
4qwkrtavycurd5db4zn9gn1cscnwbgwg	e30:1v1U6V:CWgJCAAnu-j6H03-tVCHkOKrt029u8Dq7CiEyiiXTSU	2025-10-08 21:20:35.646624+03
p7o75qee7s3up0dchi8syownheht5tw7	e30:1v1UCb:LmkwaWFs-DvJ4UCEs3Eb7lP7E_w7g1DvmdRWZfxVQQs	2025-10-08 21:26:53.788505+03
8zsjgfczou5f26mjqmenlgvbu9j0hpb2	e30:1v1UHK:H9nHPQI2hqXJ-rNumNz3RQtmFjv7X-xK7lDrj-m57Xw	2025-10-08 21:31:46.123805+03
yq6xvoo9h7g03b2462rexkw880aug6ed	e30:1v1UKS:XBohsJXcHbJCPSvYZr1Qv7TFDtAVYmNkCNg7FOCbCNU	2025-10-08 21:35:00.078619+03
pcxpqcpe5tc0joxw6c0bs220l2b3db5o	e30:1v1UKp:WwrjBqbNMJGW69NP3K7BNyGWSClpKav3Kf8-zUQlFsc	2025-10-08 21:35:23.211597+03
e8gnxrq8ykkd5qjol9js632dgr3mj3eg	.eJxVjEEOwiAQRe_C2hBAoIxL9z0DGYapVA0kpV0Z765NutDtf-_9l4i4rSVunZc4Z3ERRpx-t4T04LqDfMd6a5JaXZc5yV2RB-1ybJmf18P9OyjYy7cmQD_pyemkU4BzZqccgEE7EDvvgh6YVWDARNaQVt5aw0iQPRhSqMT7A-TVN9M:1vGvPq:c5sLnt31d8B_6MsntgGX-VpPEKUOZ5WM4Jqgffxnspk	2025-11-20 11:32:22.686866+03
swjbd8um4m70fwh6gj2w0vd2ndyr0ie2	.eJxVjEEOwiAQRe_C2hBAoIxL9z0DGYapVA0kpV0Z765NutDtf-_9l4i4rSVunZc4Z3ERRpx-t4T04LqDfMd6a5JaXZc5yV2RB-1ybJmf18P9OyjYy7cmQD_pyemkU4BzZqccgEE7EDvvgh6YVWDARNaQVt5aw0iQPRhSqMT7A-TVN9M:1vH5CU:LR-2Z_NvUnDlV1a2lNta4GIzJOlMCLVbcCZP0ifqutI	2025-11-20 21:59:14.311983+03
smtrt8vwrt8hckgxbgfzjdf7cmhbtaum	.eJxVjEEOwiAQRe_C2hBAoIxL9z0DGYapVA0kpV0Z765NutDtf-_9l4i4rSVunZc4Z3ERRpx-t4T04LqDfMd6a5JaXZc5yV2RB-1ybJmf18P9OyjYy7cmQD_pyemkU4BzZqccgEE7EDvvgh6YVWDARNaQVt5aw0iQPRhSqMT7A-TVN9M:1vIO5w:NhviFQ5h2J1XFpNLP-w1V1NN2OMun_ZzrIEZXzJvtBA	2025-11-24 12:21:52.272722+03
k09p7fra7gnom4w85qx5refe83110nu3	.eJxVjEEOwiAQRe_C2hBAoIxL9z0DGYapVA0kpV0Z765NutDtf-_9l4i4rSVunZc4Z3ERRpx-t4T04LqDfMd6a5JaXZc5yV2RB-1ybJmf18P9OyjYy7cmQD_pyemkU4BzZqccgEE7EDvvgh6YVWDARNaQVt5aw0iQPRhSqMT7A-TVN9M:1vJ9Ij:iGFS5nt1YoqXHLFNOFYNu_C-s7FURVrMVuZ5kNOL1Zs	2025-11-26 14:46:13.759992+03
t92malqvbgsgny1ki87e9077y84lzlvz	.eJxVjEEOwiAQRe_C2hBAoIxL9z0DGYapVA0kpV0Z765NutDtf-_9l4i4rSVunZc4Z3ERRpx-t4T04LqDfMd6a5JaXZc5yV2RB-1ybJmf18P9OyjYy7cmQD_pyemkU4BzZqccgEE7EDvvgh6YVWDARNaQVt5aw0iQPRhSqMT7A-TVN9M:1vJB3C:8ZY1uSja9LFrvxgx7rRmnaBEplRV2lNcQUHLFpWNhxc	2025-11-26 16:38:18.498586+03
n11ypcvabzofe936j7sm7olx3gpgohj5	.eJxVjEEOwiAQRe_C2hBAoIxL9z0DGYapVA0kpV0Z765NutDtf-_9l4i4rSVunZc4Z3ERRpx-t4T04LqDfMd6a5JaXZc5yV2RB-1ybJmf18P9OyjYy7cmQD_pyemkU4BzZqccgEE7EDvvgh6YVWDARNaQVt5aw0iQPRhSqMT7A-TVN9M:1v8GXK:PH1DXrNVs05ICCUwEIa4pxz7CsgNh8ZPtvJEd8si8QY	2025-10-27 14:16:18.94639+03
1tmcbcn63msdx0bkv14ztauum7xe1eay	.eJxVjEEOwiAQRe_C2hBAoIxL9z0DGYapVA0kpV0Z765NutDtf-_9l4i4rSVunZc4Z3ERRpx-t4T04LqDfMd6a5JaXZc5yV2RB-1ybJmf18P9OyjYy7cmQD_pyemkU4BzZqccgEE7EDvvgh6YVWDARNaQVt5aw0iQPRhSqMT7A-TVN9M:1vClga:m1-D5pd3jBMMXP5XNp4pMGbTHOxVz0EJwfjv2mPLFhU	2025-11-09 00:20:28.884338+03
\.


--
-- TOC entry 3985 (class 0 OID 19712)
-- Dependencies: 220
-- Data for Name: petshop_agecategory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.petshop_agecategory (id, age_name, is_active) FROM stdin;
1	Взрослые	t
2	Пожилые	t
5	Маленькие	t
\.


--
-- TOC entry 4034 (class 0 OID 20187)
-- Dependencies: 272
-- Data for Name: petshop_auditlog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.petshop_auditlog (id, table_name, row_id, action, old_data, new_data, action_time, user_id) FROM stdin;
268	petshop_brand	5	CREATE	\N	{"id": 5, "name": "Triol", "is_active": true}	2025-11-06 22:01:29.622779+03	2
283	petshop_user	29	CREATE	\N	{"id": 29, "role": 1, "email": "asdfg@gmail.com", "phone": "+7gfcgf", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$4VuERG5BoDQQQygWKxCKT8$BfBw3vHyOCEEQCcMtteKFx17DdgcRQFokIvmFNmZUjQ=", "is_active": true, "last_name": "аыв", "first_name": "фваывп", "last_login": null, "date_joined": "2025-11-12T14:35:13.663792+00:00", "middle_name": null, "is_superuser": false, "user_permissions": []}	2025-11-12 17:35:13.913258+03	2
246	petshop_user	19	DELETE	{"id": 19, "role": 5, "email": "kuznetsova@example.com", "phone": "89991112233", "groups": [], "is_staff": true, "password": "", "is_active": true, "last_name": "Кузнецова", "first_name": "Екатерина", "last_login": null, "date_joined": "2025-10-22T20:42:33.680257+00:00", "middle_name": "Викторовна", "is_superuser": false, "user_permissions": []}	\N	2025-11-01 17:07:48.987023+03	2
261	petshop_order	136	UPDATE	{"id": 136, "email": "kspankova13@gmail.com", "phone": "+79236783456", "status": "В обработке", "user_id": 2, "last_name": "Белова", "first_name": "Мария", "total_price": 6076.00, "date_created": "2025-11-06T08:53:34.649751+00:00", "date_updated": "2025-11-06T08:53:34.649764+00:00", "order_number": "df19c234928a45b3aea3", "pickup_point_id": 1}	{"id": 136, "email": "kspankova13@gmail.com", "phone": "+79236783456", "status": "Получен", "user_id": 2, "last_name": "Белова", "first_name": "Мария", "total_price": 6076.00, "date_created": "2025-11-06T08:53:34.649751+00:00", "date_updated": "2025-11-06T08:53:53.068477+00:00", "order_number": "df19c234928a45b3aea3", "pickup_point_id": 1}	2025-11-06 11:53:53.064888+03	2
214	petshop_productstock	7	UPDATE	{"id": 7, "quantity": 12, "product_id": 4, "pickup_point_id": 1}	{"id": 7, "quantity": 0, "product_id": 4, "pickup_point_id": 1}	2025-10-18 14:20:08.810859+03	2
269	petshop_producttype	3	CREATE	\N	{"id": 3, "is_active": true, "type_name": "Мягкие игрушки"}	2025-11-06 22:01:51.411228+03	2
25	petshop_productpurpose	2	CREATE	\N	{"id": 2, "product_id": 1, "purpose_id": 1}	2025-09-24 19:54:01.705123+03	\N
40	petshop_agecategory	6	UPDATE	{"id": 6, "age_name": "ыв", "is_active": true}	{"id": 6, "age_name": "23аауа", "is_active": true}	2025-09-24 20:09:15.033376+03	\N
215	petshop_productstock	7	UPDATE	{"id": 7, "quantity": 0, "product_id": 4, "pickup_point_id": 1}	{"id": 7, "quantity": 12, "product_id": 4, "pickup_point_id": 1}	2025-10-18 14:20:58.279638+03	2
68	petshop_agecategory	7	DELETE	{"id": 7, "age_name": "ывсыв", "is_active": true}	\N	2025-09-25 01:10:28.847372+03	2
71	petshop_order	26	UPDATE	{"id": 26, "email": "isip_k.a.pankova@mpt.ru", "phone": "+79236783456", "status": "В обработке", "user_id": 2, "last_name": "Белова", "first_name": "Мария", "total_price": 3038.00, "date_created": "2025-09-20T17:54:43.502745+00:00", "date_updated": "2025-09-20T17:54:43.511082+00:00", "order_number": "ENNHDBJWFW", "pickup_point_id": 1}	{"id": 26, "email": "isip_k.a.pankova@mpt.ru", "phone": "+79236783456", "status": "Получен", "user_id": 2, "last_name": "Белова", "first_name": "Мария", "total_price": 3038.00, "date_created": "2025-09-20T17:54:43.502745+00:00", "date_updated": "2025-09-26T17:49:18.308523+00:00", "order_number": "ENNHDBJWFW", "pickup_point_id": 1}	2025-09-26 20:49:18.267161+03	2
119	petshop_productstock	3	DELETE	{"id": 3, "quantity": 3, "product_id": 2, "pickup_point_id": 1}	\N	2025-09-28 20:53:15.157742+03	3
216	petshop_productstock	7	UPDATE	{"id": 7, "quantity": 12, "product_id": 4, "pickup_point_id": 1}	{"id": 7, "quantity": 0, "product_id": 4, "pickup_point_id": 1}	2025-10-18 14:21:54.039831+03	2
226	petshop_productstock	5	UPDATE	{"id": 5, "quantity": 14, "product_id": 2, "pickup_point_id": 1}	{"id": 5, "quantity": 0, "product_id": 2, "pickup_point_id": 1}	2025-10-21 09:02:32.30214+03	2
227	petshop_productstock	5	UPDATE	{"id": 5, "quantity": 0, "product_id": 2, "pickup_point_id": 1}	{"id": 5, "quantity": 12, "product_id": 2, "pickup_point_id": 1}	2025-10-21 09:10:43.496762+03	2
162	petshop_order	121	UPDATE	{"id": 121, "email": "kspankova13@gmail.com", "phone": "+79236783456", "status": "В обработке", "user_id": 2, "last_name": "Белова", "first_name": "Мария", "total_price": 2333.00, "date_created": "2025-09-29T20:24:58.368336+00:00", "date_updated": "2025-09-29T20:24:58.368352+00:00", "order_number": "a75b65a121c24c418354", "pickup_point_id": 1}	{"id": 121, "email": "kspankova13@gmail.com", "phone": "+79236783456", "status": "В работе", "user_id": 2, "last_name": "Белова", "first_name": "Мария", "total_price": 2333.00, "date_created": "2025-09-29T20:24:58.368336+00:00", "date_updated": "2025-10-08T19:06:52.214424+00:00", "order_number": "a75b65a121c24c418354", "pickup_point_id": 1}	2025-10-08 22:06:52.209573+03	2
72	petshop_productstock	2	UPDATE	{"id": 2, "quantity": 4, "product_id": 1, "pickup_point_id": 2}	{"id": 2, "quantity": 2, "product_id": 1, "pickup_point_id": 2}	2025-09-28 17:33:23.330893+03	2
1	Order	40	UPDATE	{"id": 40, "email": "isip_k.a.pankova@mpt.ru", "phone": "+79236783456", "status": "В обработке", "user_id": 3, "last_name": "Белова", "first_name": "Екатерина", "total_price": 3038.00, "date_created": "2025-09-23T18:30:46.153471+00:00", "date_updated": "2025-09-23T18:30:46.158417+00:00", "order_number": "ZCTRLOTLLY", "pickup_point_id": 1}	{"id": 40, "email": "isip_k.a.pankova@mpt.ru", "phone": "+79236783456", "status": "В работе", "user_id": 3, "last_name": "Белова", "first_name": "Екатерина", "total_price": 3038.00, "date_created": "2025-09-23T18:30:46.153471+00:00", "date_updated": "2025-09-24T14:55:33.445194+00:00", "order_number": "ZCTRLOTLLY", "pickup_point_id": 1}	2025-09-24 17:55:33.439005+03	\N
2	petshop_agecategory	3	UPDATE	{"id": 3, "age_name": "dfgdfgdf", "is_active": true}	{"id": 3, "age_name": "ыыввыыв", "is_active": true}	2025-09-24 18:40:51.741244+03	\N
41	petshop_agecategory	6	UPDATE	{"id": 6, "age_name": "23аауа", "is_active": true}	{"id": 6, "age_name": "23аауа", "is_active": true}	2025-09-24 20:09:15.033376+03	2
70	petshop_order	41	UPDATE	{"id": 41, "email": "isip_k.a.pankova@mpt.ru", "phone": "+79236783456", "status": "В обработке", "user_id": 2, "last_name": "Воронов", "first_name": "Ксения", "total_price": 2000.00, "date_created": "2025-09-24T16:03:06.727548+00:00", "date_updated": "2025-09-24T16:03:06.727566+00:00", "order_number": "2MIN62BLCW", "pickup_point_id": 1}	{"id": 41, "email": "isip_k.a.pankova@mpt.ru", "phone": "+79236783456", "status": "Получен", "user_id": 2, "last_name": "Воронов", "first_name": "Ксения", "total_price": 2000.00, "date_created": "2025-09-24T16:03:06.727548+00:00", "date_updated": "2025-09-26T17:43:13.319196+00:00", "order_number": "2MIN62BLCW", "pickup_point_id": 1}	2025-09-26 20:43:13.31137+03	2
73	petshop_productstock	3	CREATE	\N	{"id": 3, "quantity": 3, "product_id": 2, "pickup_point_id": 1}	2025-09-28 18:12:14.794823+03	2
247	petshop_order	4	UPDATE	{"id": 4, "email": "isip_k.a.pankova@mpt.ru", "phone": "+79236783456", "status": "new", "user_id": 3, "last_name": "Белова", "first_name": "Мария", "total_price": 6076.00, "date_created": "2025-09-20T16:19:37.084431+00:00", "date_updated": "2025-09-20T16:19:37.090687+00:00", "order_number": "XJ7BPXJUHY", "pickup_point_id": 1}	{"id": 4, "email": "isip_k.a.pankova@mpt.ru", "phone": "+79236783456", "status": "В обработке", "user_id": 3, "last_name": "Белова", "first_name": "Мария", "total_price": 6076.00, "date_created": "2025-09-20T16:19:37.084431+00:00", "date_updated": "2025-11-01T15:06:15.579155+00:00", "order_number": "XJ7BPXJUHY", "pickup_point_id": 1}	2025-11-01 18:06:15.574467+03	2
248	petshop_order	3	UPDATE	{"id": 3, "email": "kspankova13@gmail.com", "phone": null, "status": "new", "user_id": 2, "last_name": "Панкова", "first_name": "Ксения", "total_price": 18228.00, "date_created": "2025-09-20T16:18:57.560558+00:00", "date_updated": "2025-09-20T16:18:57.567711+00:00", "order_number": "U4WUW8LK41", "pickup_point_id": 1}	{"id": 3, "email": "kspankova13@gmail.com", "phone": null, "status": "В обработке", "user_id": 2, "last_name": "Панкова", "first_name": "Ксения", "total_price": 18228.00, "date_created": "2025-09-20T16:18:57.560558+00:00", "date_updated": "2025-11-01T15:06:20.283468+00:00", "order_number": "U4WUW8LK41", "pickup_point_id": 1}	2025-11-01 18:06:20.280818+03	2
270	petshop_product	2	UPDATE	{"id": 2, "name": "Игрушка для собак мягкая Triol Бобер", "image": "игрушка.png", "price": 2333.00, "stock": 47, "brand_id": 1, "is_active": true, "species_id": 1, "category_id": 2, "description": "sdvsdf", "age_category_id": 1, "product_type_id": 1}	{"id": 2, "name": "Игрушка для собак мягкая Triol Бобер", "image": "Снимок_экрана_2025-11-06_в_22.03.00.png", "price": 515.00, "stock": 47, "brand_id": 5, "is_active": true, "species_id": 1, "category_id": 2, "description": "Мягкая игрушка для собак \\"Бобёр\\" с двумя пищалками внутри. Собаки любят трепать и грызть мягкие игрушки, ведь их легко носить в зубах и кусать. Кроме того, такую реалистичную игрушку можно использовать для дрессировки и натаски собак.", "age_category_id": null, "product_type_id": 3}	2025-11-06 22:03:15.095372+03	2
163	petshop_order	121	UPDATE	{"id": 121, "email": "kspankova13@gmail.com", "phone": "+79236783456", "status": "В работе", "user_id": 2, "last_name": "Белова", "first_name": "Мария", "total_price": 2333.00, "date_created": "2025-09-29T20:24:58.368336+00:00", "date_updated": "2025-10-08T19:06:52.214424+00:00", "order_number": "a75b65a121c24c418354", "pickup_point_id": 1}	{"id": 121, "email": "kspankova13@gmail.com", "phone": "+79236783456", "status": "Получен", "user_id": 2, "last_name": "Белова", "first_name": "Мария", "total_price": 2333.00, "date_created": "2025-09-29T20:24:58.368336+00:00", "date_updated": "2025-10-08T19:07:59.103695+00:00", "order_number": "a75b65a121c24c418354", "pickup_point_id": 1}	2025-10-08 22:07:59.101969+03	0
170	petshop_order	93	UPDATE	{"id": 93, "email": "isip_k.a.pankova@mpt.ru", "phone": "+79236783456", "status": "В обработке", "user_id": 3, "last_name": "Белова", "first_name": "Екатерина", "total_price": 3038.00, "date_created": "2025-09-28T16:35:10.725245+00:00", "date_updated": "2025-09-28T16:35:10.725253+00:00", "order_number": "017f0f8252fe4b959f32", "pickup_point_id": 1}	{"id": 93, "email": "isip_k.a.pankova@mpt.ru", "phone": "+79236783456", "status": "В работе", "user_id": 3, "last_name": "Белова", "first_name": "Екатерина", "total_price": 3038.00, "date_created": "2025-09-28T16:35:10.725245+00:00", "date_updated": "2025-10-14T12:16:59.40481+00:00", "order_number": "017f0f8252fe4b959f32", "pickup_point_id": 1}	2025-10-14 15:16:59.401219+03	2
184	petshop_product	1	UPDATE	{"id": 1, "name": "Корм для кошек Grandorf 2кг ягненок с индейкой", "image": "корм_9a3F2cJ.png", "price": 3038.00, "stock": 9, "brand_id": 2, "is_active": true, "species_id": 2, "category_id": 1, "description": "Состав:\\r\\n\\r\\nДегидрированное мясо ягненка (23%), Дегидрированное мясо индейки (22%), Цельнозерновой коричневый рис, Свежее мясо ягненка (8%), Свежее мясо индейки (8%), Жир индейки (7%), Порошок корней цикория (натуральный источник пребиотиков: ФОС и инулина), Свежее масло лосося (1%), Сушеный антарктический криль (натуральный источник ЭПК и ДГК, 1%), Пивные дрожжи (натуральный источник МОС), Растительная клетчатка, Сушеная клюква, Юкка Мохаве. Кроме заявленных в составе животных ингредиентов продукт может содержать следы ДНК других ингредиентов животного или растительного происхождения в незначительных количествах из-за технологических особенностей производства кормов.\\r\\n\\r\\nАналитические составляющие: Сырой протеин: 34%; Сырая клетчатка: 2,5%; Сырой жир: 22%; Сырая зола: 7,5%; Влажность: 6%; Кальций: 1,2%; Фосфор: 1%; Магний: 0,09%; Омега 6 жирные кислоты: 3,7%; Омега 3 жирные кислоты: 0,8%.\\r\\n\\r\\nМетаболизируемая энергия: 4490 ккал/кг.\\r\\n\\r\\nДобавки/кг: Пищевые добавки: Витамин А (3a672a): 20000 МЕ/кг; Витамин D3 (3a671): 1500 МЕ/кг; Витамин Е (3a700): 600 мг/кг; L-карнитин (3a910): 50 мг/кг; Медь (3b405): 5,0 мг/кг; Цинк (3b605): 100 мг/кг; Марганец (3b503): 15 мг/кг; Йод (3b202): 1,5 мг/кг; Селен (3b801): 0,2 мг/кг; Таурин (3a370): 1500 мг/кг.\\r\\n\\r\\nТехнологические добавки: Антиоксидант: богатые токоферолом экстракты из растительных масел 1000 мг/кг.", "age_category_id": 1, "product_type_id": 2}	{"id": 1, "name": "Корм для кошек Grandorf 2кг ягненок с индейкой", "image": "корм_9a3F2cJ.png", "price": 3038.00, "stock": 9, "brand_id": 2, "is_active": true, "species_id": 2, "category_id": 1, "description": "Состав:\\r\\n\\r\\nДегидрированное мясо ягненка (23%), Дегидрированное мясо индейки (22%), Цельнозерновой коричневый рис, Свежее мясо ягненка (8%), Свежее мясо индейки (8%), Жир индейки (7%), Порошок корней цикория (натуральный источник пребиотиков: ФОС и инулина), Свежее масло лосося (1%), Сушеный антарктический криль (натуральный источник ЭПК и ДГК, 1%), Пивные дрожжи (натуральный источник МОС), Растительная клетчатка, Сушеная клюква, Юкка Мохаве. Кроме заявленных в составе животных ингредиентов продукт может содержать следы ДНК других ингредиентов животного или растительного происхождения в незначительных количествах из-за технологических особенностей производства кормов.\\r\\n\\r\\nАналитические составляющие: Сырой протеин: 34%; Сырая клетчатка: 2,5%; Сырой жир: 22%; Сырая зола: 7,5%; Влажность: 6%; Кальций: 1,2%; Фосфор: 1%; Магний: 0,09%; Омега 6 жирные кислоты: 3,7%; Омега 3 жирные кислоты: 0,8%.\\r\\n\\r\\nМетаболизируемая энергия: 4490 ккал/кг.\\r\\n\\r\\nДобавки/кг: Пищевые добавки: Витамин А (3a672a): 20000 МЕ/кг; Витамин D3 (3a671): 1500 МЕ/кг; Витамин Е (3a700): 600 мг/кг; L-карнитин (3a910): 50 мг/кг; Медь (3b405): 5,0 мг/кг; Цинк (3b605): 100 мг/кг; Марганец (3b503): 15 мг/кг; Йод (3b202): 1,5 мг/кг; Селен (3b801): 0,2 мг/кг; Таурин (3a370): 1500 мг/кг.\\r\\n\\r\\nТехнологические добавки: Антиоксидант: богатые токоферолом экстракты из растительных масел 1000 мг/кг.", "age_category_id": 1, "product_type_id": 2}	2025-10-18 12:28:26.866065+03	2
185	petshop_productpurpose	2	DELETE	{"id": 2, "product_id": 1, "purpose_id": 1}	\N	2025-10-18 12:28:26.866065+03	2
69	petshop_order	46	UPDATE	{"id": 46, "email": "kspankova13@gmail.com", "phone": "+79236783456", "status": "Завершён", "user_id": 2, "last_name": "Воронов", "first_name": "Ксюша", "total_price": 3456.01, "date_created": "2025-09-24T16:19:22.974287+00:00", "date_updated": "2025-09-24T16:19:55.320683+00:00", "order_number": "ZCTRLOTLLQ", "pickup_point_id": 2}	{"id": 46, "email": "kspankova13@gmail.com", "phone": "+79236783456", "status": "Получен", "user_id": 2, "last_name": "Воронов", "first_name": "Ксюша", "total_price": 3456.01, "date_created": "2025-09-24T16:19:22.974287+00:00", "date_updated": "2025-09-26T17:42:21.027857+00:00", "order_number": "ZCTRLOTLLQ", "pickup_point_id": 2}	2025-09-26 20:42:20.986398+03	2
271	petshop_productpurpose	3	DELETE	{"id": 3, "product_id": 2, "purpose_id": 1}	\N	2025-11-06 22:03:15.095372+03	2
272	petshop_agecategory	5	UPDATE	{"id": 5, "age_name": "ыввыы", "is_active": true}	{"id": 5, "age_name": "Маленькие", "is_active": true}	2025-11-06 22:04:14.262094+03	2
181	petshop_product	1	UPDATE	{"id": 1, "name": "Корм для кошек Grandorf 2кг ягненок с индейкой", "image": "корм_9a3F2cJ.png", "price": 3038.00, "stock": 9, "brand_id": 2, "is_active": true, "species_id": 2, "category_id": 1, "description": "Состав:\\r\\n\\r\\nДегидрированное мясо ягненка (23%), Дегидрированное мясо индейки (22%), Цельнозерновой коричневый рис, Свежее мясо ягненка (8%), Свежее мясо индейки (8%), Жир индейки (7%), Порошок корней цикория (натуральный источник пребиотиков: ФОС и инулина), Свежее масло лосося (1%), Сушеный антарктический криль (натуральный источник ЭПК и ДГК, 1%), Пивные дрожжи (натуральный источник МОС), Растительная клетчатка, Сушеная клюква, Юкка Мохаве. Кроме заявленных в составе животных ингредиентов продукт может содержать следы ДНК других ингредиентов животного или растительного происхождения в незначительных количествах из-за технологических особенностей производства кормов.\\r\\n\\r\\nАналитические составляющие: Сырой протеин: 34%; Сырая клетчатка: 2,5%; Сырой жир: 22%; Сырая зола: 7,5%; Влажность: 6%; Кальций: 1,2%; Фосфор: 1%; Магний: 0,09%; Омега 6 жирные кислоты: 3,7%; Омега 3 жирные кислоты: 0,8%.\\r\\n\\r\\nМетаболизируемая энергия: 4490 ккал/кг.\\r\\n\\r\\nДобавки/кг: Пищевые добавки: Витамин А (3a672a): 20000 МЕ/кг; Витамин D3 (3a671): 1500 МЕ/кг; Витамин Е (3a700): 600 мг/кг; L-карнитин (3a910): 50 мг/кг; Медь (3b405): 5,0 мг/кг; Цинк (3b605): 100 мг/кг; Марганец (3b503): 15 мг/кг; Йод (3b202): 1,5 мг/кг; Селен (3b801): 0,2 мг/кг; Таурин (3a370): 1500 мг/кг.\\r\\n\\r\\nТехнологические добавки: Антиоксидант: богатые токоферолом экстракты из растительных масел 1000 мг/кг.", "age_category_id": 1, "product_type_id": 2}	{"id": 1, "name": "Корм для кошек Grandorf 2кг ягненок с индейкой", "image": "корм_9a3F2cJ.png", "price": 3038.00, "stock": 9, "brand_id": 2, "is_active": true, "species_id": 2, "category_id": 1, "description": "Состав:\\r\\n\\r\\nДегидрированное мясо ягненка (23%), Дегидрированное мясо индейки (22%), Цельнозерновой коричневый рис, Свежее мясо ягненка (8%), Свежее мясо индейки (8%), Жир индейки (7%), Порошок корней цикория (натуральный источник пребиотиков: ФОС и инулина), Свежее масло лосося (1%), Сушеный антарктический криль (натуральный источник ЭПК и ДГК, 1%), Пивные дрожжи (натуральный источник МОС), Растительная клетчатка, Сушеная клюква, Юкка Мохаве. Кроме заявленных в составе животных ингредиентов продукт может содержать следы ДНК других ингредиентов животного или растительного происхождения в незначительных количествах из-за технологических особенностей производства кормов.\\r\\n\\r\\nАналитические составляющие: Сырой протеин: 34%; Сырая клетчатка: 2,5%; Сырой жир: 22%; Сырая зола: 7,5%; Влажность: 6%; Кальций: 1,2%; Фосфор: 1%; Магний: 0,09%; Омега 6 жирные кислоты: 3,7%; Омега 3 жирные кислоты: 0,8%.\\r\\n\\r\\nМетаболизируемая энергия: 4490 ккал/кг.\\r\\n\\r\\nДобавки/кг: Пищевые добавки: Витамин А (3a672a): 20000 МЕ/кг; Витамин D3 (3a671): 1500 МЕ/кг; Витамин Е (3a700): 600 мг/кг; L-карнитин (3a910): 50 мг/кг; Медь (3b405): 5,0 мг/кг; Цинк (3b605): 100 мг/кг; Марганец (3b503): 15 мг/кг; Йод (3b202): 1,5 мг/кг; Селен (3b801): 0,2 мг/кг; Таурин (3a370): 1500 мг/кг.\\r\\n\\r\\nТехнологические добавки: Антиоксидант: богатые токоферолом экстракты из растительных масел 1000 мг/кг.", "age_category_id": 1, "product_type_id": 2}	2025-10-18 12:25:13.995535+03	2
192	petshop_productstock	6	CREATE	\N	{"id": 6, "quantity": 110, "product_id": 3, "pickup_point_id": 1}	2025-10-18 12:30:03.363109+03	2
259	petshop_order	130	UPDATE	{"id": 130, "email": "kspankova13@gmail.com", "phone": "+79236783456", "status": "В обработке", "user_id": 2, "last_name": "Белова", "first_name": "Мария", "total_price": 2333.00, "date_created": "2025-10-18T12:40:37.921923+00:00", "date_updated": "2025-10-18T12:40:37.921935+00:00", "order_number": "97d532ef8a994dd6845c", "pickup_point_id": 1}	{"id": 130, "email": "kspankova13@gmail.com", "phone": "+79236783456", "status": "Получен", "user_id": 2, "last_name": "Белова", "first_name": "Мария", "total_price": 2333.00, "date_created": "2025-10-18T12:40:37.921923+00:00", "date_updated": "2025-11-06T08:35:47.541137+00:00", "order_number": "97d532ef8a994dd6845c", "pickup_point_id": 1}	2025-11-06 11:35:47.537318+03	2
273	petshop_product	3	UPDATE	{"id": 3, "name": "корм", "image": "__9.jpeg", "price": 2000.00, "stock": 12, "brand_id": 2, "is_active": true, "species_id": 2, "category_id": 1, "description": "Состав:\\r\\n\\r\\nДегидрированное мясо ягненка (23%), Дегидрированное мясо индейки (22%), Цельнозерновой коричневый рис, Свежее мясо ягненка (8%), Свежее мясо индейки (8%), Жир индейки (7%), Порошок корней цикория (натуральный источник пребиотиков: ФОС и инулина), Свежее масло лосося (1%), Сушеный антарктический криль (натуральный источник ЭПК и ДГК, 1%), Пивные дрожжи (натуральный источник МОС), Растительная клетчатка, Сушеная клюква, Юкка Мохаве. Кроме заявленных в составе животных ингредиентов продукт может содержать следы ДНК других ингредиентов животного или растительного происхождения в незначительных количествах из-за технологических особенностей производства кормов.\\r\\n\\r\\nАналитические составляющие: Сырой протеин: 34%; Сырая клетчатка: 2,5%; Сырой жир: 22%; Сырая зола: 7,5%; Влажность: 6%; Кальций: 1,2%; Фосфор: 1%; Магний: 0,09%; Омега 6 жирные кислоты: 3,7%; Омега 3 жирные кислоты: 0,8%.\\r\\n\\r\\nМетаболизируемая энергия: 4490 ккал/кг.\\r\\n\\r\\nДобавки/кг: Пищевые добавки: Витамин А (3a672a): 20000 МЕ/кг; Витамин D3 (3a671): 1500 МЕ/кг; Витамин Е (3a700): 600 мг/кг; L-карнитин (3a910): 50 мг/кг; Медь (3b405): 5,0 мг/кг; Цинк (3b605): 100 мг/кг; Марганец (3b503): 15 мг/кг; Йод (3b202): 1,5 мг/кг; Селен (3b801): 0,2 мг/кг; Таурин (3a370): 1500 мг/кг.\\r\\n\\r\\nТехнологические добавки: Антиоксидант: богатые токоферолом экстракты из растительных масел 1000 мг/кг.", "age_category_id": 1, "product_type_id": 2}	{"id": 3, "name": "Корм для щенков Grandorf 1кг ягненок с индейкой", "image": "Снимок_экрана_2025-11-06_в_22.04.52.png", "price": 1350.00, "stock": 12, "brand_id": 2, "is_active": true, "species_id": 1, "category_id": 1, "description": "Состав:\\r\\n\\r\\nДегидрированное мясо ягненка (24%), Дегидрированное мясо индейки (23%), Цельнозерновой коричневый рис, Свежее мясо ягненка (7%), Свежее мясо индейки (7%), Жир индейки (7%), Порошок корней цикория (натуральный источник пребиотиков: ФОС и инулина), Мука из плодов рожкового дерева, Сушеное яблоко, Свежее масло лосося (1%), Сушеный антарктический криль (натуральный источник ЭПК и ДГК, 1%), Пивные дрожжи (натуральный источник МОС), Глюкозамин (1000 мг/кг), Хондроитин сульфат (1000 мг/кг), MSM (метилсульфонилметан, 40 мг/кг), Сушеная клюква, Юкка Мохаве. Кроме заявленных в составе животных ингредиентов продукт может содержать следы ДНК других ингредиентов животного или растительного происхождения в незначительных количествах из-за технологических особенностей производства кормов.", "age_category_id": 5, "product_type_id": 2}	2025-11-06 22:05:01.152923+03	2
288	petshop_agecategory	12	CREATE	\N	{"id": 12, "age_name": "ывап", "is_active": true}	2025-11-12 17:49:41.874292+03	2
199	petshop_product	1	UPDATE	{"id": 1, "name": "Корм для кошек Grandorf 2кг ягненок с индейкой", "image": "корм_9a3F2cJ.png", "price": 3038.00, "stock": 9, "brand_id": 2, "is_active": true, "species_id": 2, "category_id": 1, "description": "Состав:\\r\\n\\r\\nДегидрированное мясо ягненка (23%), Дегидрированное мясо индейки (22%), Цельнозерновой коричневый рис, Свежее мясо ягненка (8%), Свежее мясо индейки (8%), Жир индейки (7%), Порошок корней цикория (натуральный источник пребиотиков: ФОС и инулина), Свежее масло лосося (1%), Сушеный антарктический криль (натуральный источник ЭПК и ДГК, 1%), Пивные дрожжи (натуральный источник МОС), Растительная клетчатка, Сушеная клюква, Юкка Мохаве. Кроме заявленных в составе животных ингредиентов продукт может содержать следы ДНК других ингредиентов животного или растительного происхождения в незначительных количествах из-за технологических особенностей производства кормов.\\r\\n\\r\\nАналитические составляющие: Сырой протеин: 34%; Сырая клетчатка: 2,5%; Сырой жир: 22%; Сырая зола: 7,5%; Влажность: 6%; Кальций: 1,2%; Фосфор: 1%; Магний: 0,09%; Омега 6 жирные кислоты: 3,7%; Омега 3 жирные кислоты: 0,8%.\\r\\n\\r\\nМетаболизируемая энергия: 4490 ккал/кг.\\r\\n\\r\\nДобавки/кг: Пищевые добавки: Витамин А (3a672a): 20000 МЕ/кг; Витамин D3 (3a671): 1500 МЕ/кг; Витамин Е (3a700): 600 мг/кг; L-карнитин (3a910): 50 мг/кг; Медь (3b405): 5,0 мг/кг; Цинк (3b605): 100 мг/кг; Марганец (3b503): 15 мг/кг; Йод (3b202): 1,5 мг/кг; Селен (3b801): 0,2 мг/кг; Таурин (3a370): 1500 мг/кг.\\r\\n\\r\\nТехнологические добавки: Антиоксидант: богатые токоферолом экстракты из растительных масел 1000 мг/кг.", "age_category_id": 1, "product_type_id": 2}	{"id": 1, "name": "Корм для кошек Grandorf 2кг ягненок с индейкой", "image": "корм_9a3F2cJ.png", "price": 3038.50, "stock": 9, "brand_id": 2, "is_active": true, "species_id": 2, "category_id": 1, "description": "Состав:\\r\\n\\r\\nДегидрированное мясо ягненка (23%), Дегидрированное мясо индейки (22%), Цельнозерновой коричневый рис, Свежее мясо ягненка (8%), Свежее мясо индейки (8%), Жир индейки (7%), Порошок корней цикория (натуральный источник пребиотиков: ФОС и инулина), Свежее масло лосося (1%), Сушеный антарктический криль (натуральный источник ЭПК и ДГК, 1%), Пивные дрожжи (натуральный источник МОС), Растительная клетчатка, Сушеная клюква, Юкка Мохаве. Кроме заявленных в составе животных ингредиентов продукт может содержать следы ДНК других ингредиентов животного или растительного происхождения в незначительных количествах из-за технологических особенностей производства кормов.\\r\\n\\r\\nАналитические составляющие: Сырой протеин: 34%; Сырая клетчатка: 2,5%; Сырой жир: 22%; Сырая зола: 7,5%; Влажность: 6%; Кальций: 1,2%; Фосфор: 1%; Магний: 0,09%; Омега 6 жирные кислоты: 3,7%; Омега 3 жирные кислоты: 0,8%.\\r\\n\\r\\nМетаболизируемая энергия: 4490 ккал/кг.\\r\\n\\r\\nДобавки/кг: Пищевые добавки: Витамин А (3a672a): 20000 МЕ/кг; Витамин D3 (3a671): 1500 МЕ/кг; Витамин Е (3a700): 600 мг/кг; L-карнитин (3a910): 50 мг/кг; Медь (3b405): 5,0 мг/кг; Цинк (3b605): 100 мг/кг; Марганец (3b503): 15 мг/кг; Йод (3b202): 1,5 мг/кг; Селен (3b801): 0,2 мг/кг; Таурин (3a370): 1500 мг/кг.\\r\\n\\r\\nТехнологические добавки: Антиоксидант: богатые токоферолом экстракты из растительных масел 1000 мг/кг.", "age_category_id": 1, "product_type_id": 2}	2025-10-18 13:32:34.89258+03	2
249	petshop_order	2	UPDATE	{"id": 2, "email": "isip_k.a.pankova@mpt.ru", "phone": "+79236783456", "status": "new", "user_id": 3, "last_name": "Белова", "first_name": "Мария", "total_price": 3038.00, "date_created": "2025-09-20T16:15:53.867355+00:00", "date_updated": "2025-09-20T16:15:53.886674+00:00", "order_number": "N2HRSJNLF5", "pickup_point_id": 1}	{"id": 2, "email": "isip_k.a.pankova@mpt.ru", "phone": "+79236783456", "status": "В обработке", "user_id": 3, "last_name": "Белова", "first_name": "Мария", "total_price": 3038.00, "date_created": "2025-09-20T16:15:53.867355+00:00", "date_updated": "2025-11-01T15:06:23.461398+00:00", "order_number": "N2HRSJNLF5", "pickup_point_id": 1}	2025-11-01 18:06:23.45938+03	2
133	petshop_productstock	4	DELETE	{"id": 4, "quantity": 5, "product_id": 2, "pickup_point_id": 1}	\N	2025-09-29 21:51:54.771193+03	2
134	petshop_productstock	5	CREATE	\N	{"id": 5, "quantity": 20, "product_id": 2, "pickup_point_id": 1}	2025-09-29 21:52:04.505327+03	2
161	petshop_order	120	UPDATE	{"id": 120, "email": "kspankova13@gmail.com", "phone": "+79236783456", "status": "В обработке", "user_id": 2, "last_name": "Белова", "first_name": "Мария", "total_price": 2333.00, "date_created": "2025-09-29T20:24:33.50781+00:00", "date_updated": "2025-09-29T20:24:33.507823+00:00", "order_number": "828a781018294cc5aae0", "pickup_point_id": 1}	{"id": 120, "email": "kspankova13@gmail.com", "phone": "+79236783456", "status": "Получен", "user_id": 2, "last_name": "Белова", "first_name": "Мария", "total_price": 2333.00, "date_created": "2025-09-29T20:24:33.50781+00:00", "date_updated": "2025-10-07T20:26:31.127406+00:00", "order_number": "828a781018294cc5aae0", "pickup_point_id": 1}	2025-10-07 23:26:31.12488+03	0
217	petshop_productstock	7	UPDATE	{"id": 7, "quantity": 0, "product_id": 4, "pickup_point_id": 1}	{"id": 7, "quantity": 12, "product_id": 4, "pickup_point_id": 1}	2025-10-18 14:22:42.112101+03	2
168	petshop_order	118	UPDATE	{"id": 118, "email": "kspankova13@gmail.com", "phone": "+79236783456", "status": "В обработке", "user_id": 2, "last_name": "Белова", "first_name": "Мария", "total_price": 3038.00, "date_created": "2025-09-29T19:58:29.590309+00:00", "date_updated": "2025-09-29T19:58:29.590323+00:00", "order_number": "97297a3376cd4e2ab5ad", "pickup_point_id": 2}	{"id": 118, "email": "kspankova13@gmail.com", "phone": "+79236783456", "status": "Завершён", "user_id": 2, "last_name": "Белова", "first_name": "Мария", "total_price": 3038.00, "date_created": "2025-09-29T19:58:29.590309+00:00", "date_updated": "2025-10-14T12:13:50.834843+00:00", "order_number": "97297a3376cd4e2ab5ad", "pickup_point_id": 2}	2025-10-14 15:13:50.831316+03	2
274	petshop_brand	6	CREATE	\N	{"id": 6, "name": "Barbaks", "is_active": true}	2025-11-06 22:05:50.168376+03	2
289	petshop_agecategory	12	DELETE	{"id": 12, "age_name": "ывап", "is_active": true}	\N	2025-11-12 17:49:45.87327+03	2
193	petshop_productstock	7	CREATE	\N	{"id": 7, "quantity": 12, "product_id": 4, "pickup_point_id": 1}	2025-10-18 12:30:11.397904+03	2
19	petshop_agecategory	3	DELETE	{"id": 3, "age_name": "121цвцвц", "is_active": true}	\N	2025-09-24 19:45:22.170983+03	2
200	petshop_product	1	UPDATE	{"id": 1, "name": "Корм для кошек Grandorf 2кг ягненок с индейкой", "image": "корм_9a3F2cJ.png", "price": 3038.50, "stock": 9, "brand_id": 2, "is_active": true, "species_id": 2, "category_id": 1, "description": "Состав:\\r\\n\\r\\nДегидрированное мясо ягненка (23%), Дегидрированное мясо индейки (22%), Цельнозерновой коричневый рис, Свежее мясо ягненка (8%), Свежее мясо индейки (8%), Жир индейки (7%), Порошок корней цикория (натуральный источник пребиотиков: ФОС и инулина), Свежее масло лосося (1%), Сушеный антарктический криль (натуральный источник ЭПК и ДГК, 1%), Пивные дрожжи (натуральный источник МОС), Растительная клетчатка, Сушеная клюква, Юкка Мохаве. Кроме заявленных в составе животных ингредиентов продукт может содержать следы ДНК других ингредиентов животного или растительного происхождения в незначительных количествах из-за технологических особенностей производства кормов.\\r\\n\\r\\nАналитические составляющие: Сырой протеин: 34%; Сырая клетчатка: 2,5%; Сырой жир: 22%; Сырая зола: 7,5%; Влажность: 6%; Кальций: 1,2%; Фосфор: 1%; Магний: 0,09%; Омега 6 жирные кислоты: 3,7%; Омега 3 жирные кислоты: 0,8%.\\r\\n\\r\\nМетаболизируемая энергия: 4490 ккал/кг.\\r\\n\\r\\nДобавки/кг: Пищевые добавки: Витамин А (3a672a): 20000 МЕ/кг; Витамин D3 (3a671): 1500 МЕ/кг; Витамин Е (3a700): 600 мг/кг; L-карнитин (3a910): 50 мг/кг; Медь (3b405): 5,0 мг/кг; Цинк (3b605): 100 мг/кг; Марганец (3b503): 15 мг/кг; Йод (3b202): 1,5 мг/кг; Селен (3b801): 0,2 мг/кг; Таурин (3a370): 1500 мг/кг.\\r\\n\\r\\nТехнологические добавки: Антиоксидант: богатые токоферолом экстракты из растительных масел 1000 мг/кг.", "age_category_id": 1, "product_type_id": 2}	{"id": 1, "name": "Корм для кошек Grandorf 2кг ягненок с индейкой", "image": "корм_9a3F2cJ.png", "price": 3038.00, "stock": 9, "brand_id": 2, "is_active": true, "species_id": 2, "category_id": 1, "description": "Состав:\\r\\n\\r\\nДегидрированное мясо ягненка (23%), Дегидрированное мясо индейки (22%), Цельнозерновой коричневый рис, Свежее мясо ягненка (8%), Свежее мясо индейки (8%), Жир индейки (7%), Порошок корней цикория (натуральный источник пребиотиков: ФОС и инулина), Свежее масло лосося (1%), Сушеный антарктический криль (натуральный источник ЭПК и ДГК, 1%), Пивные дрожжи (натуральный источник МОС), Растительная клетчатка, Сушеная клюква, Юкка Мохаве. Кроме заявленных в составе животных ингредиентов продукт может содержать следы ДНК других ингредиентов животного или растительного происхождения в незначительных количествах из-за технологических особенностей производства кормов.\\r\\n\\r\\nАналитические составляющие: Сырой протеин: 34%; Сырая клетчатка: 2,5%; Сырой жир: 22%; Сырая зола: 7,5%; Влажность: 6%; Кальций: 1,2%; Фосфор: 1%; Магний: 0,09%; Омега 6 жирные кислоты: 3,7%; Омега 3 жирные кислоты: 0,8%.\\r\\n\\r\\nМетаболизируемая энергия: 4490 ккал/кг.\\r\\n\\r\\nДобавки/кг: Пищевые добавки: Витамин А (3a672a): 20000 МЕ/кг; Витамин D3 (3a671): 1500 МЕ/кг; Витамин Е (3a700): 600 мг/кг; L-карнитин (3a910): 50 мг/кг; Медь (3b405): 5,0 мг/кг; Цинк (3b605): 100 мг/кг; Марганец (3b503): 15 мг/кг; Йод (3b202): 1,5 мг/кг; Селен (3b801): 0,2 мг/кг; Таурин (3a370): 1500 мг/кг.\\r\\n\\r\\nТехнологические добавки: Антиоксидант: богатые токоферолом экстракты из растительных масел 1000 мг/кг.", "age_category_id": 1, "product_type_id": 2}	2025-10-18 13:32:51.821616+03	2
218	petshop_productstock	7	UPDATE	{"id": 7, "quantity": 12, "product_id": 4, "pickup_point_id": 1}	{"id": 7, "quantity": 0, "product_id": 4, "pickup_point_id": 1}	2025-10-18 14:25:45.0966+03	2
250	petshop_product	8	CREATE	\N	{"id": 8, "name": "ыфвуаквпенг", "image": "photo_2025-11-01_15.18.40.jpeg", "price": 1234.00, "stock": 12, "brand_id": 2, "is_active": true, "species_id": 2, "category_id": 1, "description": "уцкенгш", "age_category_id": 2, "product_type_id": 1}	2025-11-02 13:55:42.28264+03	2
251	petshop_productpurpose	9	CREATE	\N	{"id": 9, "product_id": 8, "purpose_id": 2}	2025-11-02 13:55:42.28264+03	2
252	petshop_productpurpose	9	DELETE	{"id": 9, "product_id": 8, "purpose_id": 2}	\N	2025-11-02 13:56:06.034884+03	2
231	petshop_user	8	DELETE	{"id": 8, "role": 1, "email": "seller999@example.com", "phone": "+71235674534", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$Q51Cbg7aI8oh1cwj6HskPk$r1OY33tZgV5lLgR94e6M5fKLmNteCP99Es1Rn7e9Xsw=", "is_active": true, "last_name": "Иванов", "first_name": "Михаил", "last_login": null, "date_joined": "2025-09-26T15:25:11.703638+00:00", "middle_name": null, "is_superuser": false, "user_permissions": []}	\N	2025-10-22 22:05:11.941141+03	2
242	petshop_product	4	UPDATE	{"id": 4, "name": "пкуп", "image": "__1.jpeg", "price": 23456.00, "stock": 0, "brand_id": 2, "is_active": true, "species_id": 2, "category_id": 3, "description": "вапиаавы", "age_category_id": 1, "product_type_id": 2}	{"id": 4, "name": "пкуп", "image": "__1.jpeg", "price": 23456.00, "stock": 0, "brand_id": 2, "is_active": true, "species_id": 2, "category_id": 1, "description": "вапиаавы", "age_category_id": 1, "product_type_id": 2}	2025-10-26 00:26:41.012237+03	2
164	petshop_productpurpose	3	CREATE	\N	{"id": 3, "product_id": 2, "purpose_id": 1}	2025-10-08 22:54:48.454691+03	2
174	petshop_productstock	1	UPDATE	{"id": 1, "quantity": 0, "product_id": 1, "pickup_point_id": 1}	{"id": 1, "quantity": 1, "product_id": 1, "pickup_point_id": 1}	2025-10-14 21:30:34.512399+03	2
253	petshop_product	8	DELETE	{"id": 8, "name": "ыфвуаквпенг", "image": "photo_2025-11-01_15.18.40.jpeg", "price": 1234.00, "stock": 12, "brand_id": 2, "is_active": true, "species_id": 2, "category_id": 1, "description": "уцкенгш", "age_category_id": 2, "product_type_id": 1}	\N	2025-11-02 13:56:06.034884+03	2
254	petshop_productstock	1	UPDATE	{"id": 1, "quantity": 0, "product_id": 1, "pickup_point_id": 1}	{"id": 1, "quantity": 4, "product_id": 1, "pickup_point_id": 1}	2025-11-05 10:13:37.062073+03	2
175	petshop_product	3	CREATE	\N	{"id": 3, "name": "корм", "image": "", "price": 2000.00, "stock": 12, "brand_id": 2, "is_active": true, "species_id": 2, "category_id": 1, "description": "Состав:\\r\\n\\r\\nДегидрированное мясо ягненка (23%), Дегидрированное мясо индейки (22%), Цельнозерновой коричневый рис, Свежее мясо ягненка (8%), Свежее мясо индейки (8%), Жир индейки (7%), Порошок корней цикория (натуральный источник пребиотиков: ФОС и инулина), Свежее масло лосося (1%), Сушеный антарктический криль (натуральный источник ЭПК и ДГК, 1%), Пивные дрожжи (натуральный источник МОС), Растительная клетчатка, Сушеная клюква, Юкка Мохаве. Кроме заявленных в составе животных ингредиентов продукт может содержать следы ДНК других ингредиентов животного или растительного происхождения в незначительных количествах из-за технологических особенностей производства кормов.\\r\\n\\r\\nАналитические составляющие: Сырой протеин: 34%; Сырая клетчатка: 2,5%; Сырой жир: 22%; Сырая зола: 7,5%; Влажность: 6%; Кальций: 1,2%; Фосфор: 1%; Магний: 0,09%; Омега 6 жирные кислоты: 3,7%; Омега 3 жирные кислоты: 0,8%.\\r\\n\\r\\nМетаболизируемая энергия: 4490 ккал/кг.\\r\\n\\r\\nДобавки/кг: Пищевые добавки: Витамин А (3a672a): 20000 МЕ/кг; Витамин D3 (3a671): 1500 МЕ/кг; Витамин Е (3a700): 600 мг/кг; L-карнитин (3a910): 50 мг/кг; Медь (3b405): 5,0 мг/кг; Цинк (3b605): 100 мг/кг; Марганец (3b503): 15 мг/кг; Йод (3b202): 1,5 мг/кг; Селен (3b801): 0,2 мг/кг; Таурин (3a370): 1500 мг/кг.\\r\\n\\r\\nТехнологические добавки: Антиоксидант: богатые токоферолом экстракты из растительных масел 1000 мг/кг.", "age_category_id": 1, "product_type_id": 2}	2025-10-18 12:24:12.532907+03	2
130	petshop_order	103	UPDATE	{"id": 103, "email": "isip_k.a.pankova@mpt.ru", "phone": "+79236783456", "status": "В обработке", "user_id": 3, "last_name": "Белова", "first_name": "Екатерина", "total_price": 6076.00, "date_created": "2025-09-28T17:42:50.052586+00:00", "date_updated": "2025-09-28T17:42:50.052598+00:00", "order_number": "ebe31a8e4b5a475cb2ca", "pickup_point_id": 2}	{"id": 103, "email": "isip_k.a.pankova@mpt.ru", "phone": "+79236783456", "status": "Получен", "user_id": 3, "last_name": "Белова", "first_name": "Екатерина", "total_price": 6076.00, "date_created": "2025-09-28T17:42:50.052586+00:00", "date_updated": "2025-09-28T18:19:42.784196+00:00", "order_number": "ebe31a8e4b5a475cb2ca", "pickup_point_id": 2}	2025-09-28 21:19:42.745351+03	3
132	petshop_productstock	4	CREATE	\N	{"id": 4, "quantity": 5, "product_id": 2, "pickup_point_id": 1}	2025-09-29 18:05:00.118483+03	2
198	petshop_productstock	8	CREATE	\N	{"id": 8, "quantity": 1324, "product_id": 5, "pickup_point_id": 1}	2025-10-18 12:31:56.862763+03	2
20	petshop_agecategory	3	DELETE	{"id": 3, "age_name": "121цвцвц", "is_active": true}	\N	2025-09-24 19:45:22.170983+03	\N
186	petshop_product	3	UPDATE	{"id": 3, "name": "корм", "image": "", "price": 2000.00, "stock": 12, "brand_id": 2, "is_active": true, "species_id": 2, "category_id": 1, "description": "Состав:\\r\\n\\r\\nДегидрированное мясо ягненка (23%), Дегидрированное мясо индейки (22%), Цельнозерновой коричневый рис, Свежее мясо ягненка (8%), Свежее мясо индейки (8%), Жир индейки (7%), Порошок корней цикория (натуральный источник пребиотиков: ФОС и инулина), Свежее масло лосося (1%), Сушеный антарктический криль (натуральный источник ЭПК и ДГК, 1%), Пивные дрожжи (натуральный источник МОС), Растительная клетчатка, Сушеная клюква, Юкка Мохаве. Кроме заявленных в составе животных ингредиентов продукт может содержать следы ДНК других ингредиентов животного или растительного происхождения в незначительных количествах из-за технологических особенностей производства кормов.\\r\\n\\r\\nАналитические составляющие: Сырой протеин: 34%; Сырая клетчатка: 2,5%; Сырой жир: 22%; Сырая зола: 7,5%; Влажность: 6%; Кальций: 1,2%; Фосфор: 1%; Магний: 0,09%; Омега 6 жирные кислоты: 3,7%; Омега 3 жирные кислоты: 0,8%.\\r\\n\\r\\nМетаболизируемая энергия: 4490 ккал/кг.\\r\\n\\r\\nДобавки/кг: Пищевые добавки: Витамин А (3a672a): 20000 МЕ/кг; Витамин D3 (3a671): 1500 МЕ/кг; Витамин Е (3a700): 600 мг/кг; L-карнитин (3a910): 50 мг/кг; Медь (3b405): 5,0 мг/кг; Цинк (3b605): 100 мг/кг; Марганец (3b503): 15 мг/кг; Йод (3b202): 1,5 мг/кг; Селен (3b801): 0,2 мг/кг; Таурин (3a370): 1500 мг/кг.\\r\\n\\r\\nТехнологические добавки: Антиоксидант: богатые токоферолом экстракты из растительных масел 1000 мг/кг.", "age_category_id": 1, "product_type_id": 2}	{"id": 3, "name": "корм", "image": "", "price": 2000.00, "stock": 12, "brand_id": 2, "is_active": true, "species_id": 2, "category_id": 1, "description": "Состав:\\r\\n\\r\\nДегидрированное мясо ягненка (23%), Дегидрированное мясо индейки (22%), Цельнозерновой коричневый рис, Свежее мясо ягненка (8%), Свежее мясо индейки (8%), Жир индейки (7%), Порошок корней цикория (натуральный источник пребиотиков: ФОС и инулина), Свежее масло лосося (1%), Сушеный антарктический криль (натуральный источник ЭПК и ДГК, 1%), Пивные дрожжи (натуральный источник МОС), Растительная клетчатка, Сушеная клюква, Юкка Мохаве. Кроме заявленных в составе животных ингредиентов продукт может содержать следы ДНК других ингредиентов животного или растительного происхождения в незначительных количествах из-за технологических особенностей производства кормов.\\r\\n\\r\\nАналитические составляющие: Сырой протеин: 34%; Сырая клетчатка: 2,5%; Сырой жир: 22%; Сырая зола: 7,5%; Влажность: 6%; Кальций: 1,2%; Фосфор: 1%; Магний: 0,09%; Омега 6 жирные кислоты: 3,7%; Омега 3 жирные кислоты: 0,8%.\\r\\n\\r\\nМетаболизируемая энергия: 4490 ккал/кг.\\r\\n\\r\\nДобавки/кг: Пищевые добавки: Витамин А (3a672a): 20000 МЕ/кг; Витамин D3 (3a671): 1500 МЕ/кг; Витамин Е (3a700): 600 мг/кг; L-карнитин (3a910): 50 мг/кг; Медь (3b405): 5,0 мг/кг; Цинк (3b605): 100 мг/кг; Марганец (3b503): 15 мг/кг; Йод (3b202): 1,5 мг/кг; Селен (3b801): 0,2 мг/кг; Таурин (3a370): 1500 мг/кг.\\r\\n\\r\\nТехнологические добавки: Антиоксидант: богатые токоферолом экстракты из растительных масел 1000 мг/кг.", "age_category_id": 1, "product_type_id": 2}	2025-10-18 12:28:37.456289+03	2
187	petshop_productpurpose	4	UPDATE	{"id": 4, "product_id": 3, "purpose_id": 2}	{"id": 4, "product_id": 3, "purpose_id": 1}	2025-10-18 12:28:37.456289+03	2
255	petshop_order	134	UPDATE	{"id": 134, "email": "kspankova13@gmail.com", "phone": "+79236783456", "status": "В обработке", "user_id": 2, "last_name": "Белова", "first_name": "Мария", "total_price": 3038.00, "date_created": "2025-11-01T14:09:51.687608+00:00", "date_updated": "2025-11-01T14:09:51.687616+00:00", "order_number": "0d6fa9cc3da24ffca7ad", "pickup_point_id": 2}	{"id": 134, "email": "kspankova13@gmail.com", "phone": "+79236783456", "status": "Получен", "user_id": 2, "last_name": "Белова", "first_name": "Мария", "total_price": 3038.00, "date_created": "2025-11-01T14:09:51.687608+00:00", "date_updated": "2025-11-05T07:14:36.34544+00:00", "order_number": "0d6fa9cc3da24ffca7ad", "pickup_point_id": 2}	2025-11-05 10:14:36.34315+03	2
195	petshop_product	3	UPDATE	{"id": 3, "name": "корм", "image": "", "price": 2000.00, "stock": 12, "brand_id": 2, "is_active": true, "species_id": 2, "category_id": 1, "description": "Состав:\\r\\n\\r\\nДегидрированное мясо ягненка (23%), Дегидрированное мясо индейки (22%), Цельнозерновой коричневый рис, Свежее мясо ягненка (8%), Свежее мясо индейки (8%), Жир индейки (7%), Порошок корней цикория (натуральный источник пребиотиков: ФОС и инулина), Свежее масло лосося (1%), Сушеный антарктический криль (натуральный источник ЭПК и ДГК, 1%), Пивные дрожжи (натуральный источник МОС), Растительная клетчатка, Сушеная клюква, Юкка Мохаве. Кроме заявленных в составе животных ингредиентов продукт может содержать следы ДНК других ингредиентов животного или растительного происхождения в незначительных количествах из-за технологических особенностей производства кормов.\\r\\n\\r\\nАналитические составляющие: Сырой протеин: 34%; Сырая клетчатка: 2,5%; Сырой жир: 22%; Сырая зола: 7,5%; Влажность: 6%; Кальций: 1,2%; Фосфор: 1%; Магний: 0,09%; Омега 6 жирные кислоты: 3,7%; Омега 3 жирные кислоты: 0,8%.\\r\\n\\r\\nМетаболизируемая энергия: 4490 ккал/кг.\\r\\n\\r\\nДобавки/кг: Пищевые добавки: Витамин А (3a672a): 20000 МЕ/кг; Витамин D3 (3a671): 1500 МЕ/кг; Витамин Е (3a700): 600 мг/кг; L-карнитин (3a910): 50 мг/кг; Медь (3b405): 5,0 мг/кг; Цинк (3b605): 100 мг/кг; Марганец (3b503): 15 мг/кг; Йод (3b202): 1,5 мг/кг; Селен (3b801): 0,2 мг/кг; Таурин (3a370): 1500 мг/кг.\\r\\n\\r\\nТехнологические добавки: Антиоксидант: богатые токоферолом экстракты из растительных масел 1000 мг/кг.", "age_category_id": 1, "product_type_id": 2}	{"id": 3, "name": "корм", "image": "__9.jpeg", "price": 2000.00, "stock": 12, "brand_id": 2, "is_active": true, "species_id": 2, "category_id": 1, "description": "Состав:\\r\\n\\r\\nДегидрированное мясо ягненка (23%), Дегидрированное мясо индейки (22%), Цельнозерновой коричневый рис, Свежее мясо ягненка (8%), Свежее мясо индейки (8%), Жир индейки (7%), Порошок корней цикория (натуральный источник пребиотиков: ФОС и инулина), Свежее масло лосося (1%), Сушеный антарктический криль (натуральный источник ЭПК и ДГК, 1%), Пивные дрожжи (натуральный источник МОС), Растительная клетчатка, Сушеная клюква, Юкка Мохаве. Кроме заявленных в составе животных ингредиентов продукт может содержать следы ДНК других ингредиентов животного или растительного происхождения в незначительных количествах из-за технологических особенностей производства кормов.\\r\\n\\r\\nАналитические составляющие: Сырой протеин: 34%; Сырая клетчатка: 2,5%; Сырой жир: 22%; Сырая зола: 7,5%; Влажность: 6%; Кальций: 1,2%; Фосфор: 1%; Магний: 0,09%; Омега 6 жирные кислоты: 3,7%; Омега 3 жирные кислоты: 0,8%.\\r\\n\\r\\nМетаболизируемая энергия: 4490 ккал/кг.\\r\\n\\r\\nДобавки/кг: Пищевые добавки: Витамин А (3a672a): 20000 МЕ/кг; Витамин D3 (3a671): 1500 МЕ/кг; Витамин Е (3a700): 600 мг/кг; L-карнитин (3a910): 50 мг/кг; Медь (3b405): 5,0 мг/кг; Цинк (3b605): 100 мг/кг; Марганец (3b503): 15 мг/кг; Йод (3b202): 1,5 мг/кг; Селен (3b801): 0,2 мг/кг; Таурин (3a370): 1500 мг/кг.\\r\\n\\r\\nТехнологические добавки: Антиоксидант: богатые токоферолом экстракты из растительных масел 1000 мг/кг.", "age_category_id": 1, "product_type_id": 2}	2025-10-18 12:31:11.269244+03	2
123	petshop_brand	4	CREATE	\N	{"id": 4, "name": "ыава", "is_active": true}	2025-09-28 21:01:52.441604+03	3
165	petshop_productstock	2	UPDATE	{"id": 2, "quantity": 0, "product_id": 1, "pickup_point_id": 2}	{"id": 2, "quantity": 6, "product_id": 1, "pickup_point_id": 2}	2025-10-13 11:06:31.324573+03	2
188	petshop_product	4	CREATE	\N	{"id": 4, "name": "пкуп", "image": "", "price": 23456.00, "stock": 23, "brand_id": 2, "is_active": true, "species_id": 2, "category_id": 1, "description": "вапиаавы", "age_category_id": 1, "product_type_id": 2}	2025-10-18 12:29:08.117498+03	2
189	petshop_productpurpose	5	CREATE	\N	{"id": 5, "product_id": 4, "purpose_id": 2}	2025-10-18 12:29:08.117498+03	2
196	petshop_product	5	CREATE	\N	{"id": 5, "name": "авпрорл", "image": "__10.jpeg", "price": 3456.00, "stock": 0, "brand_id": 2, "is_active": true, "species_id": 2, "category_id": 1, "description": "ыкакып", "age_category_id": 1, "product_type_id": 2}	2025-10-18 12:31:48.149384+03	2
232	petshop_user	2	UPDATE	{"id": 2, "role": 1, "email": "kspankova13@gmail.com", "phone": "+79236783456", "groups": [], "is_staff": true, "password": "pbkdf2_sha256$1000000$djZDFzVOi2CBOd2VyA7LkC$5KnYVLzhQR+wmIu+HdFL4iuiOx9PeWUCJ5TzBiAhc/o=", "is_active": true, "last_name": "Белова", "first_name": "Мария", "last_login": "2025-10-22T15:36:55.319975+00:00", "date_joined": "2025-09-20T14:32:29.091744+00:00", "middle_name": "", "is_superuser": true, "user_permissions": []}	{"id": 2, "role": 1, "email": "kspankova13@gmail.com", "phone": "+79236783456", "groups": [], "is_staff": true, "password": "pbkdf2_sha256$1000000$djZDFzVOi2CBOd2VyA7LkC$5KnYVLzhQR+wmIu+HdFL4iuiOx9PeWUCJ5TzBiAhc/o=", "is_active": true, "last_name": "Белова", "first_name": "Мария", "last_login": "2025-10-22T15:36:55.319975+00:00", "date_joined": "2025-09-20T14:32:29.091744+00:00", "middle_name": "", "is_superuser": false, "user_permissions": []}	2025-10-22 23:11:57.017183+03	2
243	petshop_category	3	DELETE	{"id": 3, "name": "xdvsdf", "is_active": true}	\N	2025-10-26 00:26:51.225307+03	2
233	petshop_user	12	UPDATE	{"id": 12, "role": 1, "email": "valeriya@example.com", "phone": "+79124533312", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$6qLFuXG2i6Rsl3IFuezIaN$jJCAxM4Yjw4bg1aXCvswhMXFnUZKZhztT71vSHO7xi4=", "is_active": true, "last_name": "Меладзе", "first_name": "Валерия", "last_login": null, "date_joined": "2025-10-07T21:02:05.405767+00:00", "middle_name": "", "is_superuser": false, "user_permissions": []}	{"id": 12, "role": 1, "email": "valeriya@example.com", "phone": "+79124533312", "groups": [], "is_staff": true, "password": "pbkdf2_sha256$1000000$6qLFuXG2i6Rsl3IFuezIaN$jJCAxM4Yjw4bg1aXCvswhMXFnUZKZhztT71vSHO7xi4=", "is_active": true, "last_name": "Меладзе", "first_name": "Валерия", "last_login": null, "date_joined": "2025-10-07T21:02:05.405767+00:00", "middle_name": "", "is_superuser": false, "user_permissions": []}	2025-10-22 23:16:16.692879+03	2
244	petshop_category	4	CREATE	\N	{"id": 4, "name": "уакпк", "is_active": true}	2025-10-26 00:30:57.662194+03	2
21	petshop_agecategory	5	CREATE	\N	{"id": 5, "age_name": "ыввыы", "is_active": true}	2025-09-24 19:45:41.590321+03	\N
234	petshop_user	6	UPDATE	{"id": 6, "role": 1, "email": "seller1010@example.com", "phone": "+71235674534", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$Q126JkEyNEh0fzvvWWAxKL$iUx2nlb5zIEYksluavfCDobOat4CbaTFLWZwvIzLf60=", "is_active": true, "last_name": "Дроздова", "first_name": "Виктория", "last_login": null, "date_joined": "2025-09-24T18:38:59.978903+00:00", "middle_name": "", "is_superuser": false, "user_permissions": []}	{"id": 6, "role": 1, "email": "seller1010@example.com", "phone": "+71235674534", "groups": [], "is_staff": true, "password": "pbkdf2_sha256$1000000$Q126JkEyNEh0fzvvWWAxKL$iUx2nlb5zIEYksluavfCDobOat4CbaTFLWZwvIzLf60=", "is_active": true, "last_name": "Дроздова", "first_name": "Виктория", "last_login": null, "date_joined": "2025-09-24T18:38:59.978903+00:00", "middle_name": "", "is_superuser": false, "user_permissions": []}	2025-10-22 23:16:21.714971+03	2
245	petshop_product	4	UPDATE	{"id": 4, "name": "пкуп", "image": "__1.jpeg", "price": 23456.00, "stock": 0, "brand_id": 2, "is_active": true, "species_id": 2, "category_id": 1, "description": "вапиаавы", "age_category_id": 1, "product_type_id": 2}	{"id": 4, "name": "пкуп", "image": "__1.jpeg", "price": 23456.00, "stock": 0, "brand_id": 2, "is_active": true, "species_id": 2, "category_id": 4, "description": "вапиаавы", "age_category_id": 1, "product_type_id": 2}	2025-10-26 00:31:04.40899+03	2
256	petshop_product	9	CREATE	\N	{"id": 9, "name": "adsdgtfyh", "image": "", "price": 123456.00, "stock": 0, "brand_id": 2, "is_active": true, "species_id": 1, "category_id": 2, "description": "asdfgh", "age_category_id": 1, "product_type_id": 2}	2025-11-05 11:57:00.519065+03	2
235	petshop_user	5	UPDATE	{"id": 5, "role": 1, "email": "seller001@example.com", "phone": "+78881234356", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$PW3f4KGkvnNQSGCWKX1RrX$MgMEFv40vvbFy65Ww4bBtr7EGqQeQwhya3xgPR2OrVg=", "is_active": true, "last_name": "Панкова", "first_name": "Мария", "last_login": null, "date_joined": "2025-09-24T18:37:00.916272+00:00", "middle_name": "", "is_superuser": false, "user_permissions": []}	{"id": 5, "role": 1, "email": "seller001@example.com", "phone": "+78881234356", "groups": [], "is_staff": true, "password": "pbkdf2_sha256$1000000$PW3f4KGkvnNQSGCWKX1RrX$MgMEFv40vvbFy65Ww4bBtr7EGqQeQwhya3xgPR2OrVg=", "is_active": true, "last_name": "Панкова", "first_name": "Мария", "last_login": null, "date_joined": "2025-09-24T18:37:00.916272+00:00", "middle_name": "", "is_superuser": false, "user_permissions": []}	2025-10-22 23:16:29.735408+03	2
197	petshop_productpurpose	6	CREATE	\N	{"id": 6, "product_id": 5, "purpose_id": 1}	2025-10-18 12:31:48.149384+03	2
120	petshop_productstock	2	UPDATE	{"id": 2, "quantity": 0, "product_id": 1, "pickup_point_id": 2}	{"id": 2, "quantity": 4, "product_id": 1, "pickup_point_id": 2}	2025-09-28 20:53:37.910408+03	3
166	petshop_order	120	UPDATE	{"id": 120, "email": "kspankova13@gmail.com", "phone": "+79236783456", "status": "Получен", "user_id": 2, "last_name": "Белова", "first_name": "Мария", "total_price": 2333.00, "date_created": "2025-09-29T20:24:33.50781+00:00", "date_updated": "2025-10-07T20:26:31.127406+00:00", "order_number": "828a781018294cc5aae0", "pickup_point_id": 1}	{"id": 120, "email": "kspankova13@gmail.com", "phone": "+79236783456", "status": "В обработке", "user_id": 2, "last_name": "Белова", "first_name": "Мария", "total_price": 2333.00, "date_created": "2025-09-29T20:24:33.50781+00:00", "date_updated": "2025-10-14T12:12:11.805496+00:00", "order_number": "828a781018294cc5aae0", "pickup_point_id": 1}	2025-10-14 15:12:11.798813+03	2
173	petshop_order	121	UPDATE	{"id": 121, "email": "kspankova13@gmail.com", "phone": "+79236783456", "status": "В обработке", "user_id": 2, "last_name": "Белова", "first_name": "Мария", "total_price": 2333.00, "date_created": "2025-09-29T20:24:58.368336+00:00", "date_updated": "2025-10-14T12:12:48.367711+00:00", "order_number": "a75b65a121c24c418354", "pickup_point_id": 1}	{"id": 121, "email": "kspankova13@gmail.com", "phone": "+79236783456", "status": "Завершён", "user_id": 2, "last_name": "Белова", "first_name": "Мария", "total_price": 2333.00, "date_created": "2025-09-29T20:24:58.368336+00:00", "date_updated": "2025-10-14T12:38:13.004537+00:00", "order_number": "a75b65a121c24c418354", "pickup_point_id": 1}	2025-10-14 15:38:13.002021+03	2
190	petshop_product	4	UPDATE	{"id": 4, "name": "пкуп", "image": "", "price": 23456.00, "stock": 23, "brand_id": 2, "is_active": true, "species_id": 2, "category_id": 1, "description": "вапиаавы", "age_category_id": 1, "product_type_id": 2}	{"id": 4, "name": "пкуп", "image": "", "price": 23456.00, "stock": 23, "brand_id": 2, "is_active": true, "species_id": 2, "category_id": 1, "description": "вапиаавы", "age_category_id": 1, "product_type_id": 2}	2025-10-18 12:29:17.963667+03	2
191	petshop_productpurpose	5	UPDATE	{"id": 5, "product_id": 4, "purpose_id": 2}	{"id": 5, "product_id": 4, "purpose_id": 1}	2025-10-18 12:29:17.963667+03	2
131	petshop_order	106	UPDATE	{"id": 106, "email": "isip_k.a.pankova@mpt.ru", "phone": "+79236783456", "status": "В обработке", "user_id": 3, "last_name": "Белова", "first_name": "Екатерина", "total_price": 3038.00, "date_created": "2025-09-28T18:21:14.042842+00:00", "date_updated": "2025-09-28T18:21:14.042861+00:00", "order_number": "91f4b6e1388e47bf9766", "pickup_point_id": 2}	{"id": 106, "email": "isip_k.a.pankova@mpt.ru", "phone": "+79236783456", "status": "Получен", "user_id": 3, "last_name": "Белова", "first_name": "Екатерина", "total_price": 3038.00, "date_created": "2025-09-28T18:21:14.042842+00:00", "date_updated": "2025-09-28T18:24:56.501288+00:00", "order_number": "91f4b6e1388e47bf9766", "pickup_point_id": 2}	2025-09-28 21:24:56.460518+03	3
22	petshop_agecategory	5	CREATE	\N	{"id": 5, "age_name": "ыввыы", "is_active": true}	2025-09-24 19:45:41.590321+03	2
275	petshop_producttype	4	CREATE	\N	{"id": 4, "is_active": true, "type_name": "Интерактивные ишрушки"}	2025-11-06 22:06:16.713298+03	2
167	petshop_order	121	UPDATE	{"id": 121, "email": "kspankova13@gmail.com", "phone": "+79236783456", "status": "Получен", "user_id": 2, "last_name": "Белова", "first_name": "Мария", "total_price": 2333.00, "date_created": "2025-09-29T20:24:58.368336+00:00", "date_updated": "2025-10-08T19:07:59.103695+00:00", "order_number": "a75b65a121c24c418354", "pickup_point_id": 1}	{"id": 121, "email": "kspankova13@gmail.com", "phone": "+79236783456", "status": "В обработке", "user_id": 2, "last_name": "Белова", "first_name": "Мария", "total_price": 2333.00, "date_created": "2025-09-29T20:24:58.368336+00:00", "date_updated": "2025-10-14T12:12:48.367711+00:00", "order_number": "a75b65a121c24c418354", "pickup_point_id": 1}	2025-10-14 15:12:48.363781+03	2
236	petshop_user	3	UPDATE	{"id": 3, "role": 1, "email": "isip_k.a.pankova@mpt.ru", "phone": "+79236783456", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$Wd3eX8akAbq9WTiGhKEe22$qEoR3rW2A13x5F/LwxgZYbb13nEMZrnPoV70X6KbEHg=", "is_active": true, "last_name": "Белова", "first_name": "Екатерина", "last_login": "2025-10-07T18:34:46.945635+00:00", "date_joined": "2025-09-20T15:57:45.361944+00:00", "middle_name": "", "is_superuser": false, "user_permissions": []}	{"id": 3, "role": 1, "email": "isip_k.a.pankova@mpt.ru", "phone": "+79236783456", "groups": [], "is_staff": true, "password": "pbkdf2_sha256$1000000$Wd3eX8akAbq9WTiGhKEe22$qEoR3rW2A13x5F/LwxgZYbb13nEMZrnPoV70X6KbEHg=", "is_active": true, "last_name": "Белова", "first_name": "Екатерина", "last_login": "2025-10-07T18:34:46.945635+00:00", "date_joined": "2025-09-20T15:57:45.361944+00:00", "middle_name": "", "is_superuser": false, "user_permissions": []}	2025-10-22 23:16:36.962394+03	2
220	petshop_productstock	7	UPDATE	{"id": 7, "quantity": 0, "product_id": 4, "pickup_point_id": 1}	{"id": 7, "quantity": 12, "product_id": 4, "pickup_point_id": 1}	2025-10-18 14:47:58.764084+03	2
257	petshop_productpurpose	10	CREATE	\N	{"id": 10, "product_id": 9, "purpose_id": 2}	2025-11-05 11:57:00.519065+03	2
258	petshop_productstock	11	CREATE	\N	{"id": 11, "quantity": 22, "product_id": 9, "pickup_point_id": 1}	2025-11-05 11:57:20.025036+03	2
169	petshop_order	92	UPDATE	{"id": 92, "email": "isip_k.a.pankova@mpt.ru", "phone": "+79236783456", "status": "В обработке", "user_id": 3, "last_name": "Белова", "first_name": "Екатерина", "total_price": 3038.00, "date_created": "2025-09-28T16:34:12.71645+00:00", "date_updated": "2025-09-28T16:34:12.716466+00:00", "order_number": "df61898b11804ad4af1b", "pickup_point_id": 1}	{"id": 92, "email": "isip_k.a.pankova@mpt.ru", "phone": "+79236783456", "status": "В работе", "user_id": 3, "last_name": "Белова", "first_name": "Екатерина", "total_price": 3038.00, "date_created": "2025-09-28T16:34:12.71645+00:00", "date_updated": "2025-10-14T12:16:36.923366+00:00", "order_number": "df61898b11804ad4af1b", "pickup_point_id": 1}	2025-10-14 15:16:36.920334+03	2
237	petshop_user	3	UPDATE	{"id": 3, "role": 1, "email": "isip_k.a.pankova@mpt.ru", "phone": "+79236783456", "groups": [], "is_staff": true, "password": "pbkdf2_sha256$1000000$Wd3eX8akAbq9WTiGhKEe22$qEoR3rW2A13x5F/LwxgZYbb13nEMZrnPoV70X6KbEHg=", "is_active": true, "last_name": "Белова", "first_name": "Екатерина", "last_login": "2025-10-07T18:34:46.945635+00:00", "date_joined": "2025-09-20T15:57:45.361944+00:00", "middle_name": "", "is_superuser": false, "user_permissions": []}	{"id": 3, "role": 1, "email": "isip_k.a.pankova@mpt.ru", "phone": "+79236783456", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$Wd3eX8akAbq9WTiGhKEe22$qEoR3rW2A13x5F/LwxgZYbb13nEMZrnPoV70X6KbEHg=", "is_active": true, "last_name": "Белова", "first_name": "Екатерина", "last_login": "2025-10-07T18:34:46.945635+00:00", "date_joined": "2025-09-20T15:57:45.361944+00:00", "middle_name": "", "is_superuser": false, "user_permissions": []}	2025-10-22 23:16:50.596958+03	2
240	petshop_role	5	CREATE	\N	{"id": 5, "name": "Пользователь"}	2025-10-22 23:33:36.994468+03	0
194	petshop_product	4	UPDATE	{"id": 4, "name": "пкуп", "image": "", "price": 23456.00, "stock": 23, "brand_id": 2, "is_active": true, "species_id": 2, "category_id": 1, "description": "вапиаавы", "age_category_id": 1, "product_type_id": 2}	{"id": 4, "name": "пкуп", "image": "__1.jpeg", "price": 23456.00, "stock": 23, "brand_id": 2, "is_active": true, "species_id": 2, "category_id": 1, "description": "вапиаавы", "age_category_id": 1, "product_type_id": 2}	2025-10-18 12:31:05.057262+03	2
201	petshop_productpurpose	6	DELETE	{"id": 6, "product_id": 5, "purpose_id": 1}	\N	2025-10-18 13:40:06.371863+03	2
202	petshop_productstock	8	DELETE	{"id": 8, "quantity": 1324, "product_id": 5, "pickup_point_id": 1}	\N	2025-10-18 13:40:06.371863+03	2
276	petshop_producttype	4	UPDATE	{"id": 4, "is_active": true, "type_name": "Интерактивные ишрушки"}	{"id": 4, "is_active": true, "type_name": "Интерактивные игрушки"}	2025-11-06 22:06:24.200914+03	2
203	petshop_product	5	DELETE	{"id": 5, "name": "авпрорл", "image": "__10.jpeg", "price": 3456.00, "stock": 0, "brand_id": 2, "is_active": true, "species_id": 2, "category_id": 1, "description": "ыкакып", "age_category_id": 1, "product_type_id": 2}	\N	2025-10-18 13:40:06.371863+03	2
124	petshop_brand	4	DELETE	{"id": 4, "name": "ыава", "is_active": true}	\N	2025-09-28 21:01:56.716728+03	3
23	petshop_agecategory	6	CREATE	\N	{"id": 6, "age_name": "ыв", "is_active": true}	2025-09-24 19:46:04.98935+03	\N
43	petshop_agecategory	6	UPDATE	{"id": 6, "age_name": "23аауа", "is_active": true}	{"id": 6, "age_name": "ывыв", "is_active": true}	2025-09-24 20:42:06.226518+03	2
44	petshop_agecategory	6	DELETE	{"id": 6, "age_name": "ывыв", "is_active": true}	\N	2025-09-24 20:42:25.325045+03	2
241	petshop_product	4	UPDATE	{"id": 4, "name": "пкуп", "image": "__1.jpeg", "price": 23456.00, "stock": 0, "brand_id": 2, "is_active": true, "species_id": 2, "category_id": 1, "description": "вапиаавы", "age_category_id": 1, "product_type_id": 2}	{"id": 4, "name": "пкуп", "image": "__1.jpeg", "price": 23456.00, "stock": 0, "brand_id": 2, "is_active": true, "species_id": 2, "category_id": 3, "description": "вапиаавы", "age_category_id": 1, "product_type_id": 2}	2025-10-26 00:26:09.155074+03	2
45	petshop_agecategory	7	CREATE	\N	{"id": 7, "age_name": "ывсыв", "is_active": true}	2025-09-24 20:42:37.427734+03	2
46	petshop_category	3	CREATE	\N	{"id": 3, "name": "dfsdfsd", "is_active": true}	2025-09-24 21:11:23.952772+03	2
277	petshop_product	4	UPDATE	{"id": 4, "name": "пкуп", "image": "__1.jpeg", "price": 23456.00, "stock": 0, "brand_id": 2, "is_active": true, "species_id": 2, "category_id": 4, "description": "вапиаавы", "age_category_id": 1, "product_type_id": 2}	{"id": 4, "name": "Пирамидка для кошек Barbaks Ёлочка-трек", "image": "Снимок_экрана_2025-11-06_в_22.07.03.png", "price": 324.00, "stock": 0, "brand_id": 6, "is_active": true, "species_id": 2, "category_id": 2, "description": "Двухуровневая пирамидка Barbaks в форме елочки создана для того, чтобы подарить питомцу часы активных игр. В комплекте поставляются шарики с кошачьей мятой, которые кошка будет с удовольствием катать по трекам, развивая ловкость и удовлетворяя природное любопытство. Устойчивая конструкция с широким основанием предотвращает опрокидывание во время энергичных игр. Компактные размеры позволяют разместить пирамидку в любом уголке дома. Игрушка особенно понравится котятам и активным взрослым кошкам и поможет им выплеснуть энергию даже в условиях ограниченного пространства.", "age_category_id": null, "product_type_id": 4}	2025-11-06 22:07:14.963987+03	2
278	petshop_productpurpose	5	DELETE	{"id": 5, "product_id": 4, "purpose_id": 1}	\N	2025-11-06 22:07:14.963987+03	2
47	petshop_category	3	UPDATE	{"id": 3, "name": "dfsdfsd", "is_active": true}	{"id": 3, "name": "xdvsdf", "is_active": true}	2025-09-24 21:11:33.186101+03	2
58	petshop_user	6	UPDATE	{"id": 6, "role": 1, "email": "seller1000@example.com", "phone": "+71235674534", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$Q126JkEyNEh0fzvvWWAxKL$iUx2nlb5zIEYksluavfCDobOat4CbaTFLWZwvIzLf60=", "is_active": true, "last_name": "Дроздова", "first_name": "Виктория", "last_login": null, "date_joined": "2025-09-24T18:38:59.978903+00:00", "middle_name": null, "is_superuser": false, "user_permissions": []}	{"id": 6, "role": 1, "email": "seller1010@example.com", "phone": "+71235674534", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$Q126JkEyNEh0fzvvWWAxKL$iUx2nlb5zIEYksluavfCDobOat4CbaTFLWZwvIzLf60=", "is_active": true, "last_name": "Дроздова", "first_name": "Виктория", "last_login": null, "date_joined": "2025-09-24T18:38:59.978903+00:00", "middle_name": null, "is_superuser": false, "user_permissions": []}	2025-09-24 21:44:19.800695+03	3
24	petshop_agecategory	6	CREATE	\N	{"id": 6, "age_name": "ыв", "is_active": true}	2025-09-24 19:46:04.98935+03	2
279	petshop_product	9	UPDATE	{"id": 9, "name": "adsdgtfyh", "image": "", "price": 123456.00, "stock": 0, "brand_id": 2, "is_active": true, "species_id": 1, "category_id": 2, "description": "asdfgh", "age_category_id": 1, "product_type_id": 2}	{"id": 9, "name": "Игрушка для кошек Barbaks Окунь Кузьма с кошачьей мятой", "image": "Снимок_экрана_2025-11-06_в_22.08.24.png", "price": 199.00, "stock": 0, "brand_id": 6, "is_active": true, "species_id": 2, "category_id": 2, "description": "Игрушка для кошек Barbaks «Окунь Кузьма» мягкая с кошачьей мятой для интерактивных игр, снятия стресса и развития реакции.\\r\\n\\r\\nПодходит как котятам, так и взрослым кошкам.\\r\\nСостав: полиэстер, полипропилен, кошачья мята.\\r\\nРазмер: 7x21 см.\\r\\nСрок годности: не ограничен при соблюдении условий хранения.\\r\\nСделано в Китае.", "age_category_id": null, "product_type_id": 3}	2025-11-06 22:08:32.9231+03	2
280	petshop_productpurpose	10	DELETE	{"id": 10, "product_id": 9, "purpose_id": 2}	\N	2025-11-06 22:08:32.9231+03	2
281	petshop_order	142	UPDATE	{"id": 142, "email": "kspankova13@gmail.com", "phone": "+79236783456", "status": "В обработке", "user_id": 2, "last_name": "Белова", "first_name": "Мария", "total_price": 515.00, "date_created": "2025-11-12T11:55:37.40182+00:00", "date_updated": "2025-11-12T11:55:37.401835+00:00", "order_number": "2cdf04cbcbec4c1dbce2", "pickup_point_id": 1}	{"id": 142, "email": "kspankova13@gmail.com", "phone": "+79236783456", "status": "Получен", "user_id": 2, "last_name": "Белова", "first_name": "Мария", "total_price": 515.00, "date_created": "2025-11-12T11:55:37.40182+00:00", "date_updated": "2025-11-12T13:47:47.308356+00:00", "order_number": "2cdf04cbcbec4c1dbce2", "pickup_point_id": 1}	2025-11-12 16:47:47.30499+03	2
282	petshop_order	143	UPDATE	{"id": 143, "email": "kspankova13@gmail.com", "phone": "+79236783456", "status": "В обработке", "user_id": 2, "last_name": "Белова", "first_name": "Мария", "total_price": 1030.00, "date_created": "2025-11-12T13:58:40.622147+00:00", "date_updated": "2025-11-12T13:58:40.622157+00:00", "order_number": "e606e669065042f1bf68", "pickup_point_id": 1}	{"id": 143, "email": "kspankova13@gmail.com", "phone": "+79236783456", "status": "Получен", "user_id": 2, "last_name": "Белова", "first_name": "Мария", "total_price": 1030.00, "date_created": "2025-11-12T13:58:40.622147+00:00", "date_updated": "2025-11-12T13:59:02.531234+00:00", "order_number": "e606e669065042f1bf68", "pickup_point_id": 1}	2025-11-12 16:59:02.52813+03	2
3	petshop_order	40	UPDATE	{"id": 40, "email": "isip_k.a.pankova@mpt.ru", "phone": "+79236783456", "status": "В работе", "user_id": 3, "last_name": "Белова", "first_name": "Екатерина", "total_price": 3038.00, "date_created": "2025-09-23T18:30:46.153471+00:00", "date_updated": "2025-09-24T14:55:33.445194+00:00", "order_number": "ZCTRLOTLLY", "pickup_point_id": 1}	{"id": 40, "email": "isip_k.a.pankova@mpt.ru", "phone": "+79236783456", "status": "Завершён", "user_id": 3, "last_name": "Белова", "first_name": "Екатерина", "total_price": 3038.00, "date_created": "2025-09-23T18:30:46.153471+00:00", "date_updated": "2025-09-24T15:50:11.39324+00:00", "order_number": "ZCTRLOTLLY", "pickup_point_id": 1}	2025-09-24 18:50:11.386079+03	\N
4	petshop_order	41	CREATE	\N	{"id": 41, "email": "isip_k.a.pankova@mpt.ru", "phone": "+79236783456", "status": "В обработке", "user_id": 2, "last_name": "Воронов", "first_name": "Ксения", "total_price": 2000.00, "date_created": "2025-09-24T16:03:06.727548+00:00", "date_updated": "2025-09-24T16:03:06.727566+00:00", "order_number": "2MIN62BLCW", "pickup_point_id": 1}	2025-09-24 19:03:06.723602+03	\N
8	petshop_order	46	CREATE	\N	{"id": 46, "email": "kspankova13@gmail.com", "phone": "+79236783456", "status": "В работе", "user_id": 2, "last_name": "Воронов", "first_name": "Ксюша", "total_price": 3456.01, "date_created": "2025-09-24T16:19:22.974287+00:00", "date_updated": "2025-09-24T16:19:22.974297+00:00", "order_number": "ZCTRLOTLLQ", "pickup_point_id": 2}	2025-09-24 19:19:22.942271+03	\N
9	Order	46	CREATE	\N	{"id": 46, "user": 2, "email": "kspankova13@gmail.com", "phone": "+79236783456", "status": "В работе", "last_name": "Воронов", "first_name": "Ксюша", "total_price": 3456.01, "order_number": "ZCTRLOTLLQ", "pickup_point": 2}	2025-09-24 19:19:22.979006+03	\N
223	petshop_productstock	7	UPDATE	{"id": 7, "quantity": 12, "product_id": 4, "pickup_point_id": 1}	{"id": 7, "quantity": 13, "product_id": 4, "pickup_point_id": 1}	2025-10-18 15:10:30.556431+03	2
224	petshop_productstock	7	UPDATE	{"id": 7, "quantity": 13, "product_id": 4, "pickup_point_id": 1}	{"id": 7, "quantity": 121, "product_id": 4, "pickup_point_id": 1}	2025-10-18 15:32:53.019761+03	2
225	petshop_productstock	7	UPDATE	{"id": 7, "quantity": 121, "product_id": 4, "pickup_point_id": 1}	{"id": 7, "quantity": 5, "product_id": 4, "pickup_point_id": 1}	2025-10-18 15:37:37.111472+03	2
10	Order	46	UPDATE	\N	{"id": 46, "user": 2, "email": "kspankova13@gmail.com", "phone": "+79236783456", "status": "Завершён", "last_name": "Воронов", "first_name": "Ксюша", "total_price": 3456.01, "order_number": "ZCTRLOTLLQ", "pickup_point": 2}	2025-09-24 19:19:55.321402+03	\N
176	petshop_productpurpose	4	CREATE	\N	{"id": 4, "product_id": 3, "purpose_id": 2}	2025-10-18 12:24:12.532907+03	2
207	petshop_product	7	CREATE	\N	{"id": 7, "name": "цуекн", "image": "__8.jpeg", "price": 2134.00, "stock": 0, "brand_id": 1, "is_active": true, "species_id": 1, "category_id": 2, "description": "ыавпр", "age_category_id": 2, "product_type_id": 2}	2025-10-18 13:56:41.780539+03	2
208	petshop_productpurpose	8	CREATE	\N	{"id": 8, "product_id": 7, "purpose_id": 2}	2025-10-18 13:56:41.780539+03	2
209	petshop_productstock	10	CREATE	\N	{"id": 10, "quantity": 1234, "product_id": 7, "pickup_point_id": 1}	2025-10-18 13:56:52.784512+03	2
11	petshop_agecategory	3	UPDATE	{"id": 3, "age_name": "ыыввыыв", "is_active": true}	{"id": 3, "age_name": "ыывйввввыыв", "is_active": true}	2025-09-24 19:26:35.369261+03	\N
210	petshop_productpurpose	8	DELETE	{"id": 8, "product_id": 7, "purpose_id": 2}	\N	2025-10-18 13:57:19.776843+03	2
211	petshop_productstock	10	DELETE	{"id": 10, "quantity": 1234, "product_id": 7, "pickup_point_id": 1}	\N	2025-10-18 13:57:19.776843+03	2
212	petshop_product	7	DELETE	{"id": 7, "name": "цуекн", "image": "__8.jpeg", "price": 2134.00, "stock": 0, "brand_id": 1, "is_active": true, "species_id": 1, "category_id": 2, "description": "ыавпр", "age_category_id": 2, "product_type_id": 2}	\N	2025-10-18 13:57:19.776843+03	2
260	petshop_order	130	UPDATE	{"id": 130, "email": "kspankova13@gmail.com", "phone": "+79236783456", "status": "Получен", "user_id": 2, "last_name": "Белова", "first_name": "Мария", "total_price": 2333.00, "date_created": "2025-10-18T12:40:37.921923+00:00", "date_updated": "2025-11-06T08:35:47.541137+00:00", "order_number": "97d532ef8a994dd6845c", "pickup_point_id": 1}	{"id": 130, "email": "kspankova13@gmail.com", "phone": "+79236783456", "status": "Получен", "user_id": 2, "last_name": "Белова", "first_name": "Мария", "total_price": 2333.00, "date_created": "2025-10-18T12:40:37.921923+00:00", "date_updated": "2025-11-06T08:36:58.32995+00:00", "order_number": "97d532ef8a994dd6845c", "pickup_point_id": 1}	2025-11-06 11:36:58.327513+03	2
213	petshop_product	4	UPDATE	{"id": 4, "name": "пкуп", "image": "__1.jpeg", "price": 23456.00, "stock": 23, "brand_id": 2, "is_active": true, "species_id": 2, "category_id": 1, "description": "вапиаавы", "age_category_id": 1, "product_type_id": 2}	{"id": 4, "name": "пкуп", "image": "__1.jpeg", "price": 23456.00, "stock": 0, "brand_id": 2, "is_active": true, "species_id": 2, "category_id": 1, "description": "вапиаавы", "age_category_id": 1, "product_type_id": 2}	2025-10-18 14:19:53.693851+03	2
13	petshop_agecategory	3	UPDATE	{"id": 3, "age_name": "ыывйввввыыв", "is_active": true}	{"id": 3, "age_name": "121цвцвц", "is_active": true}	2025-09-24 19:32:31.125653+03	\N
14	petshop_agecategory	3	UPDATE	{"id": 3, "age_name": "121цвцвц", "is_active": true}	{"id": 3, "age_name": "121цвцвц", "is_active": true}	2025-09-24 19:32:31.125653+03	2
15	petshop_agecategory	4	CREATE	\N	{"id": 4, "age_name": "ыпып", "is_active": true}	2025-09-24 19:43:37.639856+03	\N
16	petshop_agecategory	4	CREATE	\N	{"id": 4, "age_name": "ыпып", "is_active": true}	2025-09-24 19:43:37.639856+03	2
17	petshop_agecategory	4	DELETE	{"id": 4, "age_name": "ыпып", "is_active": true}	\N	2025-09-24 19:43:54.535709+03	2
18	petshop_agecategory	4	DELETE	{"id": 4, "age_name": "ыпып", "is_active": true}	\N	2025-09-24 19:43:54.535709+03	\N
\.


--
-- TOC entry 3987 (class 0 OID 19718)
-- Dependencies: 222
-- Data for Name: petshop_brand; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.petshop_brand (id, name, is_active) FROM stdin;
1	Carnica	t
2	Grandorf	t
5	Triol	t
6	Barbaks	t
\.


--
-- TOC entry 4015 (class 0 OID 19832)
-- Dependencies: 250
-- Data for Name: petshop_cart; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.petshop_cart (id, quantity, product_id, user_id) FROM stdin;
50	1	1	11
60	1	1	3
92	1	2	2
\.


--
-- TOC entry 3989 (class 0 OID 19724)
-- Dependencies: 224
-- Data for Name: petshop_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.petshop_category (id, name, is_active) FROM stdin;
1	Корм	t
2	Игрушки	t
4	уакпк	t
\.


--
-- TOC entry 4001 (class 0 OID 19762)
-- Dependencies: 236
-- Data for Name: petshop_order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.petshop_order (id, order_number, status, total_price, date_created, date_updated, pickup_point_id, user_id, email, first_name, last_name, phone) FROM stdin;
139	b1eee4a4a10845878aba	В обработке	3038.00	2025-11-11 21:31:49.312784+03	2025-11-11 21:31:49.312798+03	1	2	kspankova13@gmail.com	Мария	Белова	+79236783456
141	f9e97e62834645f2bf09	В обработке	515.00	2025-11-12 01:01:30.265438+03	2025-11-12 01:01:30.265458+03	1	2	kspankova13@gmail.com	Мария	Белова	+79236783456
143	e606e669065042f1bf68	Получен	1030.00	2025-11-12 16:58:40.622147+03	2025-11-12 16:59:02.531234+03	1	2	kspankova13@gmail.com	Мария	Белова	+79236783456
140	264bf1dd2c824032bef4	В обработке	3038.00	2025-11-12 00:08:42.025955+03	2025-11-12 00:08:42.025969+03	1	2	kspankova13@gmail.com	Мария	Белова	+79236783456
142	2cdf04cbcbec4c1dbce2	Получен	515.00	2025-11-12 14:55:37.40182+03	2025-11-12 16:47:47.308356+03	1	2	kspankova13@gmail.com	Мария	Белова	+79236783456
120	828a781018294cc5aae0	В обработке	2333.00	2025-09-29 23:24:33.50781+03	2025-10-14 15:12:11.805496+03	1	2	kspankova13@gmail.com	Мария	Белова	+79236783456
118	97297a3376cd4e2ab5ad	Завершён	3038.00	2025-09-29 22:58:29.590309+03	2025-10-14 15:13:50.834843+03	2	2	kspankova13@gmail.com	Мария	Белова	+79236783456
92	df61898b11804ad4af1b	В работе	3038.00	2025-09-28 19:34:12.71645+03	2025-10-14 15:16:36.923366+03	1	3	isip_k.a.pankova@mpt.ru	Екатерина	Белова	+79236783456
93	017f0f8252fe4b959f32	В работе	3038.00	2025-09-28 19:35:10.725245+03	2025-10-14 15:16:59.40481+03	1	3	isip_k.a.pankova@mpt.ru	Екатерина	Белова	+79236783456
87	7c9aeded15cf49a1a885	В обработке	3038.00	2025-09-28 19:17:00.892823+03	2025-09-28 19:17:00.892836+03	1	3	isip_k.a.pankova@mpt.ru	Екатерина	Белова	+79236783456
88	acae0d5f2c07477d9eb7	В обработке	3038.00	2025-09-28 19:23:07.440496+03	2025-09-28 19:23:07.440511+03	1	3	isip_k.a.pankova@mpt.ru	Екатерина	Белова	+79236783456
89	1a60de862b7045e6b6ee	В обработке	3038.00	2025-09-28 19:25:57.583386+03	2025-09-28 19:25:57.583402+03	1	3	isip_k.a.pankova@mpt.ru	Екатерина	Белова	+79236783456
90	2b3157eef72f442db333	В обработке	3038.00	2025-09-28 19:32:21.019653+03	2025-09-28 19:32:21.019671+03	1	3	isip_k.a.pankova@mpt.ru	Екатерина	Белова	+79236783456
4	XJ7BPXJUHY	В обработке	6076.00	2025-09-20 19:19:37.084431+03	2025-11-01 18:06:15.579155+03	1	3	isip_k.a.pankova@mpt.ru	Мария	Белова	+79236783456
136	df19c234928a45b3aea3	Получен	6076.00	2025-11-06 11:53:34.649751+03	2025-11-06 11:53:53.068477+03	1	2	kspankova13@gmail.com	Мария	Белова	+79236783456
134	0d6fa9cc3da24ffca7ad	Получен	3038.00	2025-11-01 17:09:51.687608+03	2025-11-05 10:14:36.34544+03	2	2	kspankova13@gmail.com	Мария	Белова	+79236783456
128	bceb890ccab74de28098	В обработке	15190.00	2025-10-16 15:04:01.47284+03	2025-10-16 15:04:01.472852+03	2	2	kspankova13@gmail.com	Мария	Белова	+79236783456
101	f9a25ccd5c374a5da5e8	В обработке	3038.00	2025-09-28 20:42:14.253352+03	2025-09-28 20:42:14.253369+03	1	3	isip_k.a.pankova@mpt.ru	Екатерина	Белова	+79236783456
103	ebe31a8e4b5a475cb2ca	Получен	6076.00	2025-09-28 20:42:50.052586+03	2025-09-28 21:19:42.784196+03	2	3	isip_k.a.pankova@mpt.ru	Екатерина	Белова	+79236783456
106	91f4b6e1388e47bf9766	Получен	3038.00	2025-09-28 21:21:14.042842+03	2025-09-28 21:24:56.501288+03	2	3	isip_k.a.pankova@mpt.ru	Екатерина	Белова	+79236783456
46	ZCTRLOTLLQ	Получен	3456.01	2025-09-24 19:19:22.974287+03	2025-09-26 20:42:21.027857+03	2	2	kspankova13@gmail.com	Ксюша	Воронов	+79236783456
41	2MIN62BLCW	Получен	2000.00	2025-09-24 19:03:06.727548+03	2025-09-26 20:43:13.319196+03	1	2	isip_k.a.pankova@mpt.ru	Ксения	Воронов	+79236783456
26	ENNHDBJWFW	Получен	3038.00	2025-09-20 20:54:43.502745+03	2025-09-26 20:49:18.308523+03	1	2	isip_k.a.pankova@mpt.ru	Мария	Белова	+79236783456
117	954fbe0dd9624d538267	В обработке	3038.00	2025-09-29 22:57:38.47639+03	2025-09-29 22:57:38.476402+03	2	2	kspankova13@gmail.com	Мария	Белова	+79236783456
127	dba3568bcc124fdba203	В обработке	5371.00	2025-10-14 21:36:39.229116+03	2025-10-14 21:36:39.229131+03	1	2	kspankova13@gmail.com	Мария	Белова	+79236783456
125	47665aeef03e46fc89c6	В обработке	2333.00	2025-10-13 15:01:25.569549+03	2025-10-13 15:01:25.569566+03	1	2	kspankova13@gmail.com	Мария	Белова	+79236783456
121	a75b65a121c24c418354	Завершён	2333.00	2025-09-29 23:24:58.368336+03	2025-10-14 15:38:13.004537+03	1	2	kspankova13@gmail.com	Мария	Белова	+79236783456
5	1UYP0ENP5B	В обработке	6076.00	2025-09-20 19:23:30.879331+03	2025-09-20 19:23:30.892725+03	1	3	isip_k.a.pankova@mpt.ru	Мария	Белова	+79236783456
6	0ZU7HYF41Q	В обработке	3038.00	2025-09-20 19:26:55.428035+03	2025-09-20 19:26:55.437721+03	1	3	isip_k.a.pankova@mpt.ru	Мария	Белова	+79236783456
9	OW2KAXQWO3	В обработке	3038.00	2025-09-20 19:30:47.904236+03	2025-09-20 19:30:47.911824+03	1	3	isip_k.a.pankova@mpt.ru	Мария	Белова	+79236783456
10	HP8WUFB1MI	В обработке	3038.00	2025-09-20 19:35:54.586837+03	2025-09-20 19:35:54.593282+03	1	3	isip_k.a.pankova@mpt.ru	Мария	Белова	+79236783456
11	05G4IHLTH6	В обработке	3038.00	2025-09-20 19:37:24.828707+03	2025-09-20 19:37:24.836244+03	1	3	isip_k.a.pankova@mpt.ru	Мария	Белова	+79236783456
7	FY8UGFZY9Q	В обработке	3038.00	2025-09-20 19:29:24.550568+03	2025-09-20 19:29:24.558788+03	1	3	isip_k.a.pankova@mpt.ru	Мария	Белова	+79236783456
8	C5AGHCSXUJ	В обработке	3038.00	2025-09-20 19:30:17.839958+03	2025-09-20 19:30:17.846436+03	1	3	isip_k.a.pankova@mpt.ru	Мария	Белова	+79236783456
12	5TRRRHRLPY	В обработке	3038.00	2025-09-20 19:39:31.923468+03	2025-09-20 19:39:31.930188+03	1	3	isip_k.a.pankova@mpt.ru	Мария	Белова	+79236783456
13	Y3ZVW1DD1Z	В обработке	3038.00	2025-09-20 19:40:02.15747+03	2025-09-20 19:40:02.163527+03	1	3	isip_k.a.pankova@mpt.ru	Мария	Белова	+79236783456
14	RBCFUXVI6K	В обработке	3038.00	2025-09-20 19:42:08.502036+03	2025-09-20 19:42:08.508812+03	1	3	isip_k.a.pankova@mpt.ru	Мария	Белова	+79236783456
15	NFFCMLJ4RL	В обработке	3038.00	2025-09-20 19:49:12.875758+03	2025-09-20 19:49:12.885306+03	1	3	isip_k.a.pankova@mpt.ru	Мария	Белова	+79236783456
16	WKBA8LRQ7C	В обработке	3038.00	2025-09-20 20:18:17.528703+03	2025-09-20 20:18:17.546986+03	1	3	isip_k.a.pankova@mpt.ru	Мария	Белова	+79236783456
17	8XLDTR2ERK	В обработке	3038.00	2025-09-20 20:18:46.162823+03	2025-09-20 20:18:46.169882+03	1	3	isip_k.a.pankova@mpt.ru	Мария	Белова	+79236783456
18	S1OY3BI0GY	В обработке	3038.00	2025-09-20 20:20:37.844194+03	2025-09-20 20:20:37.851421+03	1	3	isip_k.a.pankova@mpt.ru	аевпра	Белова	+79236783456
19	G37IIQVJHD	В обработке	3038.00	2025-09-20 20:20:53.530158+03	2025-09-20 20:20:53.535769+03	1	3	isip_k.a.pankova@mpt.ru	оаопр	Белова	+79236783456
20	NWIY95COZ3	В обработке	3038.00	2025-09-20 20:21:13.343732+03	2025-09-20 20:21:13.351526+03	1	3	isip_k.a.pankova@mpt.ru	Мария	Белова	987878
21	R03SYL5MHY	В обработке	3038.00	2025-09-20 20:24:24.645481+03	2025-09-20 20:24:24.653312+03	1	3	isip_k.a.pankova@mpt.ru	Мария	Белова	67867
28	ZRRD7JVRZW	Получен	3038.00	2025-09-22 18:28:01.762946+03	2025-09-22 18:43:23.957012+03	1	3	isip_k.a.pankova@mpt.ru	Мария	Белова	+79236783456
23	JWZI6MB8GM	В обработке	15190.00	2025-09-20 20:43:24.504562+03	2025-09-20 20:43:24.515062+03	1	2	kspankova13@gmail.com	Ксения	Панкова	+79236783456
24	P3XR80J9FI	В обработке	18228.00	2025-09-20 20:44:01.415811+03	2025-09-20 20:44:01.420404+03	1	2	kspankova13@gmail.com	Ксения	Панкова	+79236783456
25	TFMM6ASTJ4	В обработке	30380.00	2025-09-20 20:48:49.348531+03	2025-09-20 20:48:49.353451+03	1	2	isip_k.a.pankova@mpt.ru	Мария	Воронова	+79236783456
38	UKTV60Z8NF	В обработке	3038.00	2025-09-23 21:24:16.899522+03	2025-09-23 21:24:16.903006+03	1	3	isip_k.a.pankova@mpt.ru	Екатерина	Белова	+79236783456
22	UXUMTFWGBX	В работе	3038.00	2025-09-20 20:24:39.464021+03	2025-09-22 17:24:55.086831+03	1	3	isip_k.a.pankova@mpt.ru	Мария	Белова	кк5646
27	G9EYOCMPTF	Получен	3038.00	2025-09-22 14:20:03.209824+03	2025-09-22 18:18:24.411428+03	1	3	isip_k.a.pankova@mpt.ru	Мария	Белова	+79997891893
30	JCWCF3TRED	Получен	3038.00	2025-09-22 18:43:31.266241+03	2025-09-22 18:43:47.620152+03	1	3	isip_k.a.pankova@mpt.ru	Мария	Белова	+79236783456
39	AEQNAFTLW6	В обработке	3038.00	2025-09-23 21:24:55.753629+03	2025-09-23 21:24:55.756203+03	1	3	isip_k.a.pankova@mpt.ru	2323	Белова	+79236783456
31	8DZYZTFGVF	Получен	3038.00	2025-09-22 18:47:35.732973+03	2025-09-22 18:49:40.302952+03	1	3	isip_k.a.pankova@mpt.ru	Мария	Белова	+79236783456
29	2MIN62BLCQ	В обработке	3038.00	2025-09-22 18:32:37.177654+03	2025-09-22 18:42:52.716929+03	1	3	isip_k.a.pankova@mpt.ru	Мария	Белова	+79236783456
32	2OCS5EMCZO	В обработке	15190.00	2025-09-23 18:26:20.95589+03	2025-09-23 18:26:20.963975+03	1	3	isip_k.a.pankova@mpt.ru	Мария	Белова	+79236783456
40	ZCTRLOTLLY	В обработке	3038.00	2025-09-23 21:30:46.153471+03	2025-09-24 19:02:26.446399+03	1	3	isip_k.a.pankova@mpt.ru	Екатерина	Белова	+79236783456
116	135a57e11ac24d6aac76	В обработке	3038.00	2025-09-29 22:53:30.838669+03	2025-09-29 22:53:30.838687+03	2	2	kspankova13@gmail.com	Мария	Белова	+79236783456
3	U4WUW8LK41	В обработке	18228.00	2025-09-20 19:18:57.560558+03	2025-11-01 18:06:20.283468+03	1	2	kspankova13@gmail.com	Ксения	Панкова	\N
2	N2HRSJNLF5	В обработке	3038.00	2025-09-20 19:15:53.867355+03	2025-11-01 18:06:23.461398+03	1	3	isip_k.a.pankova@mpt.ru	Мария	Белова	+79236783456
130	97d532ef8a994dd6845c	Получен	2333.00	2025-10-18 15:40:37.921923+03	2025-11-06 11:36:58.32995+03	1	2	kspankova13@gmail.com	Мария	Белова	+79236783456
124	2e59f8aff8a64ad99185	В обработке	2333.00	2025-10-13 14:45:17.850403+03	2025-10-13 14:45:17.850422+03	1	2	kspankova13@gmail.com	Мария	Белова	+79236783456
\.


--
-- TOC entry 4005 (class 0 OID 19778)
-- Dependencies: 240
-- Data for Name: petshop_orderitem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.petshop_orderitem (id, quantity, price, order_id, product_id) FROM stdin;
121	1	2333.00	130	2
113	1	2333.00	124	2
114	1	2333.00	125	2
117	1	3038.00	127	1
118	1	2333.00	127	2
119	5	3038.00	128	1
75	1	3038.00	87	1
76	1	3038.00	88	1
77	1	3038.00	89	1
78	1	3038.00	90	1
80	1	3038.00	92	1
81	1	3038.00	93	1
89	1	3038.00	101	1
91	2	3038.00	103	1
94	1	3038.00	106	1
104	1	3038.00	116	1
105	1	3038.00	117	1
106	1	3038.00	118	1
1	1	3038.00	2	1
2	6	3038.00	3	1
3	2	3038.00	4	1
4	2	3038.00	5	1
5	1	3038.00	6	1
6	1	3038.00	7	1
7	1	3038.00	8	1
8	1	3038.00	9	1
9	1	3038.00	10	1
10	1	3038.00	11	1
11	1	3038.00	12	1
12	1	3038.00	13	1
13	1	3038.00	14	1
14	1	3038.00	15	1
15	1	3038.00	16	1
16	1	3038.00	17	1
17	1	3038.00	18	1
18	1	3038.00	19	1
19	1	3038.00	20	1
20	1	3038.00	21	1
21	1	3038.00	22	1
22	5	3038.00	23	1
23	6	3038.00	24	1
24	10	3038.00	25	1
25	1	3038.00	26	1
26	1	3038.00	27	1
27	1	3038.00	28	1
28	1	3038.00	29	1
29	1	3038.00	30	1
30	1	3038.00	31	1
31	5	3038.00	32	1
37	1	3038.00	38	1
38	1	3038.00	39	1
39	1	3038.00	40	1
108	1	2333.00	120	2
109	1	2333.00	121	2
125	1	3038.00	134	1
127	2	3038.00	136	1
130	1	3038.00	139	1
131	1	3038.00	140	1
132	1	515.00	141	2
133	1	515.00	142	2
134	2	515.00	143	2
\.


--
-- TOC entry 3991 (class 0 OID 19730)
-- Dependencies: 226
-- Data for Name: petshop_pickuppoint; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.petshop_pickuppoint (id, address, working_hours, is_active) FROM stdin;
1	г. Москва, ул. Пушистая, д. 7А, зоомагазин "Yes of кусь"	10:00 – 20:00	t
2	г. Москва, пр-т Дружбы, д. 45, зоомагазин «Yes of кусь»	9:00-20:00	t
\.


--
-- TOC entry 4003 (class 0 OID 19770)
-- Dependencies: 238
-- Data for Name: petshop_product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.petshop_product (id, name, description, price, stock, image, is_active, age_category_id, brand_id, category_id, product_type_id, species_id) FROM stdin;
1	Корм для кошек Grandorf 2кг ягненок с индейкой	Состав:\r\n\r\nДегидрированное мясо ягненка (23%), Дегидрированное мясо индейки (22%), Цельнозерновой коричневый рис, Свежее мясо ягненка (8%), Свежее мясо индейки (8%), Жир индейки (7%), Порошок корней цикория (натуральный источник пребиотиков: ФОС и инулина), Свежее масло лосося (1%), Сушеный антарктический криль (натуральный источник ЭПК и ДГК, 1%), Пивные дрожжи (натуральный источник МОС), Растительная клетчатка, Сушеная клюква, Юкка Мохаве. Кроме заявленных в составе животных ингредиентов продукт может содержать следы ДНК других ингредиентов животного или растительного происхождения в незначительных количествах из-за технологических особенностей производства кормов.\r\n\r\nАналитические составляющие: Сырой протеин: 34%; Сырая клетчатка: 2,5%; Сырой жир: 22%; Сырая зола: 7,5%; Влажность: 6%; Кальций: 1,2%; Фосфор: 1%; Магний: 0,09%; Омега 6 жирные кислоты: 3,7%; Омега 3 жирные кислоты: 0,8%.\r\n\r\nМетаболизируемая энергия: 4490 ккал/кг.\r\n\r\nДобавки/кг: Пищевые добавки: Витамин А (3a672a): 20000 МЕ/кг; Витамин D3 (3a671): 1500 МЕ/кг; Витамин Е (3a700): 600 мг/кг; L-карнитин (3a910): 50 мг/кг; Медь (3b405): 5,0 мг/кг; Цинк (3b605): 100 мг/кг; Марганец (3b503): 15 мг/кг; Йод (3b202): 1,5 мг/кг; Селен (3b801): 0,2 мг/кг; Таурин (3a370): 1500 мг/кг.\r\n\r\nТехнологические добавки: Антиоксидант: богатые токоферолом экстракты из растительных масел 1000 мг/кг.	3038.00	9	корм_9a3F2cJ.png	t	1	2	1	2	2
2	Игрушка для собак мягкая Triol Бобер	Мягкая игрушка для собак "Бобёр" с двумя пищалками внутри. Собаки любят трепать и грызть мягкие игрушки, ведь их легко носить в зубах и кусать. Кроме того, такую реалистичную игрушку можно использовать для дрессировки и натаски собак.	515.00	47	Снимок_экрана_2025-11-06_в_22.03.00.png	t	\N	5	2	3	1
4	Пирамидка для кошек Barbaks Ёлочка-трек	Двухуровневая пирамидка Barbaks в форме елочки создана для того, чтобы подарить питомцу часы активных игр. В комплекте поставляются шарики с кошачьей мятой, которые кошка будет с удовольствием катать по трекам, развивая ловкость и удовлетворяя природное любопытство. Устойчивая конструкция с широким основанием предотвращает опрокидывание во время энергичных игр. Компактные размеры позволяют разместить пирамидку в любом уголке дома. Игрушка особенно понравится котятам и активным взрослым кошкам и поможет им выплеснуть энергию даже в условиях ограниченного пространства.	324.00	0	Снимок_экрана_2025-11-06_в_22.07.03.png	t	\N	6	2	4	2
9	Игрушка для кошек Barbaks Окунь Кузьма с кошачьей мятой	Игрушка для кошек Barbaks «Окунь Кузьма» мягкая с кошачьей мятой для интерактивных игр, снятия стресса и развития реакции.\r\n\r\nПодходит как котятам, так и взрослым кошкам.\r\nСостав: полиэстер, полипропилен, кошачья мята.\r\nРазмер: 7x21 см.\r\nСрок годности: не ограничен при соблюдении условий хранения.\r\nСделано в Китае.	199.00	0	Снимок_экрана_2025-11-06_в_22.08.24.png	t	\N	6	2	3	2
3	Корм для щенков Grandorf 1кг ягненок с индейкой	Состав:\r\n\r\nДегидрированное мясо ягненка (24%), Дегидрированное мясо индейки (23%), Цельнозерновой коричневый рис, Свежее мясо ягненка (7%), Свежее мясо индейки (7%), Жир индейки (7%), Порошок корней цикория (натуральный источник пребиотиков: ФОС и инулина), Мука из плодов рожкового дерева, Сушеное яблоко, Свежее масло лосося (1%), Сушеный антарктический криль (натуральный источник ЭПК и ДГК, 1%), Пивные дрожжи (натуральный источник МОС), Глюкозамин (1000 мг/кг), Хондроитин сульфат (1000 мг/кг), MSM (метилсульфонилметан, 40 мг/кг), Сушеная клюква, Юкка Мохаве. Кроме заявленных в составе животных ингредиентов продукт может содержать следы ДНК других ингредиентов животного или растительного происхождения в незначительных количествах из-за технологических особенностей производства кормов.	1350.00	12	Снимок_экрана_2025-11-06_в_22.04.52.png	t	5	2	1	2	1
\.


--
-- TOC entry 4009 (class 0 OID 19790)
-- Dependencies: 244
-- Data for Name: petshop_productpurpose; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.petshop_productpurpose (id, product_id, purpose_id) FROM stdin;
1	1	1
4	3	1
\.


--
-- TOC entry 4007 (class 0 OID 19784)
-- Dependencies: 242
-- Data for Name: petshop_productstock; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.petshop_productstock (id, quantity, pickup_point_id, product_id) FROM stdin;
6	110	1	3
7	5	1	4
2	0	2	1
11	22	1	9
1	0	1	1
5	8	1	2
\.


--
-- TOC entry 3993 (class 0 OID 19736)
-- Dependencies: 228
-- Data for Name: petshop_producttype; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.petshop_producttype (id, type_name, is_active) FROM stdin;
1	Лакомства	t
2	Сухой корм	t
3	Мягкие игрушки	t
4	Интерактивные игрушки	t
\.


--
-- TOC entry 3995 (class 0 OID 19742)
-- Dependencies: 230
-- Data for Name: petshop_purpose; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.petshop_purpose (id, purpose_name, is_active) FROM stdin;
1	Для роста и развития	t
2	Для поддержания здоровья	t
\.


--
-- TOC entry 4013 (class 0 OID 19819)
-- Dependencies: 248
-- Data for Name: petshop_review; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.petshop_review (id, rating, text, date_created, product_id, user_id) FROM stdin;
3	5	Самый лучший корм на свете!!!	2025-09-22 18:50:57.154661+03	1	3
4	4	пакет весь изорван	2025-09-22 19:24:12.970478+03	1	3
5	5	ваукакуп	2025-09-28 22:21:45.132317+03	1	3
6	1	ывавыа	2025-09-28 22:22:55.816979+03	1	3
9	3	ывпаг	2025-09-28 23:31:49.822437+03	1	3
10	1	все очень плохо	2025-09-29 21:57:20.016802+03	1	2
11	5	Игрушка очень мягкая, только быстро порвалась, но это не проблема😊	2025-10-13 11:23:48.11765+03	2	2
12	5	Моей собаке очееееень понравилась игрушка. Теперь носит ее всегда с собой и спит вместе с ней. Покупайте этот прекраснейший товар, не пожалеете🤘🏿🤘🏻🫶🏿🫶🏻	2025-10-13 11:27:22.261955+03	2	2
13	2	корм вроде ничего, но мне не понравился	2025-11-06 09:53:36.126434+03	1	2
14	5	бе	2025-11-12 17:12:45.130545+03	2	2
\.


--
-- TOC entry 3997 (class 0 OID 19748)
-- Dependencies: 232
-- Data for Name: petshop_role; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.petshop_role (id, name) FROM stdin;
1	Администратор
2	Покупатель
5	Пользователь
\.


--
-- TOC entry 3999 (class 0 OID 19756)
-- Dependencies: 234
-- Data for Name: petshop_species; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.petshop_species (id, species_name, is_active) FROM stdin;
1	Собаки	t
2	Кошки	t
\.


--
-- TOC entry 4011 (class 0 OID 19801)
-- Dependencies: 246
-- Data for Name: petshop_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.petshop_user (id, first_name, last_name, middle_name, email, password, phone, role_id, date_joined, is_active, is_staff, is_superuser, last_login) FROM stdin;
27	Ксения	Иванов	\N	seller590@example.com	pbkdf2_sha256$1000000$iKFbRWCB043ihXbD5sSlyq$NBw0i5iIgzh1h1sE94OsLQbBpQ5eZqs5Hji/Z/qPeqI=	+7	2	2025-11-11 21:01:20.951566+03	t	f	f	2025-11-11 21:01:21.420271+03
2	Мария	Белова		kspankova13@gmail.com	pbkdf2_sha256$1000000$djZDFzVOi2CBOd2VyA7LkC$5KnYVLzhQR+wmIu+HdFL4iuiOx9PeWUCJ5TzBiAhc/o=	+79236783456	1	2025-09-20 17:32:29.091744+03	t	t	t	2025-11-12 16:38:18.4931+03
29	фваывп	аыв	\N	asdfg@gmail.com	pbkdf2_sha256$1000000$4VuERG5BoDQQQygWKxCKT8$BfBw3vHyOCEEQCcMtteKFx17DdgcRQFokIvmFNmZUjQ=	+7gfcgf	1	2025-11-12 17:35:13.663792+03	t	f	f	\N
3	Екатерина	Белова		isip_k.a.pankova@mpt.ru	pbkdf2_sha256$1000000$Wd3eX8akAbq9WTiGhKEe22$qEoR3rW2A13x5F/LwxgZYbb13nEMZrnPoV70X6KbEHg=	+79236783456	1	2025-09-20 18:57:45.361944+03	t	t	f	2025-10-07 21:34:46.945635+03
5	Мария	Панкова		seller001@example.com	pbkdf2_sha256$1000000$PW3f4KGkvnNQSGCWKX1RrX$MgMEFv40vvbFy65Ww4bBtr7EGqQeQwhya3xgPR2OrVg=	+78881234356	1	2025-09-24 21:37:00.916272+03	t	t	f	\N
6	Виктория	Дроздова		seller1010@example.com	pbkdf2_sha256$1000000$Q126JkEyNEh0fzvvWWAxKL$iUx2nlb5zIEYksluavfCDobOat4CbaTFLWZwvIzLf60=	+71235674534	1	2025-09-24 21:38:59.978903+03	t	t	f	\N
7	Мария	Белова		kspankova134@gmail.com	pbkdf2_sha256$1000000$ZGA4ZrGlCuScl1VCwGLz5J$v4IqPkaQ724AtwRhJH8mFaIaQmYYV0dYxHfDAfpfges=	+78881234356	2	2025-09-24 21:45:30.520864+03	t	f	f	2025-09-24 21:45:30.813398+03
9	Егор	Воронов		seller01@example.com	pbkdf2_sha256$1000000$1KhPmL2Jr2TFp6X28lgKRz$A64dbPRNrptgwwO8At6KHkQ6oKjpP08CKBMq1RKKfMM=	+71235674534	2	2025-09-26 18:32:17.809951+03	t	f	f	2025-10-13 14:07:14.970048+03
11	Егор	Воронов		sellerpok@example.com	pbkdf2_sha256$1000000$cVxthwH8AzRcOIOiyZgn3G$hdAWqxHiNU2u9CkgY9U0mpYcdmjAaQUfx/Swm2gDErA=	+79997891893	2	2025-09-28 18:30:31.596919+03	t	f	f	2025-09-28 18:35:32.718012+03
12	Валерия	Меладзе		valeriya@example.com	pbkdf2_sha256$1000000$6qLFuXG2i6Rsl3IFuezIaN$jJCAxM4Yjw4bg1aXCvswhMXFnUZKZhztT71vSHO7xi4=	+79124533312	1	2025-10-08 00:02:05.405767+03	t	t	f	\N
15	Иван	Иванов	Иванович	ivanov@example.com		89991234567	5	2025-10-22 23:33:37.012201+03	t	f	f	\N
16	Мария	Петрова	Сергеевна	petrova@example.com		89997654321	1	2025-10-22 23:33:37.139452+03	t	f	f	\N
17	Алексей	Сидоров		sidorov@example.com		89998765432	1	2025-10-22 23:33:37.16598+03	t	f	f	\N
18	Андрей	Смирнов	Игоревич	smirnov@example.com		89990001122	5	2025-10-22 23:42:33.674178+03	t	f	f	\N
20	Дмитрий	Волков	Сергеевич	volkov@example.com		89992223344	1	2025-10-22 23:42:33.683779+03	t	t	t	\N
21	Ольга	Морозова	Александровна	morozova@example.com		89993334455	5	2025-10-22 23:42:33.687503+03	f	f	f	\N
22	Сергей	Петров	Николаевич	petrov@example.com		89994445566	5	2025-10-22 23:42:33.69087+03	t	t	f	\N
23	rgfhj	gfgh		seller555@example.com	pbkdf2_sha256$1000000$Frhc7fHh2T6vfdN6HNd6sq$S0HxJmWIli/T/Y3x4/4wwZ+eOI0cOd9RPzTEV0xSiwo=	+78881234356	2	2025-10-25 22:18:17.211769+03	t	f	f	2025-10-25 22:18:17.691667+03
24	Ксюша	Белова	\N	jhsbcdhj@gmail.com	pbkdf2_sha256$1000000$xFFZUxEqYTRTp6YisgGCCg$ZMvW0t/gal9YMErVSIBUEmCwl4KH3fOSuWRB+qzgitI=	+7	2	2025-11-01 17:11:49.445508+03	t	f	f	2025-11-01 17:11:49.893845+03
25	Мария	Белова	\N	jhsbscdwcdhj@gmail.com	pbkdf2_sha256$1000000$tJ6tNDsNB2cObKouUTLWuT$Alvbn08AccUeAQFQkfgHgTFXtHf6ccaryv9t+QI4Ez8=	+7	2	2025-11-01 17:12:13.911612+03	t	f	f	2025-11-01 17:12:14.344012+03
26	Виктория	Воронов	\N	sdfghn@gmail.com	pbkdf2_sha256$1000000$sV9v04MuQwmYNOY4gfSrv7$C49V3JwBrD5CeEVAYcqpAGoGlar6HXtxuhLCZlno320=	+7	2	2025-11-01 17:12:39.463526+03	t	f	f	2025-11-01 17:12:39.891361+03
\.


--
-- TOC entry 4029 (class 0 OID 20034)
-- Dependencies: 264
-- Data for Name: petshop_user_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.petshop_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- TOC entry 4031 (class 0 OID 20043)
-- Dependencies: 266
-- Data for Name: petshop_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.petshop_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- TOC entry 4017 (class 0 OID 19838)
-- Dependencies: 252
-- Data for Name: petshop_userprofile; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.petshop_userprofile (id, date_of_birth, theme, user_id, date_format) FROM stdin;
23	2000-10-10	f	27	%d.%m.%Y
1	2000-10-15	f	2	%d.%m.%Y
2	2000-09-12	t	3	%d.%m.%Y
8	\N	f	5	%d.%m.%Y
9	\N	f	6	%d.%m.%Y
4	2000-03-07	f	7	%d.%m.%Y
5	2001-09-20	f	9	%d.%m.%Y
7	2000-09-20	f	11	%d.%m.%Y
10	\N	f	12	%d.%m.%Y
11	1990-05-12	f	15	%d.%m.%Y
12	1985-09-30	f	16	%d.%m.%Y
13	1992-01-25	f	17	%d.%m.%Y
14	1991-03-15	f	18	%d.%m.%Y
16	1982-12-05	f	20	%d.%m.%Y
17	1995-09-10	f	21	%d.%m.%Y
18	1990-01-30	f	22	%d.%m.%Y
19	2000-10-12	f	23	%d.%m.%Y
20	2004-09-20	f	24	%d.%m.%Y
21	2003-12-12	f	25	%d.%m.%Y
22	2000-02-17	f	26	%d.%m.%Y
\.


--
-- TOC entry 4036 (class 0 OID 105408)
-- Dependencies: 274
-- Data for Name: reversion_revision; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reversion_revision (id, date_created, comment, user_id) FROM stdin;
\.


--
-- TOC entry 4038 (class 0 OID 105416)
-- Dependencies: 276
-- Data for Name: reversion_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reversion_version (id, object_id, format, serialized_data, object_repr, content_type_id, revision_id, db) FROM stdin;
\.


--
-- TOC entry 4044 (class 0 OID 0)
-- Dependencies: 259
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- TOC entry 4045 (class 0 OID 0)
-- Dependencies: 261
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- TOC entry 4046 (class 0 OID 0)
-- Dependencies: 257
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 116, true);


--
-- TOC entry 4047 (class 0 OID 0)
-- Dependencies: 255
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 202, true);


--
-- TOC entry 4048 (class 0 OID 0)
-- Dependencies: 253
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 29, true);


--
-- TOC entry 4049 (class 0 OID 0)
-- Dependencies: 217
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 32, true);


--
-- TOC entry 4050 (class 0 OID 0)
-- Dependencies: 219
-- Name: petshop_agecategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.petshop_agecategory_id_seq', 12, true);


--
-- TOC entry 4051 (class 0 OID 0)
-- Dependencies: 271
-- Name: petshop_auditlog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.petshop_auditlog_id_seq', 289, true);


--
-- TOC entry 4052 (class 0 OID 0)
-- Dependencies: 221
-- Name: petshop_brand_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.petshop_brand_id_seq', 6, true);


--
-- TOC entry 4053 (class 0 OID 0)
-- Dependencies: 249
-- Name: petshop_cart_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.petshop_cart_id_seq', 92, true);


--
-- TOC entry 4054 (class 0 OID 0)
-- Dependencies: 223
-- Name: petshop_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.petshop_category_id_seq', 4, true);


--
-- TOC entry 4055 (class 0 OID 0)
-- Dependencies: 235
-- Name: petshop_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.petshop_order_id_seq', 144, true);


--
-- TOC entry 4056 (class 0 OID 0)
-- Dependencies: 239
-- Name: petshop_orderitem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.petshop_orderitem_id_seq', 135, true);


--
-- TOC entry 4057 (class 0 OID 0)
-- Dependencies: 225
-- Name: petshop_pickuppoint_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.petshop_pickuppoint_id_seq', 2, true);


--
-- TOC entry 4058 (class 0 OID 0)
-- Dependencies: 237
-- Name: petshop_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.petshop_product_id_seq', 9, true);


--
-- TOC entry 4059 (class 0 OID 0)
-- Dependencies: 243
-- Name: petshop_productpurpose_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.petshop_productpurpose_id_seq', 10, true);


--
-- TOC entry 4060 (class 0 OID 0)
-- Dependencies: 241
-- Name: petshop_productstock_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.petshop_productstock_id_seq', 11, true);


--
-- TOC entry 4061 (class 0 OID 0)
-- Dependencies: 227
-- Name: petshop_producttype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.petshop_producttype_id_seq', 4, true);


--
-- TOC entry 4062 (class 0 OID 0)
-- Dependencies: 229
-- Name: petshop_purpose_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.petshop_purpose_id_seq', 2, true);


--
-- TOC entry 4063 (class 0 OID 0)
-- Dependencies: 247
-- Name: petshop_review_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.petshop_review_id_seq', 14, true);


--
-- TOC entry 4064 (class 0 OID 0)
-- Dependencies: 231
-- Name: petshop_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.petshop_role_id_seq', 5, true);


--
-- TOC entry 4065 (class 0 OID 0)
-- Dependencies: 233
-- Name: petshop_species_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.petshop_species_id_seq', 2, true);


--
-- TOC entry 4066 (class 0 OID 0)
-- Dependencies: 263
-- Name: petshop_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.petshop_user_groups_id_seq', 1, false);


--
-- TOC entry 4067 (class 0 OID 0)
-- Dependencies: 245
-- Name: petshop_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.petshop_user_id_seq', 29, true);


--
-- TOC entry 4068 (class 0 OID 0)
-- Dependencies: 265
-- Name: petshop_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.petshop_user_user_permissions_id_seq', 1, false);


--
-- TOC entry 4069 (class 0 OID 0)
-- Dependencies: 251
-- Name: petshop_userprofile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.petshop_userprofile_id_seq', 24, true);


--
-- TOC entry 4070 (class 0 OID 0)
-- Dependencies: 273
-- Name: reversion_revision_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reversion_revision_id_seq', 1, false);


--
-- TOC entry 4071 (class 0 OID 0)
-- Dependencies: 275
-- Name: reversion_version_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reversion_version_id_seq', 1, false);


--
-- TOC entry 3727 (class 2606 OID 20030)
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- TOC entry 3732 (class 2606 OID 20016)
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- TOC entry 3735 (class 2606 OID 20005)
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- TOC entry 3729 (class 2606 OID 19997)
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- TOC entry 3722 (class 2606 OID 20007)
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- TOC entry 3724 (class 2606 OID 19991)
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- TOC entry 3718 (class 2606 OID 19973)
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- TOC entry 3713 (class 2606 OID 19964)
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- TOC entry 3715 (class 2606 OID 19962)
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- TOC entry 3648 (class 2606 OID 19710)
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 3750 (class 2606 OID 20091)
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- TOC entry 3650 (class 2606 OID 19716)
-- Name: petshop_agecategory petshop_agecategory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_agecategory
    ADD CONSTRAINT petshop_agecategory_pkey PRIMARY KEY (id);


--
-- TOC entry 3753 (class 2606 OID 20193)
-- Name: petshop_auditlog petshop_auditlog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_auditlog
    ADD CONSTRAINT petshop_auditlog_pkey PRIMARY KEY (id);


--
-- TOC entry 3652 (class 2606 OID 19722)
-- Name: petshop_brand petshop_brand_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_brand
    ADD CONSTRAINT petshop_brand_pkey PRIMARY KEY (id);


--
-- TOC entry 3705 (class 2606 OID 19836)
-- Name: petshop_cart petshop_cart_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_cart
    ADD CONSTRAINT petshop_cart_pkey PRIMARY KEY (id);


--
-- TOC entry 3654 (class 2606 OID 19728)
-- Name: petshop_category petshop_category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_category
    ADD CONSTRAINT petshop_category_pkey PRIMARY KEY (id);


--
-- TOC entry 3670 (class 2606 OID 19768)
-- Name: petshop_order petshop_order_order_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_order
    ADD CONSTRAINT petshop_order_order_number_key UNIQUE (order_number);


--
-- TOC entry 3673 (class 2606 OID 19766)
-- Name: petshop_order petshop_order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_order
    ADD CONSTRAINT petshop_order_pkey PRIMARY KEY (id);


--
-- TOC entry 3684 (class 2606 OID 19782)
-- Name: petshop_orderitem petshop_orderitem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_orderitem
    ADD CONSTRAINT petshop_orderitem_pkey PRIMARY KEY (id);


--
-- TOC entry 3656 (class 2606 OID 19734)
-- Name: petshop_pickuppoint petshop_pickuppoint_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_pickuppoint
    ADD CONSTRAINT petshop_pickuppoint_pkey PRIMARY KEY (id);


--
-- TOC entry 3679 (class 2606 OID 19776)
-- Name: petshop_product petshop_product_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_product
    ADD CONSTRAINT petshop_product_pkey PRIMARY KEY (id);


--
-- TOC entry 3691 (class 2606 OID 19794)
-- Name: petshop_productpurpose petshop_productpurpose_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_productpurpose
    ADD CONSTRAINT petshop_productpurpose_pkey PRIMARY KEY (id);


--
-- TOC entry 3688 (class 2606 OID 19788)
-- Name: petshop_productstock petshop_productstock_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_productstock
    ADD CONSTRAINT petshop_productstock_pkey PRIMARY KEY (id);


--
-- TOC entry 3658 (class 2606 OID 19740)
-- Name: petshop_producttype petshop_producttype_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_producttype
    ADD CONSTRAINT petshop_producttype_pkey PRIMARY KEY (id);


--
-- TOC entry 3660 (class 2606 OID 19746)
-- Name: petshop_purpose petshop_purpose_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_purpose
    ADD CONSTRAINT petshop_purpose_pkey PRIMARY KEY (id);


--
-- TOC entry 3701 (class 2606 OID 19825)
-- Name: petshop_review petshop_review_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_review
    ADD CONSTRAINT petshop_review_pkey PRIMARY KEY (id);


--
-- TOC entry 3663 (class 2606 OID 19754)
-- Name: petshop_role petshop_role_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_role
    ADD CONSTRAINT petshop_role_name_key UNIQUE (name);


--
-- TOC entry 3665 (class 2606 OID 19752)
-- Name: petshop_role petshop_role_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_role
    ADD CONSTRAINT petshop_role_pkey PRIMARY KEY (id);


--
-- TOC entry 3667 (class 2606 OID 19760)
-- Name: petshop_species petshop_species_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_species
    ADD CONSTRAINT petshop_species_pkey PRIMARY KEY (id);


--
-- TOC entry 3696 (class 2606 OID 19809)
-- Name: petshop_user petshop_user_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_user
    ADD CONSTRAINT petshop_user_email_key UNIQUE (email);


--
-- TOC entry 3738 (class 2606 OID 20038)
-- Name: petshop_user_groups petshop_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_user_groups
    ADD CONSTRAINT petshop_user_groups_pkey PRIMARY KEY (id);


--
-- TOC entry 3741 (class 2606 OID 20058)
-- Name: petshop_user_groups petshop_user_groups_user_id_group_id_d22b9a72_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_user_groups
    ADD CONSTRAINT petshop_user_groups_user_id_group_id_d22b9a72_uniq UNIQUE (user_id, group_id);


--
-- TOC entry 3698 (class 2606 OID 19807)
-- Name: petshop_user petshop_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_user
    ADD CONSTRAINT petshop_user_pkey PRIMARY KEY (id);


--
-- TOC entry 3743 (class 2606 OID 20072)
-- Name: petshop_user_user_permissions petshop_user_user_permis_user_id_permission_id_bd759b00_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_user_user_permissions
    ADD CONSTRAINT petshop_user_user_permis_user_id_permission_id_bd759b00_uniq UNIQUE (user_id, permission_id);


--
-- TOC entry 3746 (class 2606 OID 20047)
-- Name: petshop_user_user_permissions petshop_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_user_user_permissions
    ADD CONSTRAINT petshop_user_user_permissions_pkey PRIMARY KEY (id);


--
-- TOC entry 3709 (class 2606 OID 19842)
-- Name: petshop_userprofile petshop_userprofile_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_userprofile
    ADD CONSTRAINT petshop_userprofile_pkey PRIMARY KEY (id);


--
-- TOC entry 3711 (class 2606 OID 19844)
-- Name: petshop_userprofile petshop_userprofile_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_userprofile
    ADD CONSTRAINT petshop_userprofile_user_id_key UNIQUE (user_id);


--
-- TOC entry 3757 (class 2606 OID 105414)
-- Name: reversion_revision reversion_revision_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reversion_revision
    ADD CONSTRAINT reversion_revision_pkey PRIMARY KEY (id);


--
-- TOC entry 3762 (class 2606 OID 105424)
-- Name: reversion_version reversion_version_db_content_type_id_objec_b2c54f65_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reversion_version
    ADD CONSTRAINT reversion_version_db_content_type_id_objec_b2c54f65_uniq UNIQUE (db, content_type_id, object_id, revision_id);


--
-- TOC entry 3764 (class 2606 OID 105422)
-- Name: reversion_version reversion_version_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reversion_version
    ADD CONSTRAINT reversion_version_pkey PRIMARY KEY (id);


--
-- TOC entry 3725 (class 1259 OID 20031)
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- TOC entry 3730 (class 1259 OID 20027)
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- TOC entry 3733 (class 1259 OID 20028)
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- TOC entry 3720 (class 1259 OID 20013)
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- TOC entry 3716 (class 1259 OID 19984)
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- TOC entry 3719 (class 1259 OID 19985)
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- TOC entry 3748 (class 1259 OID 20093)
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- TOC entry 3751 (class 1259 OID 20092)
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- TOC entry 3754 (class 1259 OID 20199)
-- Name: petshop_auditlog_user_id_70f63ce5; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX petshop_auditlog_user_id_70f63ce5 ON public.petshop_auditlog USING btree (user_id);


--
-- TOC entry 3706 (class 1259 OID 19950)
-- Name: petshop_cart_product_id_b9d54230; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX petshop_cart_product_id_b9d54230 ON public.petshop_cart USING btree (product_id);


--
-- TOC entry 3707 (class 1259 OID 19951)
-- Name: petshop_cart_user_id_62f0c7ca; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX petshop_cart_user_id_62f0c7ca ON public.petshop_cart USING btree (user_id);


--
-- TOC entry 3668 (class 1259 OID 19851)
-- Name: petshop_order_order_number_c3453593_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX petshop_order_order_number_c3453593_like ON public.petshop_order USING btree (order_number varchar_pattern_ops);


--
-- TOC entry 3671 (class 1259 OID 19852)
-- Name: petshop_order_pickup_point_id_d8cdfe21; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX petshop_order_pickup_point_id_d8cdfe21 ON public.petshop_order USING btree (pickup_point_id);


--
-- TOC entry 3674 (class 1259 OID 19939)
-- Name: petshop_order_user_id_fdf57c13; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX petshop_order_user_id_fdf57c13 ON public.petshop_order USING btree (user_id);


--
-- TOC entry 3682 (class 1259 OID 19887)
-- Name: petshop_orderitem_order_id_82d9618f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX petshop_orderitem_order_id_82d9618f ON public.petshop_orderitem USING btree (order_id);


--
-- TOC entry 3685 (class 1259 OID 19888)
-- Name: petshop_orderitem_product_id_a7e7a8b2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX petshop_orderitem_product_id_a7e7a8b2 ON public.petshop_orderitem USING btree (product_id);


--
-- TOC entry 3675 (class 1259 OID 19873)
-- Name: petshop_product_age_category_id_c45c4515; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX petshop_product_age_category_id_c45c4515 ON public.petshop_product USING btree (age_category_id);


--
-- TOC entry 3676 (class 1259 OID 19874)
-- Name: petshop_product_brand_id_651dc408; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX petshop_product_brand_id_651dc408 ON public.petshop_product USING btree (brand_id);


--
-- TOC entry 3677 (class 1259 OID 19875)
-- Name: petshop_product_category_id_a44c2d15; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX petshop_product_category_id_a44c2d15 ON public.petshop_product USING btree (category_id);


--
-- TOC entry 3680 (class 1259 OID 19876)
-- Name: petshop_product_product_type_id_6547c232; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX petshop_product_product_type_id_6547c232 ON public.petshop_product USING btree (product_type_id);


--
-- TOC entry 3681 (class 1259 OID 19913)
-- Name: petshop_product_species_id_1827cdc2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX petshop_product_species_id_1827cdc2 ON public.petshop_product USING btree (species_id);


--
-- TOC entry 3692 (class 1259 OID 19911)
-- Name: petshop_productpurpose_product_id_4f73375c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX petshop_productpurpose_product_id_4f73375c ON public.petshop_productpurpose USING btree (product_id);


--
-- TOC entry 3693 (class 1259 OID 19912)
-- Name: petshop_productpurpose_purpose_id_8cc2195a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX petshop_productpurpose_purpose_id_8cc2195a ON public.petshop_productpurpose USING btree (purpose_id);


--
-- TOC entry 3686 (class 1259 OID 19899)
-- Name: petshop_productstock_pickup_point_id_e12ec453; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX petshop_productstock_pickup_point_id_e12ec453 ON public.petshop_productstock USING btree (pickup_point_id);


--
-- TOC entry 3689 (class 1259 OID 19900)
-- Name: petshop_productstock_product_id_b5bf287c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX petshop_productstock_product_id_b5bf287c ON public.petshop_productstock USING btree (product_id);


--
-- TOC entry 3702 (class 1259 OID 19937)
-- Name: petshop_review_product_id_0e34d9a4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX petshop_review_product_id_0e34d9a4 ON public.petshop_review USING btree (product_id);


--
-- TOC entry 3703 (class 1259 OID 19938)
-- Name: petshop_review_user_id_590f7525; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX petshop_review_user_id_590f7525 ON public.petshop_review USING btree (user_id);


--
-- TOC entry 3661 (class 1259 OID 19845)
-- Name: petshop_role_name_5702d4eb_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX petshop_role_name_5702d4eb_like ON public.petshop_role USING btree (name varchar_pattern_ops);


--
-- TOC entry 3694 (class 1259 OID 19919)
-- Name: petshop_user_email_12c75948_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX petshop_user_email_12c75948_like ON public.petshop_user USING btree (email varchar_pattern_ops);


--
-- TOC entry 3736 (class 1259 OID 20070)
-- Name: petshop_user_groups_group_id_0056e5b6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX petshop_user_groups_group_id_0056e5b6 ON public.petshop_user_groups USING btree (group_id);


--
-- TOC entry 3739 (class 1259 OID 20069)
-- Name: petshop_user_groups_user_id_3d7cdcbc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX petshop_user_groups_user_id_3d7cdcbc ON public.petshop_user_groups USING btree (user_id);


--
-- TOC entry 3699 (class 1259 OID 19920)
-- Name: petshop_user_role_id_3b8745a3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX petshop_user_role_id_3b8745a3 ON public.petshop_user USING btree (role_id);


--
-- TOC entry 3744 (class 1259 OID 20084)
-- Name: petshop_user_user_permissions_permission_id_5e28312c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX petshop_user_user_permissions_permission_id_5e28312c ON public.petshop_user_user_permissions USING btree (permission_id);


--
-- TOC entry 3747 (class 1259 OID 20083)
-- Name: petshop_user_user_permissions_user_id_0fec841b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX petshop_user_user_permissions_user_id_0fec841b ON public.petshop_user_user_permissions USING btree (user_id);


--
-- TOC entry 3755 (class 1259 OID 105430)
-- Name: reversion_revision_date_created_96f7c20c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reversion_revision_date_created_96f7c20c ON public.reversion_revision USING btree (date_created);


--
-- TOC entry 3758 (class 1259 OID 105431)
-- Name: reversion_revision_user_id_17095f45; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reversion_revision_user_id_17095f45 ON public.reversion_revision USING btree (user_id);


--
-- TOC entry 3759 (class 1259 OID 105444)
-- Name: reversion_v_content_f95daf_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reversion_v_content_f95daf_idx ON public.reversion_version USING btree (content_type_id, db);


--
-- TOC entry 3760 (class 1259 OID 105442)
-- Name: reversion_version_content_type_id_7d0ff25c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reversion_version_content_type_id_7d0ff25c ON public.reversion_version USING btree (content_type_id);


--
-- TOC entry 3765 (class 1259 OID 105443)
-- Name: reversion_version_revision_id_af9f6a9d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reversion_version_revision_id_af9f6a9d ON public.reversion_version USING btree (revision_id);


--
-- TOC entry 3798 (class 2620 OID 20404)
-- Name: petshop_agecategory trg_agecategory_delete; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_agecategory_delete AFTER DELETE ON public.petshop_agecategory FOR EACH ROW EXECUTE FUNCTION public.trg_agecategory_delete_func();


--
-- TOC entry 3799 (class 2620 OID 20400)
-- Name: petshop_agecategory trg_agecategory_insert; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_agecategory_insert AFTER INSERT ON public.petshop_agecategory FOR EACH ROW EXECUTE FUNCTION public.trg_agecategory_insert_func();


--
-- TOC entry 3800 (class 2620 OID 20402)
-- Name: petshop_agecategory trg_agecategory_update; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_agecategory_update AFTER UPDATE ON public.petshop_agecategory FOR EACH ROW EXECUTE FUNCTION public.trg_agecategory_update_func();


--
-- TOC entry 3801 (class 2620 OID 20398)
-- Name: petshop_brand trg_brand_delete; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_brand_delete AFTER DELETE ON public.petshop_brand FOR EACH ROW EXECUTE FUNCTION public.trg_brand_delete_func();


--
-- TOC entry 3802 (class 2620 OID 20394)
-- Name: petshop_brand trg_brand_insert; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_brand_insert AFTER INSERT ON public.petshop_brand FOR EACH ROW EXECUTE FUNCTION public.trg_brand_insert_func();


--
-- TOC entry 3803 (class 2620 OID 20396)
-- Name: petshop_brand trg_brand_update; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_brand_update AFTER UPDATE ON public.petshop_brand FOR EACH ROW EXECUTE FUNCTION public.trg_brand_update_func();


--
-- TOC entry 3804 (class 2620 OID 20392)
-- Name: petshop_category trg_category_delete; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_category_delete AFTER DELETE ON public.petshop_category FOR EACH ROW EXECUTE FUNCTION public.trg_category_delete_func();


--
-- TOC entry 3805 (class 2620 OID 20388)
-- Name: petshop_category trg_category_insert; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_category_insert AFTER INSERT ON public.petshop_category FOR EACH ROW EXECUTE FUNCTION public.trg_category_insert_func();


--
-- TOC entry 3806 (class 2620 OID 20390)
-- Name: petshop_category trg_category_update; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_category_update AFTER UPDATE ON public.petshop_category FOR EACH ROW EXECUTE FUNCTION public.trg_category_update_func();


--
-- TOC entry 3822 (class 2620 OID 20356)
-- Name: petshop_order trg_order_delete; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_order_delete AFTER DELETE ON public.petshop_order FOR EACH ROW EXECUTE FUNCTION public.trg_order_delete_func();


--
-- TOC entry 3823 (class 2620 OID 20352)
-- Name: petshop_order trg_order_insert; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_order_insert AFTER INSERT ON public.petshop_order FOR EACH ROW EXECUTE FUNCTION public.trg_order_insert_func();


--
-- TOC entry 3824 (class 2620 OID 20354)
-- Name: petshop_order trg_order_update; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_order_update AFTER UPDATE ON public.petshop_order FOR EACH ROW EXECUTE FUNCTION public.trg_order_update_func();


--
-- TOC entry 3807 (class 2620 OID 20362)
-- Name: petshop_pickuppoint trg_pickuppoint_delete; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_pickuppoint_delete AFTER DELETE ON public.petshop_pickuppoint FOR EACH ROW EXECUTE FUNCTION public.trg_pickuppoint_delete_func();


--
-- TOC entry 3808 (class 2620 OID 20358)
-- Name: petshop_pickuppoint trg_pickuppoint_insert; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_pickuppoint_insert AFTER INSERT ON public.petshop_pickuppoint FOR EACH ROW EXECUTE FUNCTION public.trg_pickuppoint_insert_func();


--
-- TOC entry 3809 (class 2620 OID 20360)
-- Name: petshop_pickuppoint trg_pickuppoint_update; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_pickuppoint_update AFTER UPDATE ON public.petshop_pickuppoint FOR EACH ROW EXECUTE FUNCTION public.trg_pickuppoint_update_func();


--
-- TOC entry 3825 (class 2620 OID 20386)
-- Name: petshop_product trg_product_delete; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_product_delete AFTER DELETE ON public.petshop_product FOR EACH ROW EXECUTE FUNCTION public.trg_product_delete_func();


--
-- TOC entry 3826 (class 2620 OID 20382)
-- Name: petshop_product trg_product_insert; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_product_insert AFTER INSERT ON public.petshop_product FOR EACH ROW EXECUTE FUNCTION public.trg_product_insert_func();


--
-- TOC entry 3827 (class 2620 OID 20384)
-- Name: petshop_product trg_product_update; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_product_update AFTER UPDATE ON public.petshop_product FOR EACH ROW EXECUTE FUNCTION public.trg_product_update_func();


--
-- TOC entry 3831 (class 2620 OID 105355)
-- Name: petshop_productpurpose trg_productpurpose_delete; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_productpurpose_delete AFTER DELETE ON public.petshop_productpurpose FOR EACH ROW EXECUTE FUNCTION public.trg_productpurpose_delete_func();


--
-- TOC entry 3832 (class 2620 OID 20346)
-- Name: petshop_productpurpose trg_productpurpose_insert; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_productpurpose_insert AFTER INSERT ON public.petshop_productpurpose FOR EACH ROW EXECUTE FUNCTION public.trg_productpurpose_insert_func();


--
-- TOC entry 3833 (class 2620 OID 20348)
-- Name: petshop_productpurpose trg_productpurpose_update; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_productpurpose_update AFTER UPDATE ON public.petshop_productpurpose FOR EACH ROW EXECUTE FUNCTION public.trg_productpurpose_update_func();


--
-- TOC entry 3828 (class 2620 OID 20368)
-- Name: petshop_productstock trg_productstock_delete; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_productstock_delete AFTER DELETE ON public.petshop_productstock FOR EACH ROW EXECUTE FUNCTION public.trg_productstock_delete_func();


--
-- TOC entry 3829 (class 2620 OID 20364)
-- Name: petshop_productstock trg_productstock_insert; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_productstock_insert AFTER INSERT ON public.petshop_productstock FOR EACH ROW EXECUTE FUNCTION public.trg_productstock_insert_func();


--
-- TOC entry 3830 (class 2620 OID 20366)
-- Name: petshop_productstock trg_productstock_update; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_productstock_update AFTER UPDATE ON public.petshop_productstock FOR EACH ROW EXECUTE FUNCTION public.trg_productstock_update_func();


--
-- TOC entry 3810 (class 2620 OID 20410)
-- Name: petshop_producttype trg_producttype_delete; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_producttype_delete AFTER DELETE ON public.petshop_producttype FOR EACH ROW EXECUTE FUNCTION public.trg_producttype_delete_func();


--
-- TOC entry 3811 (class 2620 OID 20406)
-- Name: petshop_producttype trg_producttype_insert; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_producttype_insert AFTER INSERT ON public.petshop_producttype FOR EACH ROW EXECUTE FUNCTION public.trg_producttype_insert_func();


--
-- TOC entry 3812 (class 2620 OID 20408)
-- Name: petshop_producttype trg_producttype_update; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_producttype_update AFTER UPDATE ON public.petshop_producttype FOR EACH ROW EXECUTE FUNCTION public.trg_producttype_update_func();


--
-- TOC entry 3813 (class 2620 OID 20422)
-- Name: petshop_purpose trg_purpose_delete; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_purpose_delete AFTER DELETE ON public.petshop_purpose FOR EACH ROW EXECUTE FUNCTION public.trg_purpose_delete_func();


--
-- TOC entry 3814 (class 2620 OID 20418)
-- Name: petshop_purpose trg_purpose_insert; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_purpose_insert AFTER INSERT ON public.petshop_purpose FOR EACH ROW EXECUTE FUNCTION public.trg_purpose_insert_func();


--
-- TOC entry 3815 (class 2620 OID 20420)
-- Name: petshop_purpose trg_purpose_update; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_purpose_update AFTER UPDATE ON public.petshop_purpose FOR EACH ROW EXECUTE FUNCTION public.trg_purpose_update_func();


--
-- TOC entry 3816 (class 2620 OID 20380)
-- Name: petshop_role trg_role_delete; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_role_delete AFTER DELETE ON public.petshop_role FOR EACH ROW EXECUTE FUNCTION public.trg_role_delete_func();


--
-- TOC entry 3817 (class 2620 OID 20376)
-- Name: petshop_role trg_role_insert; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_role_insert AFTER INSERT ON public.petshop_role FOR EACH ROW EXECUTE FUNCTION public.trg_role_insert_func();


--
-- TOC entry 3818 (class 2620 OID 20378)
-- Name: petshop_role trg_role_update; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_role_update AFTER UPDATE ON public.petshop_role FOR EACH ROW EXECUTE FUNCTION public.trg_role_update_func();


--
-- TOC entry 3819 (class 2620 OID 20416)
-- Name: petshop_species trg_species_delete; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_species_delete AFTER DELETE ON public.petshop_species FOR EACH ROW EXECUTE FUNCTION public.trg_species_delete_func();


--
-- TOC entry 3820 (class 2620 OID 20412)
-- Name: petshop_species trg_species_insert; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_species_insert AFTER INSERT ON public.petshop_species FOR EACH ROW EXECUTE FUNCTION public.trg_species_insert_func();


--
-- TOC entry 3821 (class 2620 OID 20414)
-- Name: petshop_species trg_species_update; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_species_update AFTER UPDATE ON public.petshop_species FOR EACH ROW EXECUTE FUNCTION public.trg_species_update_func();


--
-- TOC entry 3788 (class 2606 OID 20022)
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3789 (class 2606 OID 20017)
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3787 (class 2606 OID 20008)
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3785 (class 2606 OID 19974)
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3786 (class 2606 OID 19979)
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_petshop_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_petshop_user_id FOREIGN KEY (user_id) REFERENCES public.petshop_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3794 (class 2606 OID 20194)
-- Name: petshop_auditlog petshop_auditlog_user_id_70f63ce5_fk_petshop_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_auditlog
    ADD CONSTRAINT petshop_auditlog_user_id_70f63ce5_fk_petshop_user_id FOREIGN KEY (user_id) REFERENCES public.petshop_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3782 (class 2606 OID 19940)
-- Name: petshop_cart petshop_cart_product_id_b9d54230_fk_petshop_product_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_cart
    ADD CONSTRAINT petshop_cart_product_id_b9d54230_fk_petshop_product_id FOREIGN KEY (product_id) REFERENCES public.petshop_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3783 (class 2606 OID 19945)
-- Name: petshop_cart petshop_cart_user_id_62f0c7ca_fk_petshop_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_cart
    ADD CONSTRAINT petshop_cart_user_id_62f0c7ca_fk_petshop_user_id FOREIGN KEY (user_id) REFERENCES public.petshop_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3766 (class 2606 OID 19846)
-- Name: petshop_order petshop_order_pickup_point_id_d8cdfe21_fk_petshop_p; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_order
    ADD CONSTRAINT petshop_order_pickup_point_id_d8cdfe21_fk_petshop_p FOREIGN KEY (pickup_point_id) REFERENCES public.petshop_pickuppoint(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3767 (class 2606 OID 19826)
-- Name: petshop_order petshop_order_user_id_fdf57c13_fk_petshop_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_order
    ADD CONSTRAINT petshop_order_user_id_fdf57c13_fk_petshop_user_id FOREIGN KEY (user_id) REFERENCES public.petshop_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3773 (class 2606 OID 19877)
-- Name: petshop_orderitem petshop_orderitem_order_id_82d9618f_fk_petshop_order_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_orderitem
    ADD CONSTRAINT petshop_orderitem_order_id_82d9618f_fk_petshop_order_id FOREIGN KEY (order_id) REFERENCES public.petshop_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3774 (class 2606 OID 19882)
-- Name: petshop_orderitem petshop_orderitem_product_id_a7e7a8b2_fk_petshop_product_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_orderitem
    ADD CONSTRAINT petshop_orderitem_product_id_a7e7a8b2_fk_petshop_product_id FOREIGN KEY (product_id) REFERENCES public.petshop_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3768 (class 2606 OID 19853)
-- Name: petshop_product petshop_product_age_category_id_c45c4515_fk_petshop_a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_product
    ADD CONSTRAINT petshop_product_age_category_id_c45c4515_fk_petshop_a FOREIGN KEY (age_category_id) REFERENCES public.petshop_agecategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3769 (class 2606 OID 19858)
-- Name: petshop_product petshop_product_brand_id_651dc408_fk_petshop_brand_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_product
    ADD CONSTRAINT petshop_product_brand_id_651dc408_fk_petshop_brand_id FOREIGN KEY (brand_id) REFERENCES public.petshop_brand(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3770 (class 2606 OID 19863)
-- Name: petshop_product petshop_product_category_id_a44c2d15_fk_petshop_category_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_product
    ADD CONSTRAINT petshop_product_category_id_a44c2d15_fk_petshop_category_id FOREIGN KEY (category_id) REFERENCES public.petshop_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3771 (class 2606 OID 19868)
-- Name: petshop_product petshop_product_product_type_id_6547c232_fk_petshop_p; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_product
    ADD CONSTRAINT petshop_product_product_type_id_6547c232_fk_petshop_p FOREIGN KEY (product_type_id) REFERENCES public.petshop_producttype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3772 (class 2606 OID 19795)
-- Name: petshop_product petshop_product_species_id_1827cdc2_fk_petshop_species_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_product
    ADD CONSTRAINT petshop_product_species_id_1827cdc2_fk_petshop_species_id FOREIGN KEY (species_id) REFERENCES public.petshop_species(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3777 (class 2606 OID 19901)
-- Name: petshop_productpurpose petshop_productpurpo_product_id_4f73375c_fk_petshop_p; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_productpurpose
    ADD CONSTRAINT petshop_productpurpo_product_id_4f73375c_fk_petshop_p FOREIGN KEY (product_id) REFERENCES public.petshop_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3778 (class 2606 OID 19906)
-- Name: petshop_productpurpose petshop_productpurpo_purpose_id_8cc2195a_fk_petshop_p; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_productpurpose
    ADD CONSTRAINT petshop_productpurpo_purpose_id_8cc2195a_fk_petshop_p FOREIGN KEY (purpose_id) REFERENCES public.petshop_purpose(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3775 (class 2606 OID 19889)
-- Name: petshop_productstock petshop_productstock_pickup_point_id_e12ec453_fk_petshop_p; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_productstock
    ADD CONSTRAINT petshop_productstock_pickup_point_id_e12ec453_fk_petshop_p FOREIGN KEY (pickup_point_id) REFERENCES public.petshop_pickuppoint(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3776 (class 2606 OID 19894)
-- Name: petshop_productstock petshop_productstock_product_id_b5bf287c_fk_petshop_product_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_productstock
    ADD CONSTRAINT petshop_productstock_product_id_b5bf287c_fk_petshop_product_id FOREIGN KEY (product_id) REFERENCES public.petshop_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3780 (class 2606 OID 19927)
-- Name: petshop_review petshop_review_product_id_0e34d9a4_fk_petshop_product_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_review
    ADD CONSTRAINT petshop_review_product_id_0e34d9a4_fk_petshop_product_id FOREIGN KEY (product_id) REFERENCES public.petshop_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3781 (class 2606 OID 19932)
-- Name: petshop_review petshop_review_user_id_590f7525_fk_petshop_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_review
    ADD CONSTRAINT petshop_review_user_id_590f7525_fk_petshop_user_id FOREIGN KEY (user_id) REFERENCES public.petshop_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3790 (class 2606 OID 20064)
-- Name: petshop_user_groups petshop_user_groups_group_id_0056e5b6_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_user_groups
    ADD CONSTRAINT petshop_user_groups_group_id_0056e5b6_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3791 (class 2606 OID 20059)
-- Name: petshop_user_groups petshop_user_groups_user_id_3d7cdcbc_fk_petshop_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_user_groups
    ADD CONSTRAINT petshop_user_groups_user_id_3d7cdcbc_fk_petshop_user_id FOREIGN KEY (user_id) REFERENCES public.petshop_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3779 (class 2606 OID 19914)
-- Name: petshop_user petshop_user_role_id_3b8745a3_fk_petshop_role_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_user
    ADD CONSTRAINT petshop_user_role_id_3b8745a3_fk_petshop_role_id FOREIGN KEY (role_id) REFERENCES public.petshop_role(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3792 (class 2606 OID 20078)
-- Name: petshop_user_user_permissions petshop_user_user_pe_permission_id_5e28312c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_user_user_permissions
    ADD CONSTRAINT petshop_user_user_pe_permission_id_5e28312c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3793 (class 2606 OID 20073)
-- Name: petshop_user_user_permissions petshop_user_user_pe_user_id_0fec841b_fk_petshop_u; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_user_user_permissions
    ADD CONSTRAINT petshop_user_user_pe_user_id_0fec841b_fk_petshop_u FOREIGN KEY (user_id) REFERENCES public.petshop_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3784 (class 2606 OID 19952)
-- Name: petshop_userprofile petshop_userprofile_user_id_499f1f4d_fk_petshop_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petshop_userprofile
    ADD CONSTRAINT petshop_userprofile_user_id_499f1f4d_fk_petshop_user_id FOREIGN KEY (user_id) REFERENCES public.petshop_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3795 (class 2606 OID 105425)
-- Name: reversion_revision reversion_revision_user_id_17095f45_fk_petshop_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reversion_revision
    ADD CONSTRAINT reversion_revision_user_id_17095f45_fk_petshop_user_id FOREIGN KEY (user_id) REFERENCES public.petshop_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3796 (class 2606 OID 105432)
-- Name: reversion_version reversion_version_content_type_id_7d0ff25c_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reversion_version
    ADD CONSTRAINT reversion_version_content_type_id_7d0ff25c_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3797 (class 2606 OID 105437)
-- Name: reversion_version reversion_version_revision_id_af9f6a9d_fk_reversion_revision_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reversion_version
    ADD CONSTRAINT reversion_version_revision_id_af9f6a9d_fk_reversion_revision_id FOREIGN KEY (revision_id) REFERENCES public.reversion_revision(id) DEFERRABLE INITIALLY DEFERRED;


-- Completed on 2025-11-13 11:12:28 MSK

--
-- PostgreSQL database dump complete
--

\unrestrict JjGylJgvWfEBFOhU7dRkyfO7mePgYm2EvBhTPtkmNtZFy5Z9J4WQhAF6jnpt5Jt

